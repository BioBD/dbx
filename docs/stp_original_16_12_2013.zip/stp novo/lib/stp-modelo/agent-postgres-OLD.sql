-- SQL Manager 2005 for PostgreSQL 3.3.0.1
-- ---------------------------------------
-- Host     : localhost
-- Database : tpc_h


CREATE SCHEMA agent AUTHORIZATION postgres;
--
-- Structure for table workload (OID = 1352225) : 
--
SET search_path = agent, pg_catalog;

--
-- Definition for sequence sq_ind_cand (OID = 1352255) : 
--
CREATE SEQUENCE sq_ind_cand
    INCREMENT BY 1
    MAXVALUE 99999
    NO MINVALUE
    CACHE 1;
--
-- Structure for table tb_candidate_index (OID = 8776033) : 
--
CREATE TABLE tb_candidate_index (
    cid_id integer DEFAULT nextval(('"agent"."tb_candidate_index_cid_id_seq"'::text)::regclass) NOT NULL,
    cid_table_name character varying(100),
    cid_primary_index_benefict integer DEFAULT 0,
    cid_secondary_index_benefict integer DEFAULT 0
);
--
-- Structure for table tb_candidate_index_column (OID = 8776037) : 
--
CREATE TABLE tb_candidate_index_column (
    cid_id integer NOT NULL,
    cic_column_name character varying(100) NOT NULL,
    cic_type character varying(100),
    cic_fl_status character(1)
);

CREATE SEQUENCE "agent"."workload_id_seq"
    INCREMENT 1  MINVALUE 1
    MAXVALUE 99999  START 33
    CACHE 1;
--
-- Structure for table tb_workload (OID = 8776041) : 
--
CREATE TABLE tb_workload (
    wld_id integer DEFAULT nextval('workload_id_seq'::regclass) NOT NULL,
    wld_sql text,
    wld_plan text,
    wld_access_count integer,
    wld_last_access_count integer,
    wld_fl_exec character(1) DEFAULT 'N'::bpchar
);
--
-- Structure for table tb_access_plan (OID = 8776048) : 
--
CREATE TABLE tb_access_plan (
    wld_id integer NOT NULL,
    apl_id_seq integer NOT NULL,
    apl_text_line text
);
--
-- Definition for sequence tb_candidate_index_cid_id_seq (OID = 8776093) : 
--
CREATE SEQUENCE tb_candidate_index_cid_id_seq
    INCREMENT BY 1
    MAXVALUE 99999
    NO MINVALUE
    CACHE 1;
--
-- Definition for index workload_pkey (OID = 1352246) : 
--
ALTER TABLE ONLY workload
    ADD CONSTRAINT workload_pkey PRIMARY KEY (id);
--
-- Definition for index pk_tb_candidate_index_column (OID = 8776039) : 
--
ALTER TABLE ONLY tb_candidate_index_column
    ADD CONSTRAINT pk_tb_candidate_index_column PRIMARY KEY (cid_id, cic_column_name);
--
-- Definition for index pk_tb_workload (OID = 8776046) : 
--
ALTER TABLE ONLY tb_workload
    ADD CONSTRAINT pk_tb_workload PRIMARY KEY (wld_id);
--
-- Definition for index fk_tb_access_plan_tb_workload2 (OID = 8776060) : 
--
ALTER TABLE ONLY tb_access_plan
    ADD CONSTRAINT fk_tb_access_plan_tb_workload2 FOREIGN KEY (wld_id) REFERENCES tb_workload(wld_id) ON UPDATE RESTRICT ON DELETE RESTRICT;
--
-- Definition for index pk_tb_access_plan (OID = 8776080) : 
--
ALTER TABLE ONLY tb_access_plan
    ADD CONSTRAINT pk_tb_access_plan PRIMARY KEY (wld_id, apl_id_seq);
--
-- Definition for index pk_tb_candidate_index (OID = 8776095) : 
--
ALTER TABLE ONLY tb_candidate_index
    ADD CONSTRAINT pk_tb_candidate_index PRIMARY KEY (cid_id);
--
-- Definition for index fk_tb_candidate_index_column_tb_candidate_index2 (OID = 8776097) : 
--
ALTER TABLE ONLY tb_candidate_index_column
    ADD CONSTRAINT fk_tb_candidate_index_column_tb_candidate_index2 FOREIGN KEY (cid_id) REFERENCES tb_candidate_index(cid_id) ON UPDATE RESTRICT ON DELETE RESTRICT;
