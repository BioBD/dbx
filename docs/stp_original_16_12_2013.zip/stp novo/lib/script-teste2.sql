SELECT pg_stat_get_backend_pid(s.backendid) AS processo_id,
pg_stat_get_backend_activity(s.backendid) AS sql 
FROM (SELECT pg_stat_get_backend_idset() AS backendid) AS s 
where pg_stat_get_backend_activity(s.backendid) not in ('<IDLE>')