SELECT * FROM lineitem WHERE l_orderkey=1

select * 
from agent.tb_workload

select *
from agent.tb_access_plan

delete from agent.tb_access_plan

delete from agent.tb_workload