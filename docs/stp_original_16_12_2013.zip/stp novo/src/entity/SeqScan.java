package entity;

import java.util.ArrayList;

/**
 * @author Jos� Maria
 * 
 * Classe usada para representar uma opera��o SeqScan (Full Scan ou Busca Sequencial)
 */
public class SeqScan {
	private String table;
	/** Estimativa do custo de execu��o do SeqScan (fornecido pelo pr�prio processador de consultas **/
	private String costEstimation;
	/** Quantidade de linhas (tuplas) recuperadas pela opera��o SeqScan **/
	private int retrievedRows;
//	
//	private int wldId;
//	
//	private String wldType;
//	
//	private int wldQtd;*/
	
	/**
	 * M�todo Construtor
	 * @param tabela Tabela sobre a qual o SeqScan � executado
	 * @param campo Campo utilizado no filtro (condi��o de sele��o associada � opera��o de SeqScan
	 * @param operador Operador
	 * @param custo /** Estimativa do custo de execu��o do SeqScan (fornecido pelo pr�prio processador de consultas
	 * @param linhas Quantidade de linhas (tuplas) recuperadas pela opera��o SeqScan
	 * @param wldId Identificador da Express�o SQL onde foi encontrada a opera��o SeqScan
	 * @param wldType Tipo da Express�o SQL onde foi encontrada a opera��o SeqScan
	 */
	public SeqScan(String table, String costEstimation, int retrievedRows) {
		super();
		this.table = table;
		this.costEstimation = costEstimation;
		this.retrievedRows = retrievedRows;
//		this.linhas = linhas;
//		this.wldId = wldId;
//		this.wldType = wldType;
//		this.wldQtd = wldQtd;
	}
	
	
	/**
	 * M�todo utilizado para recuperar o valor do atributo custo
	 * @return Valor do atributo custo
	 */
	public String getCostEstimation() {
		return costEstimation;
	}
	
	/**
	 * M�todo utilizado para setar o valor do atributo custo
	 * @param costEstimation Valor do atributo custo
	 */
	public void setCostEstimation(String costEstimation) {
		this.costEstimation = costEstimation;
	}
	
	/**
	 * M�todo utilizado para recuperar o valor do atributo tabela
	 * @return Valor do atributo tabela
	 */
	public String getTableName() {
		return table;
	}
	
	/**
	 * M�todo utilizado para setar o valor do atributo tabela
	 * @param tabela Novo valor do atributo tabela
	 */
	public void setTableName(String tableName) {
		this.table = tableName;
	}
	
	/**
	 * M�todo utilizado para converter o objeto SeqScan em uma String
	 */
	@Override
	public String toString() {
		return getTableName() + "." +  " + getCusto()";
	}
	
	/**
	 * M�todo utilizado para recuperar o valor do atributo linhas
	 * @return Valor do atributo linhas
	 */
//	public int getLinhas() {
//		return linhas;
//	}
//	
//	/**
//	 * M�todo utilizado para setar o valor do atributo linhas
//	 * @param linhas Novo valor do atributo linhas
//	 */
//	public void setLinhas(int linhas) {
//		this.linhas = linhas;
//	}
//	
//
//	public int getWldId() {
//		return wldId;
//	}
//	
//
//	public void setWldId(int wldId) {
//		this.wldId = wldId;
//	}
//	
//	public String getWldType() {
//		return wldType;
//	}
//	
//
//	public void setWldId(String wldType) {
//		this.wldType = wldType;
//	}
//	
//	public int getWldQtd() {
//		return wldQtd;
//	}
//	
//
//	public void setWldQtd(int wldQtd) {
//		this.wldQtd = wldQtd;
//	}
//	
	
}
