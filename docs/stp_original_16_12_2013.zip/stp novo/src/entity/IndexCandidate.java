package entity;

import java.util.ArrayList;


public class IndexCandidate {

    private int id;
    private String indexName;
    private String tableName;
    private int profit;
    private int relativeProfit;
    private int creationCost;
    private String status; //se índice é hipotético ou não
    private String type;
    private int initialProfit;
    private int fragmentationLevel;
    private ArrayList<String> columns = new ArrayList<String>();
    private int estimatedCostOfAnIndexScan;

    public IndexCandidate(String tableName, String status, String type,
            ArrayList<String> columns, int costOfAnIndexScan) {
        super();
        this.tableName = tableName;
        this.status = status;
        this.type = type;
        this.columns = columns;
        this.estimatedCostOfAnIndexScan = costOfAnIndexScan;
    }

    public IndexCandidate(int id, String tableName, int profit, String status, String type, ArrayList<String> columns) {
        this.id = id;
        this.tableName = tableName;
        this.profit = profit;
        this.status = status;
        this.type = type;
        this.columns = columns;
    }

    public IndexCandidate(String tableName) {
        this.tableName = tableName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIndexName() {
        return indexName;
    }

    public void setIndexName(String indexName) {
        this.indexName = indexName;
    }
    
    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public int getProfit() {
        return profit;
    }

    public void setProfit(int profit) {
        this.profit = profit;
    }

    public int getCreationCost() {
        return creationCost;
    }

    public void setCreationCost(int creationCost) {
        this.creationCost = creationCost;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getInitialProfit() {
        return initialProfit;
    }

    public void setInitialProfit(int initialProfit) {
        this.initialProfit = initialProfit;
    }

    public int getFragmentationLevel() {
        return fragmentationLevel;
    }

    public void setFragmentationLevel(int fragmentationLevel) {
        this.fragmentationLevel = fragmentationLevel;
    }

    public void addColumn(String columnName) {
        this.columns.add(columnName);
    }

    public void addColumns(ArrayList<String> newColumns) {
        for (int i = 0; i < newColumns.size(); i++) {
            if (!this.columns.contains(newColumns.get(i))) {
                this.columns.add(newColumns.get(i));
            }
        }
    }

    public ArrayList<String> getColumns() {
        return this.columns;
    }

    public int getCostOfAnIndexScan() {
        return estimatedCostOfAnIndexScan;
    }

    public void setCostOfAnIndexScan(int costOfAnIndexScan) {
        this.estimatedCostOfAnIndexScan = costOfAnIndexScan;
    }

    public void setColumns(ArrayList<String> columns) {
        this.columns = columns;
    }

    public int getRelativeProfit() {
        return relativeProfit;
    }

    public void setRelativeProfit(int relativeProfit) {
        this.relativeProfit = relativeProfit;
    }
    
    public boolean isIndexCandidateHypothetical() {
        if(this.getStatus().equals("H")) {
            return true;
        }
        return false;
    }
}
