package entity;

import java.util.ArrayList;

public class SeqScanWithFilter extends SeqScan {
	
	private ArrayList<String> fieldsUsedInFilter;
	/* Operador ( = , >, < )*/
	private String operator;
	
	public SeqScanWithFilter(String table, String costEstimation, int retrievedRows, ArrayList<String> fields, String operator) {
		super(table,costEstimation,retrievedRows);
		this.fieldsUsedInFilter = fields;
		this.operator = operator;
	}

	public ArrayList<String> getFieldsUsedInFilter() {
		return fieldsUsedInFilter;
	}

	public void setFieldsUsedInFilter(ArrayList<String> fieldsUsedInFilter) {
		this.fieldsUsedInFilter = fieldsUsedInFilter;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

}
