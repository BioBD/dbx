package entity;

import java.util.ArrayList;

import com.sun.org.apache.bcel.internal.generic.NEW;

public class Task {
	
	private int id;
	private String sqlText;
	private ArrayList<String> plan;
	private int captureCount;
	private int analyseCount;
	private String type;
	private ArrayList<IndexCandidate> indexCandidates = new ArrayList<IndexCandidate>(); 
	
	public Task(int id, String sqlText, ArrayList<String> plan, int captureCount,
			int analyseCount, String type) {
		super();
		this.id = id;
		this.sqlText = sqlText;
		this.plan = plan;
		this.captureCount = captureCount;
		this.analyseCount = analyseCount;
		this.type = type;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSqlText() {
		return sqlText;
	}

	public void setSqlText(String sqlText) {
		this.sqlText = sqlText;
	}

	public ArrayList<String> getPlan() {
		return plan;
	}

	public void setPlan(ArrayList<String> plan) {
		this.plan = plan;
	}

	public int getCaptureCount() {
		return captureCount;
	}

	public void setCaptureCount(int captureCount) {
		this.captureCount = captureCount;
	}

	public int getAnalyseCount() {
		return analyseCount;
	}

	public void setAnalyseCount(int analyseCount) {
		this.analyseCount = analyseCount;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public void addIndexCandidate(IndexCandidate indexCandidate) {
		this.indexCandidates.add(indexCandidate);
	}
	
	public ArrayList<IndexCandidate> getIndexCandidates() {
		return this.indexCandidates;
	}
	
	/* Checa se a Task tem um IndexCandidate com a tabela tableName e com todos os atributos em
	 * fields */
	public boolean containsIndexCandidate(String tableName, ArrayList<String> fields) {
		for(int i = 0; i<this.indexCandidates.size(); i++) {
			IndexCandidate currentIndexCandidate = this.indexCandidates.get(i);
			if(currentIndexCandidate.getTableName().equals(tableName) &&
					currentIndexCandidate.getColumns().size() == fields.size() &&
					currentIndexCandidate.getColumns().containsAll(fields)) {
				return true;
			}
		}
		return false;
	}
	
}
