package entity.DAO;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

import entity.Task;

import agents.WOAgent;


public class TaskDAO {

	private Connection connection;
	private String signatureToDifferentiate;
	
	public TaskDAO() throws IOException, SQLException, ClassNotFoundException {
		Properties parameters = getParameters();
		this.signatureToDifferentiate =  parameters.getProperty("signature");
		connect();
	}
	
	private Properties getParameters() throws IOException {
		Properties parameters = new Properties();
		parameters.load(WOAgent.class.getResourceAsStream("database.properties"));
		return parameters;
	}
	
	private void connect() throws SQLException, ClassNotFoundException, IOException {
		Properties parameters = getParameters();
		int database = Integer.parseInt(parameters.getProperty("database"));
		
		switch (database) {
		case 1:
			connectToOracle(parameters);
			break;
		case 2:
			connectToPostgres(parameters);
			break;
		case 3:
			connectToSqlServer(parameters);
			break;
		}
	}

	private void connectToSqlServer(Properties parameters) throws ClassNotFoundException, SQLException {
		String url = parameters.getProperty("urlSQLServer");
		String driver = parameters.getProperty("driverSQLServer");
		String user = parameters.getProperty("userSQLServer");
		String password = parameters.getProperty("pwdSQLServer");
		
		Class.forName(driver);
		this.connection = DriverManager.getConnection(url, user, password);
	}

	private void connectToPostgres(Properties parameters) throws ClassNotFoundException, SQLException {
		String url = parameters.getProperty("urlPostgres");
		String driver = parameters.getProperty("driverPostgres");
		String user = parameters.getProperty("userPostgres");
		String password = parameters.getProperty("pwdPostgres");
		
		Class.forName(driver);
		this.connection = DriverManager.getConnection(url, user, password);
	}

	private void connectToOracle(Properties parameters) throws SQLException, ClassNotFoundException {
		String url = parameters.getProperty("urlOracle");
		String driver = parameters.getProperty("driverOracle");
		String user = parameters.getProperty("userOracle");
		String password = parameters.getProperty("pwdOracle");
		
		Class.forName(driver);
		this.connection = DriverManager.getConnection(url, user, password);
	}
	
	private void checkConnection () throws SQLException, ClassNotFoundException, IOException {
		if(this.connection == null) {
			System.out.println("Connection null!!!");
			connect();
		}
	}
	
	//Funciona somente para o PG por causa do "agent." . Mudar depois o banco no PG pra ser gen�rico
	public ArrayList<Task> getObtainedWorkload() throws Exception {
		checkConnection();
		ArrayList<Task> obtainedWorkload = new ArrayList<Task>();
		String sqlClauseToGetTheObtainedWorkload = "select * from agent.tb_workload order by wld_id";
		Statement statement = this.connection.createStatement();
		ResultSet resultSet = statement.executeQuery(sqlClauseToGetTheObtainedWorkload);

		if(resultSet != null) {
			while(resultSet.next()) {
				int id = resultSet.getInt("wld_id");
				String sqlText = resultSet.getString("wld_sql");
				int captureCount = resultSet.getInt("wld_capture_count");
				int analyseCount = resultSet.getInt("wld_analyze_count");
				String type = resultSet.getString("wld_type");
				ArrayList<String> partitionedPlan = getPartitionedPlan(id);

				Task currentTask = new Task(id,sqlText,partitionedPlan,captureCount,analyseCount,type);
				obtainedWorkload.add(currentTask);
			}
		}
		this.connection.close();
		return obtainedWorkload;
	}
	
	public ArrayList<String> getPartitionedPlan( int queryId ) throws Exception {
		checkConnection();
		ResultSet resultSet =  null;
		Statement stmt = connection.createStatement();
		ArrayList<String> plan = new ArrayList<String>();
		String sql = signatureToDifferentiate + "select apl_text_line from agent.tb_access_plan where wld_id = "+ queryId +" order by apl_id_seq";
		resultSet = stmt.executeQuery( sql );
		if( resultSet != null ){
			while( resultSet.next() ){
				plan.add( resultSet.getString( "apl_text_line" ) );
			}
		}
		resultSet.close();
		stmt.close();
		return plan;
	}

}
