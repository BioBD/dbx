package entity.DAO;

import java.io.IOException;
import java.security.Policy.Parameters;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

import entity.IndexCandidate;
import entity.Task;


import agents.WOAgent;

public class IndexCandidateDAO {

    private Connection connection;
    private String signatureToDifferentiate;

    public IndexCandidateDAO() throws IOException, SQLException, ClassNotFoundException {
        Properties parameters = new Properties();
        parameters.load(WOAgent.class.getResourceAsStream("database.properties"));
        signatureToDifferentiate = parameters.getProperty("signature");
        int database = Integer.parseInt(parameters.getProperty("database"));
        switch (database) {
            case 1:
                connectToOracle(parameters);
                break;
            case 2:
                connectToPostgres(parameters);
                break;
            case 3:
                connectToSqlServer(parameters);
                break;
        }
    }

    private void connectToSqlServer(Properties parameters) throws ClassNotFoundException, SQLException {
        String url = parameters.getProperty("urlSQLServer");
        String driver = parameters.getProperty("driverSQLServer");
        String user = parameters.getProperty("userSQLServer");
        String password = parameters.getProperty("pwdSQLServer");

        Class.forName(driver);
        this.connection = DriverManager.getConnection(url, user, password);
    }

    private void connectToPostgres(Properties parameters) throws ClassNotFoundException, SQLException {
        String url = parameters.getProperty("urlPostgres");
        String driver = parameters.getProperty("driverPostgres");
        String user = parameters.getProperty("userPostgres");
        String password = parameters.getProperty("pwdPostgres");

        Class.forName(driver);
        this.connection = DriverManager.getConnection(url, user, password);
    }

    private void connectToOracle(Properties parameters) throws SQLException, ClassNotFoundException {
        String url = parameters.getProperty("urlOracle");
        String driver = parameters.getProperty("driverOracle");
        String user = parameters.getProperty("userOracle");
        String password = parameters.getProperty("pwdOracle");

        Class.forName(driver);
        this.connection = DriverManager.getConnection(url, user, password);
    }

    public void insertIndexCandidate(IndexCandidate indexCandidate, Task task) throws SQLException {
        String sqlClause = "insert into agent.tb_candidate_index(cid_id, cid_table_name, cid_index_profit, cid_status, cid_type)  "
                + "values (?,?,?,?,?)";
        PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClause);
        preparedStatement.setInt(1, indexCandidate.getId());
        preparedStatement.setString(2, indexCandidate.getTableName());
        preparedStatement.setInt(3, 0);
        preparedStatement.setString(4, indexCandidate.getStatus());
        preparedStatement.setString(5, indexCandidate.getType());

        preparedStatement.executeUpdate();
        insertIndexCandidateColumns(indexCandidate);
        insertTaskIndex(indexCandidate, task);
        preparedStatement.close();
    }

    public void insertTaskIndex(IndexCandidate indexCandidate, Task task) throws SQLException {
        String sqlClause = "insert into agent.tb_task_indexes(wld_id, cid_id) values (?,?)";
        PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClause);
        preparedStatement.setInt(1, task.getId());
        preparedStatement.setInt(2, indexCandidate.getId());

        preparedStatement.executeUpdate();
        preparedStatement.close();
    }

    public void insertIndexCandidateColumns(IndexCandidate indexCandidate) throws SQLException {
        String sqlClause = "insert into agent.tb_candidate_index_column(cid_id, cic_column_name) values (?,?)";
        PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClause);
        ArrayList<String> columns = indexCandidate.getColumns();

        preparedStatement.setInt(1, indexCandidate.getId());
        for (int i = 0; i < columns.size(); i++) {
            preparedStatement.setString(2, columns.get(i));
            preparedStatement.executeUpdate();
        }
        preparedStatement.close();
    }

    public void updateProfit(IndexCandidate indexCandidate) throws SQLException {
        int indexId = getIndexId(indexCandidate);
        int currentIndexProfit = getIndexProfit(indexId);
        String sqlClause = "update agent.tb_candidate_index set cid_index_profit = ? where cid_id = ? ";
        PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClause);

        preparedStatement.setInt(1, currentIndexProfit + indexCandidate.getProfit());
        preparedStatement.setInt(2, indexId);

        preparedStatement.executeUpdate();
        preparedStatement.close();
    }
    
        public void updateStatus(IndexCandidate indexCandidate) throws SQLException {
        int indexId = getIndexId(indexCandidate);
        int currentIndexProfit = getIndexProfit(indexId);
        String sqlClause = "update agent.tb_candidate_index set cid_status = ? where cid_id = ? ";
        PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClause);

        preparedStatement.setString(1, indexCandidate.getStatus());
        preparedStatement.setInt(2, indexId);

        preparedStatement.executeUpdate();
        preparedStatement.close();
    }

    public int getIndexProfit(int id) throws SQLException {
        String sqlClause = "select cid_index_profit from agent.tb_candidate_index where cid_id = ?";
        PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClause);
        int indexProfit = -1;

        preparedStatement.setInt(1, id);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            indexProfit = resultSet.getInt("cid_index_profit");
        }
        preparedStatement.close();
        return indexProfit;
    }

    public boolean indexBelongsToLocalMetabase(IndexCandidate indexCandidate) throws SQLException {
        if (getIndexId(indexCandidate) > 0) {
            return true;
        }
        return false;
    }

    public int getIndexId(IndexCandidate indexCandidate) throws SQLException {
        String tableName = indexCandidate.getTableName();
        String type = indexCandidate.getType();
        ArrayList<String> columns = indexCandidate.getColumns();

        String sqlClause = "select cid_id , cid_table_name, cid_type from agent.tb_candidate_index";
        Statement statement = this.connection.createStatement();
        ResultSet resultSet = statement.executeQuery(sqlClause);
        while (resultSet.next()) {
            if (resultSet.getString("cid_table_name").equals(tableName)
                    && resultSet.getString("cid_type").equals(type)) {
                int id = resultSet.getInt("cid_id");
                if (indexHasTheSameColumns(id, columns)) {
//					this.connection.close();
//					statement.close();
                    return id;
                }
            }
        }
//		this.connection.close();
//		statement.close();
        return -1;
    }

    public boolean indexHasTheSameColumns(int id, ArrayList<String> columns) throws SQLException {
        ArrayList<String> columnsResultSet = new ArrayList<String>();
        String sqlClause = "select cid_id , cic_column_name from agent.tb_candidate_index_column where cid_id = " + id;
        Statement statement = this.connection.createStatement();
        ResultSet resultSet = statement.executeQuery(sqlClause);

        while (resultSet.next()) {
            columnsResultSet.add(resultSet.getString("cic_column_name").trim());
        }
        if (columnsResultSet.size() == columns.size() && columnsResultSet.containsAll(columns)) {
            return true;
        }
        return false;
    }

    public ArrayList<IndexCandidate> getIndexCandidateBelongsToTask(int taskId) throws SQLException {
        ArrayList<IndexCandidate> indexCandidates = new ArrayList<IndexCandidate>();

        String sqlClause = signatureToDifferentiate + "select ci.cid_id, cid_table_name , cid_index_profit , cid_status , cid_type"
                + " from agent.tb_candidate_index ci, agent.tb_task_indexes ti"
                + " where ci.cid_id = ti.cid_id and ti.wld_id = ?;";
        PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClause);
        preparedStatement.setInt(1, taskId);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            int id = resultSet.getInt("cid_id");
            String tableName = resultSet.getString("cid_table_name");
            int indexProfit = resultSet.getInt("cid_index_profit");
            String status = resultSet.getString("cid_status");
            String type = resultSet.getString("cid_type");
            ArrayList<String> columns = getColumnsBelongsToIndexCandidate(id);
            
            IndexCandidate indexCandidate = new IndexCandidate(id, tableName, indexProfit, status, type, columns);
            indexCandidates.add(indexCandidate);
        }
        return indexCandidates;
    }

    public ArrayList<IndexCandidate> getAllIndexCandidates() throws SQLException {
        ArrayList<IndexCandidate> indexCandidates = new ArrayList<IndexCandidate>();

        String sqlClause = signatureToDifferentiate + "select cid_id, cid_table_name , cid_index_profit , cid_status , cid_type"
                + " from agent.tb_candidate_index";
        PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClause);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            int id = resultSet.getInt("cid_id");
            String tableName = resultSet.getString("cid_table_name");
            int indexProfit = resultSet.getInt("cid_index_profit");
            String status = resultSet.getString("cid_status");
            String type = resultSet.getString("cid_type");
            ArrayList<String> columns = getColumnsBelongsToIndexCandidate(id);
            IndexCandidate indexCandidate = new IndexCandidate(id, tableName, indexProfit, status, type,columns);
            indexCandidates.add(indexCandidate);
        }
        return indexCandidates;
    }

    public ArrayList<String> getColumnsBelongsToIndexCandidate(int indexId) throws SQLException {
        ArrayList<String> columns = new ArrayList<String>();
        String sqlClause = "select cic_column_name"
                + " from agent.tb_candidate_index_column"
                + " where cid_id = ?;";
        PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClause);
        preparedStatement.setInt(1, indexId);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            String currentColumn = resultSet.getString("cic_column_name").trim();
            columns.add(currentColumn);
        }
        return columns;
    }
    
    public ArrayList<IndexCandidate> getAllRealIndexes () throws SQLException {
        ArrayList<IndexCandidate> allRealIndexCandidates = new ArrayList<IndexCandidate>();

        String sqlClause = signatureToDifferentiate + "select cid_id, cid_table_name , cid_index_profit , cid_status , cid_type"
                + " from agent.tb_candidate_index where cid_status = ?";
        PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClause);
        preparedStatement.setString(1,"R");
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            int id = resultSet.getInt("cid_id");
            String tableName = resultSet.getString("cid_table_name");
            int indexProfit = resultSet.getInt("cid_index_profit");
            String status = resultSet.getString("cid_status");
            String type = resultSet.getString("cid_type");
            ArrayList<String> columns = getColumnsBelongsToIndexCandidate(id);
            IndexCandidate indexCandidate = new IndexCandidate(id, tableName, indexProfit, status, type,columns);
            allRealIndexCandidates.add(indexCandidate);
        }
        return allRealIndexCandidates;
    }

    public int getNumberOfPrimaryIndexOnTable(String tableName) throws SQLException {
        int numberOfPrimaryIndexOnTable = -1;
        String sqlClause = "select count(cid_id)"
                + " from agent.tb_candidate_index"
                + " where cid_table_name = ? AND cid_type = '1';";
        PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClause);
        preparedStatement.setString(1, tableName);
        ResultSet resultSet = preparedStatement.executeQuery();
        if (resultSet.next()) {
            numberOfPrimaryIndexOnTable = resultSet.getInt("count");
        }
        return numberOfPrimaryIndexOnTable;
    }
    
    public ArrayList<String> getTablesWithClusteredIndex() throws SQLException {
        ArrayList<String> tableNames = new ArrayList<String>();
        String sqlClause = "select relname as table from pg_class join pg_index on pg_class.oid = pg_index.indrelid "
                + "where indisclustered = 't'; ";
        Statement statement = this.connection.createStatement();
        ResultSet resultSet = statement.executeQuery(sqlClause);
        while(resultSet.next()) {
            String tableName = resultSet.getString("table");
            tableNames.add(tableName);
        }
        return tableNames;
    }
}
