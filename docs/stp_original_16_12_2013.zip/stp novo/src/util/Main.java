package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import agents.postgres.PostgresObserver;
import agents.postgres.PostgresPredictor;
import agents.postgres.PostgresReactor;

import drivers.Util;
import drivers.postgres.PostgreSqlSADriver;
import entity.DAO.IndexCandidateDAO;
import entity.IndexCandidate;
import entity.SeqScan;
import entity.SeqScanWithFilter;
import entity.Task;
import entity.DAO.TaskDAO;
import facade.IndexCandidateFacade;
import facade.SelectedIndexesFacade;

public class Main {
	public static void main(String args[]) throws Exception {

		PostgreSqlSADriver pgsa = new PostgreSqlSADriver();
		PostgresObserver pgobserver = new PostgresObserver();
                PostgresReactor pgreactor = new PostgresReactor();
                IndexCandidateDAO indexCandidateDAO = new IndexCandidateDAO();
		TaskDAO taskDAO = new TaskDAO();
		
		ArrayList<Task> a = taskDAO.getObtainedWorkload();

                SelectedIndexesFacade sif = new SelectedIndexesFacade();
		ArrayList<IndexCandidate> selectedIndexCandidates = sif.getSelectedIndexCandidates(5000);
                pgreactor.updateIndexStructuresConfiguration(selectedIndexCandidates, 1);
	}
	
	
}
