package util;

import java.util.Properties;

import agents.WOAgent;

public class Log {
	protected Properties properties = null;
	protected boolean debug = true;
	
	public Log(){
		try{
			properties = new Properties();
			properties.load(WOAgent.class.getResourceAsStream("database.properties"));
	        debug 		  = Boolean.parseBoolean( this.properties.getProperty( "debug" ));
		} catch( Exception e ){
			System.out.println( e.getMessage() );
		}
		
	}
	
	public void write( String msg ){
		if( debug ){
			System.out.println( msg );
		}
	}
	
	public void write( Exception e ){
		System.out.println( e.getMessage() );
		if( debug ){
			e.printStackTrace();
		}
	}
}
