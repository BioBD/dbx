package drivers;

/**
 * @author Jos� Maria
 * 
 * Classe usada para representar "Driver for Workload Obtainment"
 * Respons�vel por capturar a carga de trabalho submetida ao SBD
 */
public interface WADriver {
	/**
	 * M�todo usado para capturar a carga de trabalho submetida ao SBD
	 */
	public void getLastExecutedQueries()throws Exception;
}
