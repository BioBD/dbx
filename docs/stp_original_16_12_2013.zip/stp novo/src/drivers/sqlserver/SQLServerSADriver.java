package drivers.sqlserver;

import agents.WOAgent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import drivers.SADriver;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import util.Log;

/**
 * @author Jos� Maria Classe usada para representar "Driver for Statistics
 * Access" no SQLServer Respons�vel por obter as informa��eses estats�ticas de
 * um determinado banco de dados SQLServer
 */
public class SQLServerSADriver implements SADriver {

    protected String signature = null;
    /**
     * vari�vel boolean indica se o programa est� rodando em modo debug ou n�o *
     */
    protected boolean debug = true;
    /**
     * vari�vel utilizada para manipular logs *
     */
    protected Log log = null;
    /*vari�vel que representa uma inst�ncia de PostgreSqlSADriver */
    private static SQLServerSADriver instance;

    public SQLServerSADriver() {
        log = new Log();
        try {
            connect();
        } catch (SQLException e) {
            log.write(e);
        } catch (ClassNotFoundException e) {
            log.write(e);
        } catch (Exception e) {
            log.write(e);
        }
    }

    public Connection connect() throws IOException, ClassNotFoundException, SQLException {
        Properties properties = new Properties();
        properties.load(WOAgent.class.getResourceAsStream("database.properties"));
        signature = properties.getProperty("signature");
        String driver = properties.getProperty("driverSQLServer");
        String url = properties.getProperty("urlSQLServer");
        String user = properties.getProperty("userSQLServer");
        String passwd = properties.getProperty("pwdSQLServer");
        Class.forName(driver);
        Connection connection = DriverManager.getConnection(url, user, passwd);
        return connection;
    }

    /**
     * M�todo que retorna o numeroLinhas
     *
     * @param tableName Nome da tabela
     * @return numeroLinhas
     */
    public int getRowsNumber(String tableName) throws SQLException, IOException, ClassNotFoundException {
        Connection connection = connect();
        ResultSet resultSet = null;
        int numeroLinhas = 0;

        try {
            String sqlClause = "select i.rows as linhas from sysobjects T "
                    + "join sysindexes I on I.id=T.id "
                    + "WHERE T.NAME='"+tableName+"' AND T.TYPE='U' AND I.INDID<=1;";

            Statement statement = connection.createStatement();
            resultSet = statement.executeQuery(sqlClause);
            resultSet.next();
            numeroLinhas = resultSet.getInt("linhas");
        } catch (SQLException e) {
            log.write(e);
        } catch (NullPointerException e) {
            log.write(e);
        } catch (Exception e) {
            log.write(e);
        }
        connection.close();
        return numeroLinhas;
    }

    /**
     * M�todo que retorna o numeroBlocos
     *
     * @param tableName Nome da tabela
     * @return numeroBlocos
     */
    public int getBlocksNumber(String tableName) throws SQLException, IOException, ClassNotFoundException {
        Connection connection = connect();
        ResultSet resultSet = null;
        int numeroBlocos = 0;
        try {
            String sqlClause = "SELECT I.DPAGES as num_paginas FROM SYSOBJECTS T JOIN  SYSINDEXES I ON I.ID=T.ID WHERE T.NAME='"+tableName+"' AND T.TYPE='U' AND I.INDID<=1";
            Statement statement = connection.createStatement();
            resultSet = statement.executeQuery(sqlClause);
            if (resultSet.next()) {
                numeroBlocos = resultSet.getInt("num_paginas");
            }
        } catch (SQLException e) {
            log.write(e);
        } catch (NullPointerException e) {
            log.write(e);
        } catch (Exception e) {
            log.write(e);
        }
        connection.close();
        return numeroBlocos;
    }

    /**
     * M�todo que retorna o nomeIndice
     *
     * @param tableName Nome da tabela
     * @return ArrayList
     */
    public List<String> getIndexName(String tableName) {
        return new ArrayList<String>();
    }

    /**
     * M�todo que retorna a alturaArvore
     *
     * @param indexName Nome do indice
     * @return alturaArvore
     */
    public int getDeepTree(String indexName) {
        return 1;
    }

    /**
     * M�todo que retorna o n�mero de blocos (numeroBlocos) de uma determinada
     * tabela passada como par�metro no SQLServer.
     *
     * @param schemaName nome do schema
     * @param tableName nome da tabela (da qual se deseja obter o n�mero de
     * linhas)
     * @return numeroBlocos n�mero de blocos (p�ginas de dados) da tabela
     * passada como par�metro (tableName)
     */
    public int getBlocksNumber(String scemaName, String tableName) {
        // TODO Auto-generated method stub
        return 0;
    }

    /**
     * M�todo utilizado para verificar se um determinado �ndice existe no
     * SQLServer
     *
     * @param schemaName nome do schema
     * @param tableName nome da tabela
     * @param collumnName nome das colunas que comp�em o �ndice
     * @return true se o �ndice existe e false se o �ndice n�o existe
     */
    public boolean indexExist(String schemaName, String tableName, String[] collumnName) {
        // TODO Auto-generated method stub
        return false;
    }

    /**
     * M�todo utilizado para recuperar as �ltimas consultas executadas e ainda
     * n�o avaliadas no SQLServer
     *
     * @return ArrayList contendo o texto (SQL) das consultas capturadas pelo
     * WOAgent e ainda n�o analizadas pelo FISAgent
     */
    public ArrayList getQueryList() throws Exception {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * M�todo utilizado para recuperar o plano de execu��o para uma determinada
     * cl�usula SQL fornecida como par�metro (queryId) no SQLServer
     *
     * @param queryId identificador de uma determinada cl�usula SQL
     * @return ArrayList contendo o plano de execu��o para a cl�usula SQL
     * fornecida como par�metro (queryId)
     */
    public ArrayList getPartitionedPlan(String queryId) throws Exception {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * M�todo utilizado para verificar se um determinado campo (coluna) de uma
     * determinada tabela � chave prim�ria no SQLServer
     *
     * @param tableName nome da tabela
     * @param columnName nome da coluna (atributo)
     * @return true se o atributo columnName for chave prim�ria de tableName e
     * false caso contr�rio
     */
    public boolean isPrimaryKey(String tableName, ArrayList<String> columnName) throws Exception {
        // TODO Auto-generated method stub
        return false;
    }

    /**
     * M�todo utilizado para recuperar o n�mero de linhas (tuplas) de uma
     * determinada tabela (passada como par�metro) no SQLServer
     *
     * @param schemaName nome do schema
     * @param tableName nome da tabela
     * @return quantidade de linhas (tulas) da tabela tableName
     */
    public int getTableRowCount(String schemaname, String tableName) throws Exception {
        // TODO Auto-generated method stub
        return 0;
    }

    /**
     * M�todo utilizado para recuperar o tipo de uma express�o SQL (Tarefa)
     *
     * @param wldId id da express�o SQL (tarefa)
     * @return tipo da express�o SQL (Tarefa)
     */
    public String getTaskType(int wldId) {
        return null;
    }

    /**
     * M�todo utilizado para recuperar a quantidade de vezes que uma express�o
     * SQL (Tarefa) foi capturada e ainda n�o analisada
     *
     * @param wldId id da express�o SQL (tarefa)
     * @return quantidade de vezes que uma express�o SQL (Tarefa) foi capturada
     * e ainda n�o analisada
     */
    public int getWldQtd(int wldId) {
        return -1;
    }

    /**
     * M�todo utilizado para recuperar o maior benef�cio acumulado dentre todos
     * os �ndices candidatos (existentes na MetaBase Local) definidos sobre a
     * tabela passada como par�metro
     *
     * @param tableName nome da tabela
     * @return maior benef�cio acumulado dentre todos os �ndices candidatos
     * (existentes na MetaBase Local) definidos sobre a tabela passada como
     * par�metro
     */
    public int getBestPrimaryIndexProfit(String tableName) {
        return -1;
    }

    /**
     * M�todo utilizado para verificar se existe algum �ndice candidato (na
     * MetaBase Local), em estado real (status = "R") definido sobre a tabela
     * passada como par�metro
     *
     * @param tableName nome da tabela
     * @return valor booleano indicando se existe algum �ndice candidato (na
     * MetaBase Local), em estado real (status = "R") definido sobre a tabela
     * passada como par�metro
     */
    public boolean existRealPrimaryIndex(String tableName) {
        return true;
    }

    /**
     * M�todo utilizado para recuperar o nome do �ndice candidato prim�rio, cujo
     * estado seja real (status = "R"), definido sobre a tabela passada como
     * par�metro(na MetaBase Local)
     *
     * @param tableName nome da tabela
     * @return indexName nome do �ndice
     */
    public String getRealPrimaryIndexName(String tableName) {
        return null;
    }

    /**
     * M�todo utilizado para recuperar o id (identificador) de um �ndice
     * candidato (armazenado na MetaBase Local)
     *
     * @param tableName nome da tabela
     * @param field ArrayList contendo as colunas (campos) que comp�em o �ndice
     * @param type Tipo do �ndice (Prim�rio (C-Clustering) ou Secund�rio
     * (U-Unclustering))
     * @return identificado do �ndice
     */
    public int getIndexIdLM(String tableName, ArrayList<String> field, String type) throws SQLException {
        return -1;
    }

    /**
     * M�todo utilizado para verificar se um determinado �ndice real existente
     * no PostgreSQL � prim�rio (clusterizado)
     *
     * @param schemaName nome do Schema
     * @param tableName nome da tabela
     * @param fields ArrayList contendo as colunas (campos) que comp�em o �ndice
     * @return valor booleano indicando se o �ndice, cujos dados passados por
     * par�metro, existe no PostgreSQL e est� clusterizado
     */
    public boolean isClustered(String schemaName, String tableName, ArrayList<String> fields) {
        return true;
    }

    /**
     * M�todo utilizado para recuperar o nome de um �ndice real (nome f�sico do
     * �ndice)
     *
     * @param schemaName nome do Schema
     * @param tableName nome da tabela
     * @param fields ArrayList contendo as colunas (campos) que comp�em o �ndice
     * @return Nome do �ndice (como criado fisicamente no PostgreSQL)
     */
    public String getIndexName(String schemaName, String tableName, ArrayList<String> fields) {
        return null;
    }

    /**
     * M�todo utilizado para atualizar a quantidade de vezes que a express�o SQL
     * foi analisada
     *
     * @param wldId Id da express�o SQL do Schema
     */
    public void updateWldAnalyzeCount(int wldId) {
    }

    @Override
    public ArrayList getPartitionedPlan(int queryId) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public static void main(String[] args) {
        SQLServerSADriver sql = new SQLServerSADriver();
        try {
            System.out.println(sql.getBlocksNumber("lineitem"));
        } catch (SQLException ex) {
            Logger.getLogger(SQLServerSADriver.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(SQLServerSADriver.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SQLServerSADriver.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
