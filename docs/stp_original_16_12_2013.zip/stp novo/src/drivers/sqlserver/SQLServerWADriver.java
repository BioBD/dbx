package drivers.sqlserver;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

import util.Log;

import agents.WOAgent;

import drivers.Util;
import drivers.WADriver;
import java.util.Iterator;

/**
 * @author José Maria Lucas Lemos
 *
 * Classe usada para representar o "Driver for Workload Obtainment"no SQLServer
 * Responsável por obter a carga de trabalho (Cláusula SQL + Plano de execução +
 * Custo) das consultas submetidas ao SQL Server
 */
public class SQLServerWADriver implements WADriver {

    private String userName;
    private String password;
    private String urlAdress;
    private String driver;
    private Connection connection = null;
    private Properties propertiesFile;
    private String signatureToDifferentiate = null;
    /**
     * variï¿½vel utilizada para controlar o reset do valor de sum(usecounts) da
     * metabase do SQL Server*
     */
    private static int lastCapturedCount = 0;
    private boolean isTheFirstExecution = true;

    public SQLServerWADriver() {
        try {
            loadProperties();
        } catch (IOException e) {
            // TODO Auto-generated catch block
        }
        try {
            connect();
        } catch (ClassNotFoundException e) {
            System.out.println(e);
            // TODO Auto-generated catch block
        } catch (SQLException e) {
            System.out.println(e);
            // TODO Auto-generated catch block

        }
    }

    public void loadProperties() throws IOException {
        propertiesFile = new Properties();
        propertiesFile.load(WOAgent.class.getResourceAsStream("database.properties"));
        signatureToDifferentiate = this.propertiesFile.getProperty("signature");
        driver = this.propertiesFile.getProperty("driverSQLServer");
        urlAdress = this.propertiesFile.getProperty("urlSQLServer");
        userName = this.propertiesFile.getProperty("userSQLServer");
        password = this.propertiesFile.getProperty("pwdSQLServer");
    }

    public void connect() throws ClassNotFoundException, SQLException {
        Class.forName(driver);
        this.connection = DriverManager.getConnection(urlAdress, userName, password);
    }

    public void closeConnection() throws SQLException {
        this.connection.close();
    }

    public void getLastExecutedQueries() throws SQLException {
        ResultSet queryData = null;
        ArrayList<String> partitionedPlan = null;
        ResultSet capturedQueries = captureQueries();

        /* Percorre as consultas capturadas */
        while (capturedQueries.next()) {
            //Recupera a próxima consulta capturada
            String currentQuery = capturedQueries.getString("sql");
            int useCounts = capturedQueries.getInt("usecounts");
            if (!isQueryGeneratedByDBMS(currentQuery)) {
                
                partitionedPlan = getPartitionedPlan(currentQuery);
                String planJoined = joinPlanParts(partitionedPlan);

                if (isQueryAlreadyCaptured(currentQuery)) {
                    updateQueryData(currentQuery, useCounts);
                } else {
                    System.out.println(currentQuery);
                    insertQuery(currentQuery, planJoined, useCounts);
                    queryData = getQueryData(currentQuery);
                    int queryId = queryData.getInt("wld_id");
                    insertPartitionedQueryPlan(queryId, partitionedPlan);
                }
            }
            if (queryData != null) {
                queryData.close();
            }
        }
    }

    private ResultSet captureQueries() throws SQLException {
        ResultSet resultSet = null;
        Statement statement = this.connection.createStatement();
        //ArrayList<String> capturedQuerys = new ArrayList<String>();

        String sqlClauseToCaptureTheWorkload = signatureToDifferentiate
                + " SELECT UPPER(REPLACE(REPLACE(REPLACE(sql, CHAR(13), ' '), CHAR(10), ' '), ' ', ' ')) AS sql, sum(usecounts) as usecounts"
                + " FROM master.dbo.syscacheobjects"
                + " WHERE cacheobjtype='Compiled Plan' and sql like 'SELECT%'"
                + " GROUP BY UPPER(REPLACE(REPLACE(REPLACE(sql, CHAR(13), ' '), CHAR(10), ' '), ' ', ' '));";
        resultSet = statement.executeQuery(sqlClauseToCaptureTheWorkload);

        /*if (resultSet != null) {
         resultSet.next();
         }*/
        

        return resultSet;
    }

    public boolean isQueryGeneratedByDBMS(String query) throws SQLException {
//		if ( (!query.equals("<command string not enabled>") ) && ( !query.contains(signatureToDifferentiate) ) && (!query.toUpperCase().contains("SYS")) ) {
//			return false;
//		}
//		return true;
        boolean flag = true;

        ArrayList<String> tables = new ArrayList<String>();
        tables = tableNames();
        
        for (Iterator<String> it = tables.iterator(); it.hasNext();) {
            String string = it.next();
           
            String partQuery = ("from " + string.toUpperCase()).toUpperCase();
            if (query.contains(partQuery)) {

                //System.out.println(query);
                //System.out.println("+++++++++++++++++" + string + "+++++++++++++++++");
                flag = false;
            }
        }
        return flag;
    }

    public ArrayList<String> tableNames() throws SQLException {
        ResultSet resultset = null;
        Statement statement = this.connection.createStatement();
        ArrayList<String> tables = new ArrayList<String>();

        String sqlTableNames = "Select distinct table_name as tabela from INFORMATION_SCHEMA.COLUMNS where TABLE_CATALOG = 'TPC-H';";

        resultset = statement.executeQuery(sqlTableNames);
        while (resultset.next()) {

            String tableAux = resultset.getString("tabela");
            tables.add(tableAux);
        }
        resultset.close();
        statement.close();
        //lista de strings com o nome das tabelas do 
        return tables;
    }

    /**
     * Mï¿½todo usado para verificar se uma determinada consulta (passada como
     * parï¿½metro) jï¿½ havia sido anteriormente recuperada
     *
     * @param query consulta SQL
     * @return true se a clï¿½usula SQL query jï¿½ tiver sido anteriorente
     * capturada, false caso contrï¿½rio
     */
    private boolean isQueryAlreadyCaptured(String query) throws SQLException {
        ResultSet resultset = null;
        String sqlClause = "select wld_id from tb_workload where wld_sql = ?";
        PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClause);
        //String queryWithinQuotes = query.replace("'", "\"");

        //String sqlClause = signatureToDifferentiate + 
        //" select wld_id from tb_workload where wld_sql = '" + queryWithinQuotes + "'";

        //System.out.println(sqlClause);

        preparedStatement.setString(1, query);
        resultset = preparedStatement.executeQuery();

        if (resultset.next()) {
            //System.out.println("query already captured......");
           // System.out.println(query);
            resultset.close();
            preparedStatement.close();
            return true;
        } else {
            resultset.close();
            preparedStatement.close();
            return false;
        }
    }

    /**
     * Método usado para recuperar o plano de consulta (execução) para uma
     * determinada cláusula SQL (fornecida como parâmetro) em uma única String
     *
     * @param planParts plano de execuï¿½ï¿½o gerado (de forma particionada,
     * linha a linha)
     * @return plano de execuï¿½ï¿½o unificado (ou seja, em uma ï¿½nica String)
     */
    private String joinPlanParts(ArrayList<String> planParts) {
        String planJoined = "";

        int numberOfPlansRows = planParts.size();
        for (int i = 0; i < numberOfPlansRows; i++) {
            planJoined += planParts.get(i);
        }
        return planJoined;
    }

    /**
     * Mï¿½todo usado para recuperar os dados de um elemento da carga de
     * trabalho armazenado na meta-base
     *
     * @param query consulta SQL (ou seja, elemento da carga de trabalho do qual
     * se deseja recuperar os dados)
     * @return ResultSet contendo os dados requisitados so elemento da carga de
     * trabalho recebido como parï¿½metro
     */
    private ResultSet getQueryData(String query) throws SQLException {
        ResultSet resultset = null;
        String sqlClauseToGetQueryData = signatureToDifferentiate + "select wld_id, wld_sql, wld_plan, wld_capture_count, wld_analyze_count, wld_last_usecounts from tb_workload where wld_sql = ?";
        PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClauseToGetQueryData);

        preparedStatement.setString(1, query);
        resultset = preparedStatement.executeQuery();

        if (resultset != null) {
            resultset.next();
        }

        return resultset;
    }

    /**
     * Mï¿½todo usado para recuperar o plano de consulta (execuï¿½ï¿½o) para uma
     * determinada clï¿½usula SQL (fornecida como parï¿½metro)
     *
     * @param query Clï¿½usula SQL (cujo plano de execuï¿½ï¿½o serï¿½ retornado)
     * @return ArrayList contendo o plano de execuï¿½ï¿½o para a consulta
     * fornecida como parï¿½metro
     */
    @SuppressWarnings("unchecked")
    private ArrayList<String> getPartitionedPlan(String query) throws SQLException {
        ResultSet resultset = null;
        Statement statement = this.connection.createStatement();
        //Armazena o plano de execução da consulta (de forma particionada, linha por linha)
        ArrayList<String> partitionedPlan = new ArrayList<String>();

        //Torna SHOWPLAN_TEXT ON e depois submete a consulta, tendo como retorno o seu plano
        statement.execute(signatureToDifferentiate + "SET SHOWPLAN_TEXT OFF");
        statement.execute(signatureToDifferentiate + "SET SHOWPLAN_TEXT ON");

        statement.executeQuery(signatureToDifferentiate + query);
        if (!((statement.getMoreResults() == false) && (statement.getUpdateCount() == -1))) {
            resultset = statement.getResultSet();
            while (resultset.next()) {
                partitionedPlan.add(resultset.getString(1));
                //System.out.println(resultset.getString(1));
            }
        }
        //System.out.println(query);
        //System.out.println(partitionedPlan.size());
        statement.execute(signatureToDifferentiate + "SET SHOWPLAN_TEXT OFF");

        resultset.close();
        statement.close();
        return partitionedPlan;
    }

    /**
     * Mï¿½todo usado para remover o plano de execuï¿½ï¿½o de uma determinada
     * clï¿½usula SQL da meta-base
     *
     * @param queryId identificador da clï¿½usula SQL
     */
    private void deletePartitionedQueryPlan(int queryId) throws SQLException {
        Statement statement = this.connection.createStatement();
        String sqlClauseToDeletePartitionedPlan = signatureToDifferentiate + "delete from tb_access_plan where wld_id = " + queryId;
        statement.executeUpdate(sqlClauseToDeletePartitionedPlan);
        statement.close();
    }

    /**
     * Método usado para cadastrar o plano de execução de uma determinada
     * cláusula SQL na meta-base de forma quebrada(linha por linha)
     *
     * @param queryId identificador da cláusula SQL
     * @param partitionedPlan ArrayList contendo as partes que compï¿½em o plano
     * de execução (na forma de uma ï¿½rvore de execuï¿½ï¿½o)
     */
    private void insertPartitionedQueryPlan(int queryId, ArrayList<String> partitionedPlan) throws SQLException {
        int numberOfPlansRows = partitionedPlan.size();

        //Insere o plano quebrado, linha a linha, na metabase
        for (int i = 0; i < numberOfPlansRows; i++) {
            String sqlClauseToInsertPartitionedPlan = signatureToDifferentiate + " insert into tb_access_plan ( wld_id, apl_id_seq, apl_text_line ) values (?,?,?)";
            PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClauseToInsertPartitionedPlan);

            preparedStatement.setInt(1, queryId);
            preparedStatement.setInt(2, i);
            preparedStatement.setString(3, partitionedPlan.get(i));

            preparedStatement.executeUpdate();
            preparedStatement.close();
        }
    }

    /**
     * Mï¿½todo usado para cadastrar uma determinada consulta, juntamente com o
     * seu plano de execuï¿½ï¿½o, na meta-base
     *
     * @param query consulta SQL
     * @param plan plano de execuï¿½ï¿½o gerado pelo otimizador para a
     * clï¿½usula SQL query
     */
    private void insertQuery(String query, String plan, int useCounts) throws SQLException {
        int nextId = getNextId();
        String queryType = null;

        if (Util.retiraAspas(query).toUpperCase().startsWith("SELECT")) {
            queryType = "Q";
        } else if (Util.retiraAspas(query).toUpperCase().startsWith("UPDATE")) {
            queryType = "U";
        }

        //System.out.println(query);

        String sqlClauseToInsertQuery = signatureToDifferentiate + "insert into tb_workload ( wld_id, wld_sql, wld_plan, wld_capture_count, wld_analyze_count, wld_type ) values (?,?,?,?,?,?)";
        PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClauseToInsertQuery);

        preparedStatement.setInt(1, nextId);
        preparedStatement.setString(2, query);
        preparedStatement.setString(3, plan);
        preparedStatement.setInt(4, useCounts);
        preparedStatement.setInt(5, 0);
        preparedStatement.setString(6, queryType);

        preparedStatement.executeUpdate();
    }

    public void updateQueryData(String query, int useCounts) throws SQLException {
        ResultSet queryData = getQueryData(query);
        int queryId = queryData.getInt("wld_id");
        int totalNumberOfCaptures = getTotalNumberOfCaptures(query, useCounts);

        ArrayList<String> partitionedPlan = getPartitionedPlan(query);
        String planJoined = joinPlanParts(partitionedPlan);
        String storedPlan = queryData.getString("wld_plan");

        if (!isCurrentPlanEqualsStoredPlan(planJoined, storedPlan)) {
            deletePartitionedQueryPlan(queryId);
            insertPartitionedQueryPlan(queryId, partitionedPlan);
        }

        String sqlUpdate = signatureToDifferentiate
                + "update tb_workload set wld_capture_count = ?, wld_plan = ? where wld_id =?";

        PreparedStatement preparedStatement = this.connection.prepareStatement(sqlUpdate);
        preparedStatement.setInt(1, totalNumberOfCaptures);
        preparedStatement.setString(2, planJoined);
        preparedStatement.setInt(3, queryId);

        preparedStatement.executeUpdate();
    }

    public int getTotalNumberOfCaptures(String query, int useCounts) throws SQLException {
        ResultSet resultSet = getQueryData(query);
        int totalNumberOfCaptures = resultSet.getInt("wld_capture_count");
        int currentUseCount = useCounts;
        int lastUseCount = resultSet.getInt("wld_last_usecounts");
        int queryId = resultSet.getInt("wld_id");

        if (currentUseCount >= totalNumberOfCaptures) {
            totalNumberOfCaptures += (useCounts - lastUseCount);
        } else {
            if (lastUseCount > useCounts) {
                totalNumberOfCaptures += useCounts;
            } else {
                totalNumberOfCaptures += (useCounts - lastUseCount);
            }
        }
        updateLastUseCount(useCounts, queryId);
        return totalNumberOfCaptures;
    }

    private void updateLastUseCount(int useCounts, int queryId) throws SQLException {
        String sqlClause = "update tb_workload set wld_last_usecounts = " + useCounts + "where wld_id = " + queryId;
        Statement statement = this.connection.createStatement();
        statement.executeUpdate(sqlClause);
        statement.close();
    }

    public boolean isCurrentPlanEqualsStoredPlan(String currentPlan, String storedPlan) {
        return storedPlan.equals(currentPlan);
    }

    private int getNextId() throws SQLException {
        int nextId = 0;
        Statement statement = this.connection.createStatement();
        String sqlClauseToGetNextId = signatureToDifferentiate + "SELECT MAX(wld_id) as maxId FROM tb_workload";
        ResultSet resultset = statement.executeQuery(sqlClauseToGetNextId);

        if (resultset.next()) {
            nextId = resultset.getInt("maxId");
        }
        nextId++;
        return nextId;
    }
}
