package drivers.sqlserver;

import java.sql.SQLException;
import java.util.ArrayList;

import drivers.UDDriver;

/**
 * @author Jos� Maria
 * 
 * Classe usada para representar "Driver for DBMS Update"
 * Responsvel pela criao e remoo de ndices
 */
public class SQLServerUDDriver implements UDDriver {
	
	
	/**
	 * M�todo usado para criar um �ndice em uma determinada tabela
	 * @param tableName Nome da tabela a ser indexada.
	 * @param indexName Nome do ndice a ser criado.
	 * @param columnsName Nome de uma ou mais colunas da tabela.
	 */
	public void createIndex(String tableName, String indexName, String [] columnsName){
		
	}
    
	
	/**
	 * M�todo usado para remover um ndice
	 * @param indexName Nome do ndice a ser removido.
	 */
	public void dropIndex(String indexName){
		
	}

	/**
	 * M�todo usado para criar um �ndice em uma determinada tabela
	 * @param schemaName Nome do Schema
	 * @param nomeTabela Nome da tabela a ser indexada.
	 * @param nomeIndice Nome do ndice a ser criado.
	 * @param nomeColuna Nome de uma ou mais colunas da tabela.
	 */
	public void createIndex(String schemaName, String tableName, String indexName, String[] collumnName, String accessMethod) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * M�todo usado para criar um �ndice prim�rio em uma determinada tabela
	 * @param schemaName Nome do Schema
	 * @param tableName Nome da tabela a ser indexada
	 * @param indexName Nome do ndice a ser criado
	 * @param columnsName Nome de uma ou mais colunas da tabela
	 * @param accessMethod Tipo de m�todo de acesso
	 */
	public void createPrimaryIndex(String schemaName, String tableName, String indexName, String[] collumnName, String accessMethod) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * M�todo usado para incrementar o benef�cio de um �ndice prim�rio no SQLServer
	 * @param schemaName Nome do Schema
	 * @param tableName Nome da tabela a ser indexada
	 * @param field Nome da coluna
	 * @param value Valor a ser adicionado no benef�cio acumulado do �ndice
	 * @param wldId id da express�o SQL analisada
	 * @param wldType tipo da express�o SQL analisada
	 * @return Valor do benef�cio acumulado ap�s a atualiza��o
	 */
	public double incrementPrimaryIndexBenefict(String schemaname, String tableName, ArrayList<String> field, double value, int wldId, String wldType, double creationCost) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * M�todo usado para incrementar o benef�cio de um �ndice secund�rio no SQLServer
	 * @param schemaName Nome do Schema
	 * @param tableName Nome da tabela a ser indexada
	 * @param field Nome da coluna
	 * @param value Valor a ser adicionado no benef�cio acumulado do �ndice
	 * @param wldId id da express�o SQL analisada
	 * @param wldType tipo da express�o SQL analisada
	 * @param creationCost Custo de cria��o do �ndice
	 * @return Valor do benef�cio acumulado ap�s a atualiza��o
	 */
	public double incrementSecondaryIndexBenefict(String schemaname, String tableName, ArrayList<String> field, double value, int wldId, String wldType, double creationCost) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * M�todo usado para adicionar um novo �ndice candidato
	 * @param tableName Nome da tabela a ser indexada
	 * @param field Nome das colunas
	 * @param cidType Tipo do �ndice a ser criado (C -> Clustering and U -> Unclustering)
	 * @param value Valor do benef�cio do �ndice a ser criado
	 * @param creationCost Custo de cria��o do �ndice
	 */
	public void addCandidateIndex(String tableName, ArrayList<String> field, String cidType, double value, double creationCost) throws SQLException {
		// TODO Auto-generated method stub
		
	}
	
	/**
	 * M�todo usado para clusterizar uma tabela
	 * @param tableName Nome da tabela a ser clusterizada
	 * @param realIndexName Nome do �ndice a ser usado na clusteriza��o da tabela
	 */
	public void clusterTable(String tableName, String realIndexName){
		
	}

	/**
	 * M�todo usado para atualizar o nome de um �ndice na MetaBase Local
	 * @param ciId Identificador do �ndice a ser atualizado
	 * @param realIndexName Nome do �ndice a ser usado na atualiza��o
	 */
	public void updateIndexName(int cidId, String realIndexName){
		
	}
    	
            
}
