package drivers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


/**
 * @author Jos� Maria
 * Classe usada para representar "Driver for Statistics Access"
 * Obt�m informa��es estatsticas de uma determinada tabela do banco
 */
public interface SADriver {
		
	/**
	 * M�todo que retorna o n�mero de linhas (numeroLinhas) de uma determinada tabela (passada como par�metro).
	 * @param tableName nome da tabela (da qual se deseja obter o n�mero de linhas)
	 * @return numeroLinhas n�mero de linhas da tabela passada como par�metro (tableName)
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws IOException 
	 */
	public abstract int getRowsNumber(String tableName) throws SQLException, IOException, ClassNotFoundException;
		
	/**
	 * M�todo que retorna o numeroBlocos.
	 * @param tableName nome da tabela (da qual se deseja obter o n�mero de linhas)
	 * @return numeroBlocos n�mero de blocos (p�ginas de dados) da tabela passada como par�metro (tableName)
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws IOException 
	 */
	public abstract int getBlocksNumber(String tableName) throws SQLException, IOException, ClassNotFoundException;
	
	/**
	 * M�todo que retorna o numeroBlocos.
	 * @param tableName nome da tabela (da qual se deseja obter o n�mero de linhas)
	 * @return numeroBlocos n�mero de blocos (p�ginas de dados) da tabela passada como par�metro (tableName)
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws IOException 
	 */
	public abstract int getBlocksNumber(String scemaName, String tableName) throws IOException, ClassNotFoundException, SQLException;
	
	
	/**
	 * M�todo que retorna o nomeIndice.
	 * @param tableName nome da tabela (da qual se deseja recuperar o conjunto de �ndices existentes)
	 * @return nomeIndice lista com os nomes dos �ndices existentes sobre a tabela passada como par�metro (tableName)
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws IOException 
	 */
	public abstract List<String> getIndexName(String tableName) throws SQLException, IOException, ClassNotFoundException;
	
		
	/**
	 * M�todo que retorna a alturaArvore (de um determinado �ndice passado como par�metro).
	 * @param indexName nome do �ndice (do qual se deseja obter a altura)
	 * @return alturaArvore altura do �ndice passado como par�metro (indexName)
	 */
	public abstract int getDeepTree(String indexName);
	
	/**
	 * M�todo utilizado para verificar se um determinado �ndice existe
	 * @param schemaName nome do schema
	 * @param collumnName nome das colunas que comp�em o �ndice
	 * @param tableName nome da tabela
	 * @return true se o �ndice existe e false se o �ndice n�o existe
	 */
	public abstract boolean indexExist(String schemaName, String tableName, String[] collumnName) throws Exception;
	
	/**
	 * M�todo utilizado para recuperar as �ltimas consultas executadas e ainda n�o avaliadas
	 * @return ArrayList contendo o texto (SQL) das consultas capturadas pelo WOAgent e ainda n�o analizadas pelo FISAgent
	 */
	public abstract ArrayList getQueryList() throws Exception;
	
	
	/**
	 * M�todo utilizado para recuperar o plano de execu��o para uma determinada cl�usula SQL fornecida como par�metro (query_id)
	 * @param queryId identificador de uma determinada cl�usula SQL
	 * @return ArrayList contendo o plano de execu��o para a cl�usula SQL fornecida como par�metro (query_id)
	 */
	public abstract ArrayList getPartitionedPlan( int queryId ) throws Exception;
	
	/**
	 * M�todo utilizado para verificar se um determinado campo (coluna) de uma determinada tabela � chave prim�ria
	 * @param tableName nome da tabela
	 * @param columnName nome da coluna (atributo)
	 * @return true se o atributo columnName for chave prim�ria de tableName e false caso contr�rio
	 */
	public abstract boolean isPrimaryKey( String tableName, ArrayList<String> columnName ) throws Exception;
	
	/**
	 * M�todo utilizado para recuperar o n�mero de linhas (tuplas) de uma determinada tabela (passada como par�metro)
	 * @param schemaName nome do schema
	 * @param tableName nome da tabela
	 * @return quantidade de linhas (tulas) da tabela  tableName
	 */
	public abstract int getTableRowCount(String schemaname, String tableName) throws Exception;
	
	/**
	 * M�todo utilizado para recuperar o tipo de uma express�o SQL (Tarefa)
	 * @param wldId id da express�o SQL (tarefa)
	 * @return tipo da express�o SQL (Tarefa)
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws IOException 
	 */
	public abstract String getTaskType(int wldId) throws IOException, ClassNotFoundException, SQLException;
	
	
	/**
	 * M�todo utilizado para recuperar a quantidade de vezes que uma express�o SQL (Tarefa) foi capturada e ainda n�o analisada
	 * @param wldId id da express�o SQL (tarefa)
	 * @return quantidade de vezes que uma express�o SQL (Tarefa) foi capturada e ainda n�o analisada
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws IOException 
	 */
	public abstract int getWldQtd(int wldId) throws IOException, ClassNotFoundException, SQLException;
	
	
	/**
	 * M�todo utilizado para recuperar o maior benef�cio acumulado dentre todos os �ndices candidatos (existentes na MetaBase Local) definidos sobre a tabela passada como par�metro
	 * @param tableName nome da tabela
	 * @return maior benef�cio acumulado dentre todos os �ndices candidatos (existentes na MetaBase Local) definidos sobre a tabela passada como par�metro
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws IOException 
	 */
	public abstract int getBestPrimaryIndexProfit(String tableName) throws IOException, ClassNotFoundException, SQLException;

	/**
	 * M�todo utilizado para verificar se existe algum �ndice candidato (na MetaBase Local), em estado real (status = "R") definido sobre a tabela passada como par�metro
	 * @param tableName nome da tabela
	 * @return valor booleano indicando se existe algum �ndice candidato (na MetaBase Local), em estado real (status = "R") definido sobre a tabela passada como par�metro
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws IOException 
	 */
	public abstract boolean existRealPrimaryIndex(String tableName) throws IOException, ClassNotFoundException, SQLException;

	/**
	 * M�todo utilizado para recuperar o nome do �ndice candidato prim�rio, cujo estado seja real (status = "R"), definido sobre a tabela passada como par�metro(na MetaBase Local)
	 * @param tableName nome da tabela
	 * @return indexName nome do �ndice
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws IOException 
	 */
	public abstract String getRealPrimaryIndexName(String tableName) throws IOException, ClassNotFoundException, SQLException;

	/**
	 * M�todo utilizado para recuperar o id (identificador) de um �ndice candidato (armazenado na MetaBase Local)
	 * @param tableName nome da tabela
	 * @param field ArrayList contendo as colunas (campos) que comp�em o �ndice
	 * @param type Tipo do �ndice (Prim�rio (C-Clustering) ou Secund�rio (U-Unclustering))
	 * @return identificado do �ndice
	 * @throws ClassNotFoundException 
	 * @throws IOException 
	 */
	public abstract int getIndexIdLM(String tableName, ArrayList<String> field, String type) throws SQLException, IOException, ClassNotFoundException;
	
	/**
	 * M�todo utilizado para verificar se um determinado �ndice real existente no PostgreSQL � prim�rio (clusterizado)
	 * @param schemaName nome do Schema
	 * @param tableName nome da tabela
	 * @param fields ArrayList contendo as colunas (campos) que comp�em o �ndice
	 * @return valor booleano indicando se o �ndice, cujos dados passados por par�metro, existe no PostgreSQL e est� clusterizado
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws IOException 
	 */
	public abstract boolean isClustered(String schemaName, String tableName, ArrayList<String> fields) throws IOException, ClassNotFoundException, SQLException;
	
	/**
	 * M�todo utilizado para recuperar o nome de um �ndice real (nome f�sico do �ndice)
	 * @param schemaName nome do Schema
	 * @param tableName nome da tabela
	 * @param fields ArrayList contendo as colunas (campos) que comp�em o �ndice
	 * @return Nome do �ndice (como criado fisicamente no PostgreSQL)
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws IOException 
	 */
	public abstract String getIndexName(String schemaName, String tableName, ArrayList<String> fields) throws IOException, ClassNotFoundException, SQLException;
	
	/**
	 * M�todo utilizado para atualizar a quantidade de vezes que a express�o SQL foi analisada
	 * @param wldId Id da express�o SQL do Schema
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws IOException 
	 */
	public abstract void updateWldAnalyzeCount(int wldId) throws IOException, ClassNotFoundException, SQLException;

}
