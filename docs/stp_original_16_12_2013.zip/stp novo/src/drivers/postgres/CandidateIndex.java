package drivers.postgres;

import java.util.ArrayList;

/**
 * @author Jos� Maria
 * 
 * Classe usada para representar um �ndice candidato
 */
public class CandidateIndex {
	/** Tabela sobre a qual o �ndice seria criado **/
	private String table;
	/** Chave de busca do �ndice **/
	private ArrayList<String> searchKey;
	/** Operador do Filtro presente na Opera��o SeqScan**/
	private String operator;
	/** Estimativa do custo de execu��o do SeqScan (fornecido pelo pr�prio processador de consultas **/
	private String costSeqScan;
	/** Quantidade de linhas (tuplas) recuperadas pela opera��o SeqScan **/
	private int qtdTuples;
	
	/**
	 * M�todo Construtor
	 * @param table Tabela sobre o �ndice candidato seria criado
	 * @param searchKey Chave de busca do �ndice candidato
	 * @param operator Operador do Filtro utilizado na opera��o SeqScan
	 * @param costSeqScan Estimativa do custo de execu��o do SeqScan (fornecido pelo pr�prio processador de consultas
	 * @param qtdTuples Quantidade de linhas (tuplas) recuperadas pela opera��o SeqScan
	 */
	public CandidateIndex(String table, ArrayList<String> searchKey, String operator, String costSeqScan, int qtdTuples) {
		super();
		this.table = table;
		this.searchKey = searchKey;
		this.operator = operator;
		this.costSeqScan = costSeqScan;
		this.qtdTuples = qtdTuples;
	}
	
	/**
	 * M�todo utilizado para recuperar o valor do atributo searchKey
	 * @return Valor do atributo searchKey
	 */
	public ArrayList<String> getSearchKey() {
		return searchKey;
	}
	
	/**
	 * M�todo utilizado para setar o valor do atributo searchKey
	 * @param searchKey Novo valor do atributo searchKey
	 */
	public void setSearchKey(ArrayList<String> searchKey) {
		this.searchKey = searchKey;
	}
	
	/**
	 * M�todo utilizado para recuperar o valor do atributo costSeqScan
	 * @return Valor do atributo costSeqScan
	 */
	public String getCostSeqScan() {
		return costSeqScan;
	}
	
	/**
	 * M�todo utilizado para setar o valor do atributo costSeqScan
	 * @param custo Valor do atributo costSeqScan
	 */
	public void setCostSeqScan(String costSeqScan) {
		this.costSeqScan = costSeqScan;
	}
	
	/**
	 * M�todo utilizado para recuperar o valor do atributo operator
	 * @return Valor do atributo operator
	 */
	public String getOperator() {
		return operator;
	}
	
	/**
	 * M�todo utilizado para setar o valor do atributo operator
	 * @param operador Novo valor do atributo operator
	 */
	public void setOperator(String operator) {
		this.operator = operator;
	}
	
	/**
	 * M�todo utilizado para recuperar o valor do atributo table
	 * @return Valor do atributo table
	 */
	public String getTable() {
		return table;
	}
	
	/**
	 * M�todo utilizado para setar o valor do atributo table
	 * @param tabela Novo valor do atributo table
	 */
	public void setTable(String table) {
		this.table = table;
	}
	
	/**
	 * M�todo utilizado para converter o objeto SeqScan em uma String
	 */
	@Override
	public String toString() {
		return getTable() + "." + getSearchKey() + "("+ getOperator() +"): " + getCostSeqScan();
	}
	
	/**
	 * M�todo utilizado para recuperar o valor do atributo qtdTuples
	 * @return Valor do atributo qtdTuples
	 */
	public int getQtdTuples() {
		return qtdTuples;
	}
	
	/**
	 * M�todo utilizado para setar o valor do atributo qtdTuples
	 * @param linhas Novo valor do atributo qtdTuples
	 */
	public void setQtdTuples(int qtdTuples) {
		this.qtdTuples = qtdTuples;
	}
	
	
}

