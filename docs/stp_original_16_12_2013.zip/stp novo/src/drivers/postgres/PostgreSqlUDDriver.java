package drivers.postgres;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

import util.Log;

import agents.WOAgent;

import drivers.UDDriver;

/**
 * @author Jos� Maria
 * 
 * Classe usada para representar "Driver for DBMS Update" no Postgres
 * Respons�vel pela cria��o e remo��o de �ndices
 */
public class PostgreSqlUDDriver implements UDDriver{
	/** vari�vel que representa uma conex�o com o Postgres **/
	Connection connection = null;
	/** vari�vel utilizada para acessar um arquivo de propriedades **/
	protected Properties properties;
	/** vari�vel que representa uma Assinatura **/
	protected String signature = null;
	/** vari�vel boolean indica se o programa est� rodando em modo debug ou n�o **/
	protected boolean debug = true;
	/** vari�vel utilizada para manipular logs **/
	protected Log log = new Log();

	/** M�todo Construtor **/
	public PostgreSqlUDDriver(){
		try{
			properties = new Properties();
			properties.load(WOAgent.class.getResourceAsStream("database.properties"));
	        signature     = this.properties.getProperty( "signature" );
			String driver = this.properties.getProperty( "driverPostgres" );
			String url    = this.properties.getProperty( "urlPostgres" );
	        String user   = this.properties.getProperty( "userPostgres" );
	        String passwd = this.properties.getProperty( "pwdPostgres" );
            Class.forName( driver );
            this.connection = DriverManager.getConnection( url, user, passwd );
		} catch( SQLException e ){
        	log.write( e );
        } catch (ClassNotFoundException e) {
        	log.write( e );
		} catch (Exception e) {
            log.write( e );
        }		
	}

	/**
	 * M�todo usado para criar um �ndice em uma determinada tabela no Postgres
	 * @param tableName Nome da tabela a ser indexada.
	 * @param indexName Nome do ndice a ser criado.
	 * @param columnName Nome de uma ou mais colunas da tabela.
	 */
	public void createIndex(String tableName, String indexName, String[] collumnName){
		Statement statement=null;
		
		ResultSet resultSet = null;
		
		PreparedStatement cstmt = null;
		
		String sql = null;
		
		String accessMethod = "btree";
		
		/* Identificador do �ndice*/
		int cidId=0;
		
		/* Benef�cio Inicial */
		int cidInitialProfit=0;
		
		/* Custo de Cria��o do �ndice*/
		int cidCreationCost = 0;
		
		/* Cardinalidade da tabela sobre a qual o �ndice ser� criado (n�mero de tuplas) */
		int cidInitialCardinality=0;
    	
		/* Tamanho do �ndice, ou seja, n�mero de p�ginas de discos ocupadas para armazenar o �ndice */
		int cidInitialDiskPages=0;
		
		//Recupera o id do �ndice
		ArrayList<String> fields = new ArrayList<String>();
		for (int i = 0; i < collumnName.length; i++) {
			fields.add(collumnName[ i ]);
		}
		try{
			cidId = indexIdLM(tableName, fields, "U");
		}
		catch (SQLException e) {
   			log.write( e );
		}
		
		//Altera o nome do �ndice
		indexName = indexName + "_" + cidId;
		
		String collumns = "";
		try{
			statement = this.connection.createStatement();
			for ( int i = 0; i < collumnName.length; i++ ) {
				if ( i == collumnName.length - 1 ) {
					collumns += "\"" + collumnName[ i ] + "\"";
				} else {
					collumns += "\"" + collumnName[ i ] + "\", ";
				}
			}		
	    	/* Index creation command */
	    	String sqlClause = signature+ " CREATE INDEX \""+ indexName + "\" ON \""+ "public" +"\".\""+ tableName +"\"  USING " + accessMethod + " ("+ collumns +");";
	    	log.write( sqlClause );
	    	statement.executeUpdate(sqlClause);
	    	statement.close();
		}
		catch (SQLException e) {
			log.write( e );
		}
		catch (Exception e) {
			log.write( e );
		}
    	
    	//Atualiza dados do �ndice na MetaBase Local
        try{    		
        	//Recupera os dados necess�rios
        	sql = signature+ "select cid_initial_profit, cid_creation_cost from tb_candidate_index where cid_id=?";
        	
        	cstmt = this.connection.prepareStatement(sql);
        	
        	cstmt.setInt(1, cidId);
        	
        	resultSet = cstmt.executeQuery();
        	
        	if (resultSet.next()){
        		cidInitialProfit = resultSet.getInt("cid_initial_profit");
        		cidCreationCost = resultSet.getInt("cid_creation_cost");
        	}
        	
        	if (cidInitialProfit==0){
        		cidInitialProfit = cidCreationCost;
        	}
        	
        	resultSet.close();
        	cstmt.close();
        	
        	//Atualiza a MetaBase Local
        	sql = signature+ "update tb_candidate_index set cid_status=?, cid_initial_profit=?, cid_initial_cardinality=?, cid_initial_disk_pages=? where cid_id=?";
        	
        	cstmt = this.connection.prepareStatement(sql);
        	
        	cidInitialCardinality=this.getTableRowCount("public", tableName);
        	cidInitialDiskPages=this.getIndexBlocksNumber("public", indexName);
        	
        	cstmt.setString(1, "R");
        	cstmt.setInt(2, cidInitialProfit);
        	cstmt.setInt(3, cidInitialCardinality);
        	cstmt.setInt(4, cidInitialDiskPages);
        	cstmt.setInt(5, cidId);
        	
        	cstmt.executeUpdate();
        	
        	
        }
    	catch (SQLException e) {
   			log.write( e );
		}
    	catch (Exception e) {
   			log.write( e );
		}
    }
	
	/**
	 * M�todo usado para criar um �ndice UNIQUE em uma determinada tabela no PostgreSQL
	 * @param tableName Nome da tabela a ser indexada.
	 * @param indexName Nome do ndice a ser criado.
	 * @param columnsName Nome de uma ou mais colunas da tabela.
	 */
	public void createUniqueIndex(String schema, String nomeTabela, String nomeIndice, String[] nomeColuna, String metodoAcesso){
		String colunas = "";
		for (int i = 0; i < nomeColuna.length; i++) {
			if (i == nomeColuna.length - 1) {
				colunas = colunas + "\"" + nomeColuna[i] + "\"";
			} else {
				colunas = colunas + "\"" + nomeColuna[i] + "\", ";
			}
		}		
        try{
        	/*Clusula para criao de ndice*/
        	String sqlClause = "CREATE UNIQUE INDEX \""+ nomeIndice + "\" ON \""+ schema +"\".\""+ nomeTabela +"\"  USING " + metodoAcesso + " ("+ colunas +");";
        	log.write(sqlClause);
    		Statement statement = this.connection.createStatement();
        	statement.executeUpdate(sqlClause);
    		statement.close();
        }
    	catch (SQLException e) {
    		log.write( e );
		}
		catch (NullPointerException e) {
    		log.write( e );
		}
		catch (Exception e) {
    		log.write( e );
		}
    }
	
	/**
	 * M�todo usado para remover um ndice
	 * @param indexName Nome do �ndice a ser removido.
	 */
	public void dropIndex(String indexName){
        try{
        	/*Clusula para remoo de ndice*/
        	String sqlClause = "DROP INDEX \"public\".\"" + indexName + "\"";
        	log.write( sqlClause );
    		Statement statement = this.connection.createStatement();
        	statement.executeUpdate(sqlClause);
    		statement.close();
        }
    	catch (SQLException e) {
    		log.write( e );
		}
		catch (NullPointerException e) {
    		log.write( e );
		}
		catch (Exception e) {
    		log.write( e );
		}
    }

	
	/**
	 * M�todo usado para incrementar o benef�cio de um �ndice prim�rio no Postgres
	 * @param schemaName Nome do Schema
	 * @param tableName Nome da tabela a ser indexada
	 * @param field Nome da coluna
	 * @param value Valor a ser adicionado no benef�cio acumulado do �ndice
	 * @param wldId id da express�o SQL analisada
	 * @param wldType tipo da express�o SQL analisada
	 * @return Valor do benef�cio acumulado ap�s a atualiza��o
	 */
	public double incrementPrimaryIndexBenefict(String schemaname, String tableName, ArrayList<String> field, double value, int wldId, String wldType, double creationCost) throws SQLException{
		Statement statement = this.connection.createStatement();
		ResultSet resultSet = null; 
		PreparedStatement cstmt = null;
		int cidId=0;
		int timestamp=0;
		String cidStatus=null;
		double profit = 0;
		
		String sql = null;
		
		boolean exist = indexExistLM(tableName, field, "C");
		
		//Insere benef�cio em tb_profits
		cidId = indexIdLM(tableName, field, "C");
		
		//Se existe, atualiza o benef�cio
		if (exist){
			
			sql = "update agent.tb_candidate_index set cid_index_profit = cid_index_profit + ? where cid_id = ?";
			
			cstmt = this.connection.prepareStatement(sql);
			
			log.write( sql );
			
			cstmt.setDouble(1, value);
			cstmt.setInt(2, cidId);
								
			cstmt.executeUpdate();
			
		}
		//Se n�o existe, insere o �ndice em tb_candidate_index
		else{
			addCandidateIndex(tableName, field, "C", value, creationCost);
		}
		
		//Insere benef�cio em tb_profits
		cidId = indexIdLM(tableName, field, "C");
		cidStatus = indexTypeLM(cidId);
		
		//Recupera o maior timestamp para ciId existente em tb_profits
		sql = "select max(pro_timestamp) as max_profit from agent.tb_profits where cid_id = ?";
		
		cstmt = this.connection.prepareStatement(sql);
		
		log.write( sql );
		
		cstmt.setInt(1, cidId);
							
		resultSet = cstmt.executeQuery();
		
		if (resultSet.next()){
			timestamp = resultSet.getInt("max_profit");
		}
		
		timestamp++;
		//Insere benef�cio em tb_profits
		sql = "insert into agent.tb_profits values(?,?,?,?,?)";
		
		cstmt = this.connection.prepareStatement(sql);
		
		log.write( sql );
		
		cstmt.setInt(1, cidId);
		cstmt.setInt(2, timestamp);
		cstmt.setDouble(3, value);
		cstmt.setInt(4, wldId);
		cstmt.setString(5, cidStatus);
							
		cstmt.executeUpdate();
		
		//Recupera o benef�cio corrente
		sql = signature+ "select cid_index_profit from agent.tb_candidate_index where cid_id=?";
		
		cstmt = this.connection.prepareStatement(sql);
		
		log.write( sql );
		
		cstmt.setInt(1, cidId);
							
		resultSet = cstmt.executeQuery();
		
		if (resultSet.next()){
			profit = resultSet.getInt("cid_index_profit");
		}
		
		resultSet.close();
		statement.close();
		return profit;
	}

	/**
	 * M�todo usado para incrementar o benef�cio de um �ndice secund�rio no Postgres
	 * @param schemaName Nome do Schema
	 * @param tableName Nome da tabela a ser indexada
	 * @param field Nome da coluna
	 * @param value Valor a ser adicionado no benef�cio acumulado do �ndice
	 * @return Valor do benef�cio acumulado ap�s a atualiza��o
	 */
	public double incrementSecondaryIndexBenefict(String schemaname, String tableName, ArrayList<String> field, double value, int wldId, String wldType, double creationCost) throws SQLException{
		Statement statement = this.connection.createStatement();
		ResultSet resultSet = null; 
		PreparedStatement cstmt = null;
		int cidId=0;
		int timestamp=0;
		String cidStatus=null;
		double profit = 0;
		
		String sql = null;
		
		boolean exist = indexExistLM(tableName, field, "U");
		//Insere benef�cio em tb_profits
		cidId = indexIdLM(tableName, field, "U");
		
		//Se existe, atualiza o benef�cio
		if (exist){
			
			sql = "update agent.tb_candidate_index set cid_index_profit = cid_index_profit + ? where cid_id = ?";
			
			cstmt = this.connection.prepareStatement(sql);
			
			log.write( sql );
			
			cstmt.setDouble(1, value);
			cstmt.setInt(2, cidId);
								
			cstmt.executeUpdate();
			
		}
		//Se n�o existe, insere o �ndice em tb_candidate_index
		else{
			addCandidateIndex(tableName, field, "U", value, creationCost);
		}
		
		//Insere benef�cio em tb_profits
		cidId = indexIdLM(tableName, field, "U");
		cidStatus = indexTypeLM(cidId);
		
		//Recupera o maior timestamp para ciId existente em tb_profits
		sql = "select max(pro_timestamp) as max_profit from agent.tb_profits where cid_id = ?";
		
		cstmt = this.connection.prepareStatement(sql);
		
		log.write( sql );
		
		cstmt.setInt(1, cidId);
							
		resultSet = cstmt.executeQuery();
		
		if (resultSet.next()){
			timestamp = resultSet.getInt("max_profit");
		}
		
		timestamp++;
		//Insere benef�cio em tb_profits
		sql = "insert into agent.tb_profits values(?,?,?,?,?)";
		
		cstmt = this.connection.prepareStatement(sql);
		
		log.write( sql );
		
		cstmt.setInt(1, cidId);
		cstmt.setInt(2, timestamp);
		cstmt.setDouble(3, value);
		cstmt.setInt(4, wldId);
		cstmt.setString(5, cidStatus);
							
		cstmt.executeUpdate();
		
		//Recupera o benef�cio corrente
		sql = signature+ "select cid_index_profit from agent.tb_candidate_index where cid_id=?";
		
		cstmt = this.connection.prepareStatement(sql);
		
		log.write( sql );
		
		cstmt.setInt(1, cidId);
							
		resultSet = cstmt.executeQuery();
		
		if (resultSet.next()){
			profit = resultSet.getInt("cid_index_profit");
		}
		
		resultSet.close();
		statement.close();
		return profit;

	}
	
	/**
	 * M�todo usado para criar um �ndice prim�rio em uma determinada tabela no Postgres
	 * @param schemaName Nome do Schema
	 * @param tableName Nome da tabela a ser indexada
	 * @param indexName Nome do ndice a ser criado
	 * @param columnsName Nome de uma ou mais colunas da tabela
	 * @param accessMethod Tipo de m�todo de acesso
	 */
	public void createIndex(String schemaName, String tableName, String indexName, String[] collumnName, String accessMethod) throws SQLException{
    	//Example: CREATE INDEX "in_cd_municipio_mu" ON "public"."processos"  USING btree ("cd_municipio_mu");
		/* collumns used in index creation */
		
		Statement statement=null;
		
		ResultSet resultSet = null;
		
		PreparedStatement cstmt = null;
		
		String sql = null;
		
		/* Identificador do �ndice*/
		int cidId=0;
		
		/* Benef�cio Inicial */
		int cidInitialProfit=0;
		
		/* Custo de Cria��o do �ndice*/
		int cidCreationCost = 0;
		
		/* Cardinalidade da tabela sobre a qual o �ndice ser� criado (n�mero de tuplas) */
		int cidInitialCardinality=0;
    	
		/* Tamanho do �ndice, ou seja, n�mero de p�ginas de discos ocupadas para armazenar o �ndice */
		int cidInitialDiskPages=0;
		
		//Recupera o id do �ndice
		ArrayList<String> fields = new ArrayList<String>();
		for (int i = 0; i < collumnName.length; i++) {
			fields.add(collumnName[ i ]);
		}
		try{
			cidId = indexIdLM(tableName, fields, "U");
		}
		catch (SQLException e) {
   			log.write( e );
		}
		
		//Altera o nome do �ndice
		indexName = indexName + "_" + cidId;
		
		String collumns = "";
		statement = this.connection.createStatement();
		for ( int i = 0; i < collumnName.length; i++ ) {
			if ( i == collumnName.length - 1 ) {
				collumns += "\"" + collumnName[ i ] + "\"";
			} else {
				collumns += "\"" + collumnName[ i ] + "\", ";
			}
		}		
    	/* Index creation command */
    	String sqlClause = signature+ " CREATE INDEX \""+ indexName + "\" ON \""+ schemaName +"\".\""+ tableName +"\"  USING " + accessMethod + " ("+ collumns +");";
    	log.write( sqlClause );
    	statement.executeUpdate(sqlClause);
    	statement.close();
    	
    	//Atualiza dados do �ndice na MetaBase Local
        try{    		
        	//Recupera os dados necess�rios
        	sql = signature+ "select cid_initial_profit, cid_creation_cost from tb_candidate_index where cid_id=?";
        	
        	cstmt = this.connection.prepareStatement(sql);
        	
        	cstmt.setInt(1, cidId);
        	
        	resultSet = cstmt.executeQuery();
        	
        	if (resultSet.next()){
        		cidInitialProfit = resultSet.getInt("cid_initial_profit");
        		cidCreationCost = resultSet.getInt("cid_creation_cost");
        	}
        	
        	if (cidInitialProfit==0){
        		cidInitialProfit = cidCreationCost;
        	}
        	
        	resultSet.close();
        	cstmt.close();
        	
        	//Atualiza a MetaBase Local
        	sql = signature+ "update tb_candidate_index set cid_status=?, cid_initial_profit=?, cid_initial_cardinality=?, cid_initial_disk_pages=? where cid_id=?";
        	
        	cstmt = this.connection.prepareStatement(sql);
        	
        	cidInitialCardinality=this.getTableRowCount(schemaName, tableName);
        	cidInitialDiskPages=this.getIndexBlocksNumber(schemaName, indexName);
        	
        	cstmt.setString(1, "R");
        	cstmt.setInt(2, cidInitialProfit);
        	cstmt.setInt(3, cidInitialCardinality);
        	cstmt.setInt(4, cidInitialDiskPages);
        	cstmt.setInt(5, cidId);
        	
        	cstmt.executeUpdate();
        	
        	
        }
    	catch (SQLException e) {
   			log.write( e );
		}
    	catch (Exception e) {
   			log.write( e );
		}
    }
	
	/**
	 * M�todo usado para criar um �ndice prim�rio em uma determinada tabela
	 * @param schemaName Nome do Schema
	 * @param tableName Nome da tabela a ser indexada
	 * @param indexName Nome do ndice a ser criado
	 * @param columnsName Nome de uma ou mais colunas da tabela
	 * @param accessMethod Tipo de m�todo de acesso
	 */
	public void createPrimaryIndex(String schemaName, String tableName, String indexName, String[] collumnName, String accessMethod){
    	//Example: CREATE INDEX "in_cd_municipio_mu" ON "public"."processos"  USING btree ("cd_municipio_mu");
		
		Statement statement=null;
		
		ResultSet resultSet = null;
		
		PreparedStatement cstmt = null;
		
		String sql = null;
		
		/* collumns used in index creation */
		String collumns = "";
		
		/* Identificador do �ndice*/
		int cidId=0;
		
		/* Benef�cio Inicial */
		int cidInitialProfit=0;
		
		/* Custo de Cria��o do �ndice*/
		int cidCreationCost = 0;
		
		/* Cardinalidade da tabela sobre a qual o �ndice ser� criado (n�mero de tuplas) */
		int cidInitialCardinality=0;
    	
		/* Tamanho do �ndice, ou seja, n�mero de p�ginas de discos ocupadas para armazenar o �ndice */
		int cidInitialDiskPages=0;
		
		//Monta texto SQL com as colunas
		for (int i = 0; i < collumnName.length; i++) {
			if (i == collumnName.length - 1) {
				collumns += "\"" + collumnName[ i ] + "\"";
			} else {
				collumns += "\"" + collumnName[ i ] + "\", ";
			}
		}		
		
		//Recupera o id do �ndice
		ArrayList<String> fields = new ArrayList<String>();
		for (int i = 0; i < collumnName.length; i++) {
			fields.add(collumnName[ i ]);
		}
		try{
			cidId = indexIdLM(tableName, fields, "C");
		}
		catch (SQLException e) {
   			log.write( e );
		}
		
		//Altera o nome do �ndice
		indexName = indexName + "_" + cidId;
		
		//Cria o �ndice fisicamente
        try{
    		//Cria o �ndice fisicamente
        	statement = this.connection.createStatement();
    		/* Index creation command */
        	String sqlClause = signature+ " CREATE INDEX \""+ indexName + "\" ON \""+ schemaName +"\".\""+ tableName +"\"  USING " + accessMethod + " ("+ collumns +");";
        	statement.executeUpdate(sqlClause);
        	statement.close();
        	
        	//Clusteriza a tabela usando o �ndice criado
        	sql = signature+ " CLUSTER ? ON ?";
        	cstmt = this.connection.prepareStatement(sql);
        	
        	cstmt.setString(1, indexName);
        	cstmt.setString(2, tableName);
        	//cstmt.executeUpdate(sql);
        	
        	cstmt.close();
        }
    	catch (SQLException e) {
   			log.write( e );
   			return;
		}
		catch (NullPointerException e) {
			log.write( e );
			return;
		}
		catch (Exception e) {
			log.write( e );
			return;
		}
		
		//Atualiza dados do �ndice na MetaBase Local
        try{    		
        	//Recupera os dados necess�rios
        	sql = signature+ "select cid_initial_profit, cid_creation_cost from agent.tb_candidate_index where cid_id=?";
        	
        	cstmt = this.connection.prepareStatement(sql);
        	
        	cstmt.setInt(1, cidId);
        	
        	resultSet = cstmt.executeQuery();
        	
        	if (resultSet.next()){
        		cidInitialProfit = resultSet.getInt("cid_initial_profit");
        		cidCreationCost = resultSet.getInt("cid_creation_cost");
        	}
        	
        	if (cidInitialProfit==0){
        		cidInitialProfit = cidCreationCost;
        	}
        	
        	resultSet.close();
        	cstmt.close();
        	
        	//Atualiza a MetaBase Local
        	sql = signature+ "update agent.tb_candidate_index set cid_status=?, cid_initial_profit=?, cid_initial_cardinality=?, cid_initial_disk_pages=? where cid_id=?";
        	
        	cstmt = this.connection.prepareStatement(sql);
        	
        	cidInitialCardinality=this.getTableRowCount(schemaName, tableName);
        	cidInitialDiskPages=this.getIndexBlocksNumber(schemaName, indexName);
        	
        	cstmt.setString(1, "R");
        	cstmt.setInt(2, cidInitialProfit);
        	cstmt.setInt(3, cidInitialCardinality);
        	cstmt.setInt(4, cidInitialDiskPages);
        	cstmt.setInt(5, cidId);
        	
        	cstmt.executeUpdate();
        	
        	
        }
    	catch (SQLException e) {
   			log.write( e );
		}
    	catch (Exception e) {
   			log.write( e );
		}
    }
	
	/**
	 * M�todo usado para adicionar um novo �ndice candidato
	 * @param tableName Nome da tabela a ser indexada
	 * @param field Nome das colunas
	 * @param cidType Tipo do �ndice a ser criado (C -> Clustering and U -> Unclustering)
	 * @param value Valor do benef�cio do �ndice a ser criado
	 * @param creationCost Custo de cria��o do �ndice
	 */
	public void addCandidateIndex( String tableName, ArrayList<String> field, String cidType, double value, double creationCost) throws SQLException {
		String cidStatus = "H";
		Statement statement = this.connection.createStatement();
		ResultSet resultSet = null; 
		PreparedStatement cstmt = null;
		String sql = null;
		int cidId=0;
		
		//Recupera o maior cid_id existente em tb_candidate_index
		sql = "select max(cid_id) as max_id from agent.tb_candidate_index";
		
		log.write( sql );
		
		resultSet = statement.executeQuery(sql);
		
		if (resultSet.next()){
			cidId = resultSet.getInt("max_id");
		}
		
		cidId++;
		
		//Inserir �ndice em tb_candidate_index
		sql = "insert into agent.tb_candidate_index (cid_id, cid_table_name, cid_index_profit, cid_creation_cost, cid_status, cid_type, cid_initial_profit, cid_fragmentation_level, cid_initial_cardinality, cid_initial_disk_pages, cid_index_name) values(?,?,?,?,?,?,?,?,?,?,?)";
		
		cstmt = this.connection.prepareStatement(sql);
		
		log.write( sql );
		
		cstmt.setInt(1, cidId);
		cstmt.setString(2, tableName);
		cstmt.setDouble(3, value);
		cstmt.setDouble(4, creationCost);
		cstmt.setString(5, cidStatus);
		cstmt.setString(6, cidType);
		cstmt.setInt(7, 0);
		cstmt.setDouble(8, 0);
		cstmt.setInt(9, 0);
		cstmt.setInt(10, 0);
		cstmt.setString(11, "");
				
		cstmt.executeUpdate();
		
		//Inserir colunas em tb_candidate_index_column
		for (int i=0; i< field.size();i++){
			sql = "insert into agent.tb_candidate_index_column values(?,?,?)";
			
			cstmt = this.connection.prepareStatement(sql);
			
			log.write( sql );
			
			cstmt.setInt(1, cidId);
			cstmt.setString(2, field.get(i).trim());
			cstmt.setString(3, null);
			//TODO: Pegar o tipo de uma coluna
					
			cstmt.executeUpdate();
		}
		
	}
	
	/**
	 * M�todo usado para implementar parte da tarefa de adicionar um �ndice candidato. Adiciona somente a tabela referente ao �ndice candidato.
	 * @param tableName Nome da tabela a ser indexada
	 */
	private void insertTable( String tableName ) throws SQLException {
		Statement statement = this.connection.createStatement();
		String sqlClause = signature + " insert into agent.tb_candidate_index ( cid_table_name ) values('"+ tableName +"')";
		statement.executeUpdate( sqlClause );
		statement.close();
	}
	
	/**
	 * M�todo usado para recuperar os dados dos �ndices candidatos de uma determinada tabea (passada como par�metro)
	 * @param tableName Nome da tabela a ser indexada
	 * @retun ResultSet contendo os �ndices candidatos existentes na tabela tableName
	 */
	private ResultSet getTableData( String tableName ) throws SQLException {
		Statement statement = this.connection.createStatement();
		String sqlClause = signature+ "select cid_id, cid_table_name, cid_primary_index_benefict, cid_secondary_index_benefict from agent.tb_candidate_index where cid_table_name = '"+ tableName +"' " ;
		return statement.executeQuery( sqlClause ); 
		
	}
	
	/**
	 * M�todo usado para testar se uma determinada coluna existe em uma determinada tabela
	 * @param tableName Nome da tabela a ser indexada
	 * @param field Nome da coluna
	 * @retun valor boolean indicando se a coluna field existe na tabela tableName
	 */
	private boolean collumnExist(String tableName, String field) throws SQLException {
		ResultSet resultSet = null;
		Statement statement = this.connection.createStatement();
		String sqlClause = signature+ "select tab.cid_table_name, col.cic_column_name" +
				" from agent.tb_candidate_index_column col, agent.tb_candidate_index tab" +
				" where col.cid_id = tab.cid_id" +
				" and tab.cid_table_name = '"+ tableName +"'" +
				" and col.cic_column_name = '"+ field +"'";
    	resultSet = statement.executeQuery(sqlClause); 
    	while( resultSet.next() ){
    		resultSet.close();
    		statement.close();
    		return true;
    	}
		resultSet.close();
		statement.close();
		return false;
	}
	
	/**
	 * M�todo usado para testar se uma determinada tabela existe
	 * @param tableName Nome da tabela a ser indexada
	 * @retun valor boolean indicando se a tabela tableName existe
	 */
	private boolean tableExist( String tableName ) throws SQLException {
		ResultSet resultSet = null;
		Statement statement = this.connection.createStatement();
		String sqlClause = signature+ "select * from agent.tb_candidate_index where cid_table_name = '"+ tableName +"' ";
    	resultSet = statement.executeQuery(sqlClause); 
    	while( resultSet.next() ){
    		resultSet.close();
    		statement.close();
    		return true;
    	}
		resultSet.close();
		statement.close();
		return false;
	}
	
	/**
	 * M�todo utilizado para verificar se um determinado �ndice existe na Metabase Local
	 * @param tableName nome da tabela
	 * @param collumnName nome das colunas que comp�em o �ndice
	 * @return true se o �ndice existe e false se o �ndice n�o existe na MetaBase Local
	 */
	public boolean indexExistLM(String tableName, ArrayList<String> collumnName, String type) throws SQLException{
		ResultSet resultSet =  null;
		ArrayList<String> indexes = new ArrayList<String>();
		ArrayList<String> searchKey = new ArrayList<String>();
		boolean exist = true;
		
		int contNotExist = 0;
		
		//Recupera os �ndices candidatos definidos sobre a tabela tableName
		String sql = "select ci.cid_id from agent.tb_candidate_index ci where ci.cid_table_name=? and ci.cid_type=?";
		PreparedStatement cstmt = this.connection.prepareStatement(sql);
		log.write( sql );
		cstmt.setString(1, tableName);
		cstmt.setString(2, type);
				
		resultSet = cstmt.executeQuery();
		
		if( resultSet != null ){
        	while( resultSet.next() ){
        		indexes.add(resultSet.getString("cid_id"));	
        	}
		}
		
		resultSet.close();
		cstmt.close();
		
		//Verifica se o �ndice desejado j� existe na MetaBase Local
		for(int i=0;i<indexes.size();i++){
		
			sql = "select cic.cic_column_name from agent.tb_candidate_index_column cic where cic.cid_id = ?";
			
			cstmt = this.connection.prepareStatement(sql);
			
			log.write( sql );
			
			cstmt.setInt(1, Integer.parseInt(indexes.get(i)));
					
			resultSet = cstmt.executeQuery();
			
			searchKey = new ArrayList<String>();
			
			/*
			for (int k=0;k<collumnName.size();k++){
				System.out.println("-"+collumnName.get(k).trim()+"-");
			}
			*/
			
			if( resultSet != null ){
	        	while( resultSet.next() ){
	        		searchKey.add((String)resultSet.getString("cic_column_name").trim());
	        		//System.out.println((String)resultSet.getString("cic_column_name"));
	        	}
			}
			/*
			for (int k=0;k<searchKey.size();k++){
				System.out.println("-"+searchKey.get(k).trim()+"-");
			}
			*/
			
			for (int j=0; j< collumnName.size();j++){
				if (! (searchKey.contains(collumnName.get(j)))){
					contNotExist ++;
					break;
				}
			}
			
        }
		
		if (contNotExist==indexes.size()){
			exist = false;
		}
		
	    return exist;
	}
	
	/**
	 * M�todo utilizado para recuperar o id de um �ndice na MetaBase Local
	 * @param tableName nome da tabela
	 * @param collumnName nome das colunas que comp�em o �ndice
	 * @return id do �ndice na MetaBase Local
	 */
	public int indexIdLM(String tableName, ArrayList<String> collumnName, String type) throws SQLException{
		ResultSet resultSet =  null;
		ArrayList<String> indexes = new ArrayList<String>();
		ArrayList<String> searchKey = new ArrayList<String>();
		int ciId=0;
		
		int contNotExist = 0;
		
		//Recupera os �ndices candidatos definidos sobre a tabela tableName
		String sql = "select ci.cid_id from agent.tb_candidate_index ci where ci.cid_table_name=? and ci.cid_type=?";
		PreparedStatement cstmt = this.connection.prepareStatement(sql);
		log.write( sql );
		cstmt.setString(1, tableName);
		cstmt.setString(2, type);
				
		resultSet = cstmt.executeQuery();
		
		if( resultSet != null ){
        	while( resultSet.next() ){
        		indexes.add(resultSet.getString("cid_id"));	
        	}
		}
		
		resultSet.close();
		cstmt.close();
		
		//Procura o id do �ndice desejado
		for(int i=0;i<indexes.size();i++){
		
			sql = "select cic.cic_column_name from agent.tb_candidate_index_column cic where cic.cid_id = ?";
			
			cstmt = this.connection.prepareStatement(sql);
			
			log.write( sql );
			
			cstmt.setInt(1, Integer.parseInt(indexes.get(i)));
					
			resultSet = cstmt.executeQuery();
			
			searchKey = new ArrayList<String>();
			
			if( resultSet != null ){
	        	while( resultSet.next() ){
	        		searchKey.add((String)resultSet.getString("cic_column_name").trim());
	        	}
			}
			
			contNotExist=0;
			if (searchKey.size()==collumnName.size()){
				for (int j=0; j< collumnName.size();j++){
					if (! searchKey.contains(collumnName.get(j))){
						contNotExist ++;
						break;
					}
				}
			}
			if (contNotExist==0){
				ciId = Integer.parseInt(indexes.get(i));
			}
			
        }
		
	    return ciId;
	}
	
	/**
	 * M�todo utilizado para recuperar o status de um �ndice na MetaBase Local
	 * @param cidId id do �ndice na MetaBase Local
	 * @return status do �ndice na MetaBase Local
	 */
	public String indexTypeLM(int cidId) throws SQLException{
		ResultSet resultSet =  null;
		String cidStatus=null;
		
		//Recupera o status do �ndice recebido como par�metro
		String sql = "select ci.cid_status from agent.tb_candidate_index ci where ci.cid_id=?";
		PreparedStatement cstmt = this.connection.prepareStatement(sql);
		log.write( sql );
		cstmt.setInt(1, cidId);
				
		resultSet = cstmt.executeQuery();
		
		if( resultSet != null ){
        	while( resultSet.next() ){
        		cidStatus = resultSet.getString("cid_status");	
        	}
		}
		
		resultSet.close();
		cstmt.close();
		
		return cidStatus;
		
	}
	
	/**
	 * M�todo utilizado para recuperar o n�mero de linhas (tuplas) de um determinada tabela (passada como par�metro) no Postgres
	 * @param schemaName nome do schema
	 * @param tableName nome da tabela
	 * @return quantidade de linhas (tulas) da tabela  tableName
	 */
	public int getTableRowCount(String schemaname, String tableName) throws Exception{
		ResultSet resultSet = null;
		int lineCount = 0;
		Statement statement = this.connection.createStatement();
    	String sqlClause = signature+ " select reltuples as linecount from pg_class where relname in ("+
							" select tablename from pg_tables where schemaname like '"+ schemaname +"'"+
							" and tablename like '" + tableName + "')";
    	resultSet = statement.executeQuery(sqlClause);
    	if( resultSet.next()){
    		lineCount = resultSet.getInt("linecount");
    	}
		resultSet.close();
		statement.close();
		return lineCount;
	}
	
	/**
	 * M�todo que retorna o numero de Blocos de um determinado �ndice no PostgreSQL.
	 * @param indexName nome da tabela (da qual se deseja obter o n�mero de linhas)
	 * @return numeroBlocos n�mero de blocos (p�ginas de dados) da tabela passada como par�metro (tableName)
	 */
	public int getIndexBlocksNumber(String schemaName, String indexName) {
		ResultSet resultSet = null;
		String sql = null;
		PreparedStatement cstmt=null;
		
		int numeroBlocos = 0;
		
		try{
        	sql = "select relpages as num_paginas from pg_class where relname in (select indexname from pg_indexes where schemaname =? and indexname=?)";

        	cstmt = this.connection.prepareStatement(sql);
    		log.write( sql );
    		
    		cstmt.setString(1, schemaName);
    		cstmt.setString(2, indexName);
    				
    		resultSet = cstmt.executeQuery();
    		
    		if( resultSet != null ){
            	while( resultSet.next() ){
            		numeroBlocos = resultSet.getInt("relpages");	
            	}
    		}

        }
    	catch (SQLException e) {
        	log.write( e );
		}
		catch (NullPointerException e) {
        	log.write( e );
		}
		catch (Exception e) {
        	log.write( e );
		}
		return numeroBlocos;
	}
	
	/**
	 * M�todo usado para clusterizar uma tabela
	 * @param tableName Nome da tabela a ser clusterizada
	 * @param realIndexName Nome do �ndice a ser usado na clusteriza��o da tabela
	 */
	public void clusterTable(String tableName, String realIndexName){
		
		PreparedStatement cstmt = null;
		
		String sql = null;

		//Clusteriza a tabela usando o �ndice
        try{
        	sql = signature+ " CLUSTER ? ON ?";
        	cstmt = this.connection.prepareStatement(sql);
        	
        	cstmt.setString(1, realIndexName);
        	cstmt.setString(2, tableName);
        	//cstmt.executeUpdate(sql);
        	
        	cstmt.close();
        }
    	catch (SQLException e) {
   			log.write( e );
   			return;
		}
		catch (NullPointerException e) {
			log.write( e );
			return;
		}
		catch (Exception e) {
			log.write( e );
			return;
		}
		
	}

	/**
	 * M�todo usado para atualizar o nome de um �ndice na MetaBase Local
	 * @param ciId Identificador do �ndice a ser atualizado
	 * @param realIndexName Nome do �ndice a ser usado na atualiza��o
	 */
	public void updateIndexName(int cidId, String realIndexName){
		PreparedStatement cstmt = null;
		
		String sql = null;

        try{
        	sql = signature+ " update tb_candidate_index set cid_index_name = ?, cid_status=? where cid_id=?";
        	cstmt = this.connection.prepareStatement(sql);
        	
        	cstmt.setString(1, realIndexName);
        	cstmt.setString(2, "R");
        	cstmt.setInt(3, cidId);
        	cstmt.executeUpdate(sql);
        	
        	cstmt.close();
        }
    	catch (SQLException e) {
   			log.write( e );
   			return;
		}
		catch (NullPointerException e) {
			log.write( e );
			return;
		}
		catch (Exception e) {
			log.write( e );
			return;
		}
	}
	
	/** M�todo Finalize **/
	public void  finalize(){
    	try{
    		connection.close();
    	}
    	catch (SQLException e) {
    		log.write( e );
		}
		catch (NullPointerException e) {
    		log.write( e );
		}
		catch (Exception e) {
    		log.write( e );
		}
    }	

}
