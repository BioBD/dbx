package drivers.postgres;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

import util.Log;

import agents.WOAgent;

import drivers.SADriver;
import entity.IndexCandidate;
import entity.Task;

/**
 * @author Jos� Maria
 * Classe usada para representar "Driver for Statistics Access" no Postgres
 * Obt�m informa��es estatsticas de uma determinada tabela do banco
 */
public class PostgreSqlSADriver implements SADriver {

    /** vari�vel que representa uma conex�o com o Postgres **/
    //protected Connection connection = null;
    /** vari�vel utilizada para acessar um arquivo de propriedades **/
    //protected Properties properties;
    /** vari�vel que representa uma Assinatura **/
    protected String signature = null;
    /** vari�vel boolean indica se o programa est� rodando em modo debug ou n�o **/
    protected boolean debug = true;
    /** vari�vel utilizada para manipular logs **/
    protected Log log = null;
    /*vari�vel que representa uma inst�ncia de PostgreSqlSADriver */
    private static PostgreSqlSADriver instance;

    /** M�todo Construtor **/
    public PostgreSqlSADriver() {
        log = new Log();
        try {
            connect();
        } catch (SQLException e) {
            log.write(e);
        } catch (ClassNotFoundException e) {
            log.write(e);
        } catch (Exception e) {
            log.write(e);
        }
    }

    public static PostgreSqlSADriver getInstance() {
        if (instance == null) {
            instance = new PostgreSqlSADriver();
        }
        return instance;
    }

//	public Connection getConnection() throws IOException, ClassNotFoundException, SQLException {
//		if(connection == null) {
//			connect();
//		}
//		return connection;
//	}
//	
    public Connection connect() throws IOException, ClassNotFoundException, SQLException {
        Properties properties = new Properties();
        properties.load(WOAgent.class.getResourceAsStream("database.properties"));
        signature = properties.getProperty("signature");
        String driver = properties.getProperty("driverPostgres");
        String url = properties.getProperty("urlPostgres");
        String user = properties.getProperty("userPostgres");
        String passwd = properties.getProperty("pwdPostgres");
        Class.forName(driver);
        Connection connection = DriverManager.getConnection(url, user, passwd);
        return connection;
    }

    public ArrayList<String> getFieldsNames(String tableName) throws SQLException, IOException, ClassNotFoundException {
        Connection connection = connect();
        ArrayList<String> fieldsNames = new ArrayList<String>();
        String sqlClauseToGetTheFieldsNames = "Select attname"
                + " From pg_class c , pg_attribute a"
                + " Where c.relname = ? "
                + " AND c.oid = a.attrelid AND attstattarget < 0";
        PreparedStatement preparedStatement = connection.prepareStatement(sqlClauseToGetTheFieldsNames);

        preparedStatement.setString(1, tableName);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            String currentField = resultSet.getString("attname");
            fieldsNames.add(currentField);
        }
        connection.close();
        return fieldsNames;
    }

    public int getNextCandidateIndexId() throws SQLException, IOException, ClassNotFoundException {
        Connection connection = connect();
        int nextId = 0;
        Statement statement = connection.createStatement();
        String sqlClauseToGetNextId = signature + "SELECT MAX(cid_id) as maxId FROM agent.tb_candidate_index";
        ResultSet resultSet = statement.executeQuery(sqlClauseToGetNextId);

        if (resultSet.next()) {
            nextId = resultSet.getInt("maxId");
        }
        statement.close();
        resultSet.close();
        nextId++;
        connection.close();
        return nextId;
    }

    public float getAttSelectivity(String tableName, String attName,
            String op, String value) throws java.text.ParseException, IOException, ClassNotFoundException, SQLException {
        Connection connection = connect();
        // FS(A,r)
        float fs = 1f;
        String type;
        try {
            type = this.getColumnType(tableName, attName);
            if (type.equals("date") || type.matches("int.*") || type.matches("float.*")) {
                fs = getHistogramSelectivity(tableName, attName, op, value, type);
            } else if (type.equals("bpchar")) {
                fs = getMCVSelectivity(tableName, attName, value);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return fs;
    }

    public int estimateIndexPagesNumber(IndexCandidate indexCandidate) throws IOException, ClassNotFoundException, SQLException {
        String tableName = indexCandidate.getTableName();
        ArrayList<String> fields = indexCandidate.getColumns();
        double treeHeight = getIndexTreeHeight(tableName, fields);
        double numValues = this.getTreeOrder(tableName, fields) - 1;
        double minChildren = numValues / 2;
        int sum = 0;
        double numTuples = getRowsNumber(tableName);
        double power = 1 / treeHeight;
        numTuples = numTuples * 2;
        minChildren = Math.pow(numTuples / numValues, power);
        minChildren = (int) Math.ceil(minChildren);


        for (int i = 0; i <= treeHeight; i++) {
            sum = (int) (sum + Math.pow(minChildren, i));
        }

        return sum;
    }

    public long getIndexTreeHeight(String tableName, ArrayList<String> fields) throws IOException, ClassNotFoundException, SQLException {
        double order = getTreeOrder(tableName, fields );
        double indexHeight = Math.log(getTableLength(tableName));
        indexHeight = indexHeight / Math.log(order / 2);
        if (indexHeight > 4) {
            System.out.println("indexHeight: " + indexHeight);
        }

        return (long) Math.ceil(indexHeight);
    }
    
    public double getTreeOrder(String tableName, ArrayList<String> fields) throws IOException, ClassNotFoundException, SQLException {
        Connection connection = connect();
        // HTi = log_(o/2) p
        // p = number of pages; o = table order
        double pageSize = 8192;
        double pointerSize = 4;
        double searchKeySize = 0;
        Statement stmt;
        try {
            stmt = connection.createStatement();
            ResultSet rs;
            for (int i = 0; i < fields.size(); i++) {
                rs = stmt.executeQuery("SELECT typlen from pg_attribute t1, pg_type t2 WHERE "
                        + "t1.atttypid = t2.oid and t1.attname = '"
                        + fields.get(i)
                        + "' and t1.attrelid = "
                        + "(SELECT oid FROM pg_class WHERE relname = '"
                        + tableName + "')");
                rs.next();
                searchKeySize += Double.parseDouble(rs.getString(1));
                if (searchKeySize < 0) {
                    searchKeySize = 20; // tamanho em bytes de uma chave de busca com 20 caracteres
                }
            }
        } catch (SQLException e) {
            searchKeySize = 4;
            e.printStackTrace();
        }
        double order = (pageSize + searchKeySize) / (pointerSize + searchKeySize);
        return order;
    }

    public float getMCVSelectivity(String tableName, String attName, String value) throws SQLException, IOException, ClassNotFoundException {
        Connection connection = connect();
        // TODO MEGA TODO PRA FAZER AQUIIIIIIII
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT null_frac, n_distinct, most_common_vals, most_common_freqs FROM pg_stats WHERE tablename='" + tableName + "'"
                + " AND attname='" + attName + "';");
        rs.next();

        float nDisctinct = this.getNDistinct(tableName, attName);
        if (nDisctinct == -1) {
            return nDisctinct * -1;
        } else if (nDisctinct > 0) {
            return this.getTableLength(tableName) / nDisctinct;
        } else {
            System.out.println("MCV EXPLODIU!");
        }
        connection.close();
        return 0;
    }

    public float getNDistinct(String tableName, String attName)
            throws SQLException, IOException, ClassNotFoundException {
        Connection connection = connect();
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT n_distinct FROM pg_stats WHERE tablename='"
                + tableName + "' AND attname='" + attName + "';");
        rs.next();
        connection.close();
        return rs.getFloat(1);
    }

    //numero de tuplas
    public float getTableLength(String tableName) throws SQLException, IOException, ClassNotFoundException {
        Connection connection = connect();
        Statement stmt;
        float num_tuples = 1;
        try {
            stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT reltuples FROM pg_class WHERE relname='"
                    + tableName + "';");
            rs.next();
            num_tuples = rs.getFloat(1);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        connection.close();
        return num_tuples;
    }

    public String getColumnType(String tableName, String attName)
            throws SQLException, IOException, ClassNotFoundException {
        Connection connection = connect();
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT typname from pg_attribute t1, pg_type t2 WHERE "
                + "t1.atttypid = t2.oid and t1.attname = '"
                + attName
                + "' and t1.attrelid = "
                + "(SELECT oid FROM pg_class WHERE relname = '"
                + tableName + "')");
        connection.close();
        return rs.next() ? rs.getString(1) : null;
    }

    public float getHistogramSelectivity(String tableName, String attName, String op, String value, String type) throws java.text.ParseException, IOException, ClassNotFoundException, SQLException {
        Connection connection = connect();
        float fs = 0.5f;

        try {
            if (op.equals("=")) {
                fs = this.getNDistinct(tableName, attName);
                if (fs > 0) {
                    fs = this.getTableLength(tableName) / fs;
                } else {
                    fs *= -1;
                }
                fs = (float) Math.pow(fs, -1);
            } else if (op.equals("<") || op.equals("<=")) {
                float longValue = 0f;
                if (type.equals("date")) {
                    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    longValue = dateFormat.parse(stripSimpleQuotes(value)).getTime();
                } else {
                    longValue = Long.parseLong(value);
                }

                float[] bucketValue = getHistogramBucket(tableName, attName, type);
                for (int i = 0; i < bucketValue.length; i++) {
                    if (longValue <= bucketValue[i] && longValue >= bucketValue[i - 1]) {
                        fs = (i - 1 + (longValue - bucketValue[i - 1]) / (bucketValue[i] - bucketValue[i - 1])) / (bucketValue.length - 1);
                        break;
                    }
                }
            } else if (op.equals(">") || op.equals(">=")) {
                float[] bucketValues = getHistogramBucket(tableName, attName, type);
                long longValue = 0;
                if (type.equals("date")) {
                    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    longValue = dateFormat.parse(stripSimpleQuotes(value)).getTime();
                } else {
                    longValue = Long.parseLong(value);
                }
                for (int i = bucketValues.length - 2; i > 0; i--) {
                    if (longValue >= bucketValues[i] && longValue <= bucketValues[i + 1]) {
                        fs = (bucketValues.length - i - 1 + (bucketValues[i + 1] - longValue));
                        fs /= (bucketValues[i + 1] - bucketValues[i]);
                        fs /= bucketValues.length - 1;
                        break;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return fs;
    }

    public float[] getHistogramBucket(String tableName, String attName, String type) throws SQLException, java.text.ParseException, IOException, ClassNotFoundException {
        Connection connection = connect();
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT histogram_bounds FROM pg_stats WHERE tablename='" + tableName
                + "' AND attname='" + attName + "'");
        rs.next();
        String result = rs.getString(1);
        result = result.substring(1, result.length() - 1);
        String[] histogram = result.split(",");
        float[] bucketValue = null;
        bucketValue = new float[histogram.length + 1];
        bucketValue[0] = 0;
        if (type.equals("date")) {
            for (int i = 1; i < histogram.length; i++) {
                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                try {
                    bucketValue[i] = dateFormat.parse(histogram[i - 1]).getTime();
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        } else if (type.matches("int.*")) {
            for (int j = 0; j < histogram.length; j++) {
                bucketValue[j] = Long.parseLong(histogram[j - 1]);
            }
        }
        connection.close();
        return bucketValue;
    }
    //used
    public String stripSimpleQuotes(String string) throws IOException, ClassNotFoundException, SQLException {
        Connection connection = connect();
        if (string.charAt(0) == '\'' && string.charAt(string.length() - 1) == '\'') {
            return string.substring(1, string.length() - 2);
        }
        return string;
    }

    /**not used
     * M�todo utilizado para verificar se um determinado �ndice existe no Postgres
     * @param schemaName nome do schema
     * @param tableName nome da tabela
     * @param collumnName nome das colunas que comp�em o �ndice
     * @return true se o �ndice existe e false se o �ndice n�o existe
     */
    public boolean indexExist(String schemaname, String tableName, String[] collumnName) throws Exception {
        Connection connection = connect();
        ResultSet resultSet = null;
        //Statement stmt = connection.createStatement();
        ArrayList<String> indexes = new ArrayList<String>();
        ArrayList<String> searchKey = new ArrayList<String>();
        boolean exist = true;

        int contNotExist = 0;

        //Recupera os �ndices definidos sobre a tabela tableName
        String sql = signature + "select i.indexname from pg_indexes i where i.schemaname=? and i.tablename=?";
        PreparedStatement cstmt = connection.prepareStatement(sql);
        log.write(sql);
        cstmt.setString(1, schemaname);
        cstmt.setString(2, tableName);

        resultSet = cstmt.executeQuery();

        if (resultSet != null) {
            while (resultSet.next()) {
                indexes.add(resultSet.getString("indexname"));
            }
        }

        resultSet.close();
        cstmt.close();

        //Verifica se o �ndice desejado j� existe fisicamente
        for (int i = 0; i < indexes.size(); i++) {

            sql = signature + "select a.attname from pg_class c, pg_indexes i, pg_attribute a where c.relname=i.indexname and i.schemaname=? and i.tablename=? and i.indexname = ? and c.oid=a.attrelid";

            cstmt = connection.prepareStatement(sql);

            log.write(sql);

            cstmt.setString(1, schemaname);
            cstmt.setString(2, tableName);
            cstmt.setString(3, (String) indexes.get(i));

            resultSet = cstmt.executeQuery();

            searchKey = new ArrayList<String>();

            if (resultSet != null) {
                while (resultSet.next()) {
                    searchKey.add((String) resultSet.getString("attname"));
                }
            }

            for (int j = 0; j < collumnName.length; j++) {
                if (!searchKey.contains(collumnName[j])) {
                    contNotExist++;
                    break;
                }
            }

        }

        if (contNotExist == indexes.size()) {
            exist = false;
        }
        connection.close();
        return exist;
    }

    /**not used
     * M�todo utilizado para recuperar as �ltimas consultas executadas e ainda n�o avaliadas no Postgres
     * @return ArrayList contendo o texto (SQL) das consultas capturadas pelo WOAgent e ainda n�o analizadas pelo FISAgent
     */
    @SuppressWarnings("unchecked")
    public ArrayList getQueryList() throws Exception {
        Connection connection = connect();
        ResultSet resultSet = null;
        ArrayList queryList = new ArrayList();
        String sql = signature + "select wld_id from agent.tb_workload where wld_capture_count > wld_analyze_count";
        String id;
        Statement statement = connection.createStatement();
        resultSet = statement.executeQuery(sql);

        if (resultSet != null) {
            while (resultSet.next()) {
                id = resultSet.getString("wld_id");
                queryList.add(id);
                //enableQueryFlag( Integer.parseInt( id ) ); 
            }
        }
        //log.write( queryList.size()+" querys returned..." );
        resultSet.close();
        statement.close();
        connection.close();
        return queryList;
    }

    /**not used
     * M�todo utilizado para setar a flag  wld_fl_exec com o valor 'S'. Isto indica que a consulta SQL j� foi analisada pelo FISAgent.
     * @param queryId identificador de uma determinada cl�usula SQL
     */
    public void enableQueryFlag(int query_id) throws Exception {
        Connection connection = connect();
        Statement statement = connection.createStatement();
        String sqlClause = signature + "update agent.tb_workload set wld_fl_exec = 'S' where wld_id = " + query_id;
        statement.executeUpdate(sqlClause);
        statement.close();
        connection.close();
    }

    /**used
     * M�todo que retorna o numeroLinhas de uma determinada tabela (passada como par�metro) no PostgreSQL.
     * @param tableName nome da tabela (da qual se deseja obter o n�mero de linhas)
     * @return numeroLinhas n�mero de linhas da tabela passada como par�metro (tableName)
     * @throws SQLException 
     * @throws ClassNotFoundException 
     * @throws IOException 
     */
    public int getRowsNumber(String tableName) throws SQLException, IOException, ClassNotFoundException {
        Connection connection = connect();
        ResultSet resultSet = null;
        int numeroLinhas = 0;

        try {
            String sqlClause = " select reltuples as num_linhas from pg_class where relname in ("
                    + " select tablename from pg_tables where schemaname like 'public'"
                    + " and tablename like '" + tableName + "')";
            Statement statement = connection.createStatement();
            resultSet = statement.executeQuery(sqlClause);
            resultSet.next();
            numeroLinhas = resultSet.getInt("num_linhas");
        } catch (SQLException e) {
            log.write(e);
        } catch (NullPointerException e) {
            log.write(e);
        } catch (Exception e) {
            log.write(e);
        }
        connection.close();
        return numeroLinhas;
    }

    /**
     * M�todo que retorna o numero de blocos (p�ginas de disco) de uma determinada tabela no PostgreSQL
     * @param tableName nome da tabela (da qual se deseja obter o n�mero de blocos)
     * @return numeroBlocos n�mero de blocos (p�ginas de dados) da tabela passada como par�metro (tableName)
     * @throws SQLException 
     * @throws ClassNotFoundException 
     * @throws IOException 
     */
    public int getBlocksNumber(String tableName) throws SQLException, IOException, ClassNotFoundException {
        Connection connection = connect();
        ResultSet resultSet = null;
        int numeroBlocos = 0;
        try {
            String sqlClause = " select relpages as num_paginas from pg_class where relname in ("
                    + " select tablename from pg_tables where schemaname like 'public'"
                    + " and tablename like '" + tableName + "')";
            Statement statement = connection.createStatement();
            resultSet = statement.executeQuery(sqlClause);
            if (resultSet.next()) {
                numeroBlocos = resultSet.getInt("num_paginas");
            }
        } catch (SQLException e) {
            log.write(e);
        } catch (NullPointerException e) {
            log.write(e);
        } catch (Exception e) {
            log.write(e);
        }
        connection.close();
        return numeroBlocos;
    }

    /**not used
     * M�todo que retorna o numero de blocos (p�ginas de disco) de uma determinada tabela no PostgreSQL
     * @param tableName nome da tabela (da qual se deseja obter o n�mero de linhas)
     * @return numeroBlocos n�mero de blocos (p�ginas de dados) da tabela passada como par�metro (tableName)
     * @throws SQLException 
     * @throws ClassNotFoundException 
     * @throws IOException 
     */
    public int getBlocksNumber(String schemaName, String tableName) throws IOException, ClassNotFoundException, SQLException {
        Connection connection = connect();
        ResultSet resultSet = null;
        int numeroBlocos = 0;
        try {
            String sqlClause = " select relpages as num_paginas from pg_class where relname in ("
                    + " select tablename from pg_tables where schemaname like '" + schemaName + "'"
                    + " and tablename like '" + tableName + "')";
            Statement statement = connection.createStatement();
            resultSet = statement.executeQuery(sqlClause);
            resultSet.next();
            numeroBlocos = resultSet.getInt("num_paginas");
        } catch (SQLException e) {
            log.write(e);
        } catch (NullPointerException e) {
            log.write(e);
        } catch (Exception e) {
            log.write(e);
        }
        return numeroBlocos;
    }

    /**not used
     * M�todo que retorna o nomeIndice.
     * @param tableName nome da tabela (da qual se deseja recuperar o conjunto de �ndices existentes)
     * @return nomeIndice lista com os nomes dos �ndices existentes sobre a tabela passada como par�metro (tableName)
     * @throws SQLException 
     * @throws ClassNotFoundException 
     * @throws IOException 
     */
    @SuppressWarnings("unchecked")
    public List getIndexName(String tableName) throws SQLException, IOException, ClassNotFoundException {
        Connection connection = connect();
        ResultSet resultSet = null;
        ArrayList indexName = new ArrayList();
        try {
            String sqlClause = " select indexname from pg_indexes"
                    + " where schemaname like 'public'"
                    + " and tablename like '" + tableName + "'";
            Statement statement = connection.createStatement();
            resultSet = statement.executeQuery(sqlClause);
            while (resultSet.next()) {
                indexName.add(resultSet.getString("indexname"));
            }
        } catch (SQLException e) {
            log.write(e);
        } catch (NullPointerException e) {
            log.write(e);
        } catch (Exception e) {
            log.write(e);
        }
        connection.close();
        return indexName;
    }

    /**not used
     * M�todo utilizado para verificar se um determinado campo (coluna) de uma determinada tabela � chave prim�ria no Postgres
     * @param tableName nome da tabela
     * @param columnName nome da coluna (atributo)
     * @return true se o atributo columnName for chave prim�ria de tableName e false caso contr�rio
     */
    public boolean isPrimaryKey(String table, ArrayList<String> atribute) throws Exception {
        Connection connection = connect();
        boolean result = true;

        if (atribute.size() > 0) {
            for (int i = 0; i < atribute.size(); i++) {
                ResultSet resultSet = null;
                Statement statement = connection.createStatement();

                String sqlClause = signature + "SELECT attname as collumn, pg_constraint.contype FROM pg_class, pg_attribute, pg_constraint WHERE pg_class.oid=attrelid and pg_class.oid = conrelid and contype  = 'p' AND attnum>0 and lower(attname) = '" + atribute.get(i) + "'" + " and relname='" + table + "'";
                resultSet = statement.executeQuery(sqlClause);
                if (resultSet.next()) {
                    if (!resultSet.getString("contype").equalsIgnoreCase("p")) {
                        result = false;
                    }
                }
                resultSet.close();
                statement.close();
            }
        } else {
            result = false;
        }
        return result;
    }

    /**not used
     * M�todo utilizado para recuperar o n�mero de linhas (tuplas) de uma determinada tabela (passada como par�metro) no Postgres
     * @param schemaName nome do schema
     * @param tableName nome da tabela
     * @return quantidade de linhas (tulas) da tabela  tableName
     */
    public int getTableRowCount(String schemaname, String tableName) throws Exception {
        Connection connection = connect();
        ResultSet resultSet = null;
        int lineCount = 0;
        Statement statement = connection.createStatement();
        String sqlClause = signature + " select reltuples as linecount from pg_class where relname in ("
                + " select tablename from pg_tables where schemaname like '" + schemaname + "'"
                + " and tablename like '" + tableName + "')";
        resultSet = statement.executeQuery(sqlClause);
        if (resultSet.next()) {
            lineCount = resultSet.getInt("linecount");
        }
        resultSet.close();
        statement.close();
        return lineCount;
    }

    /**not used
     * Mtodo que retorna a alturaArvore.
     * @return deepTree
     */
    public int getDeepTree(String tableName) {
        //TODO n�mero fixo
        return 3;
    }

    /**not used
     * M�todo utilizado para recuperar o m�todo de acesso de um determinado �ndice (passado como par�metro)
     * @param indexName nome do �ndice
     * @return m�todo de acesso do �ndice passado com par�metro
     * @throws SQLException 
     * @throws ClassNotFoundException 
     * @throws IOException 
     */
    public String getAccessMethod(String indexName) throws IOException, ClassNotFoundException, SQLException {
        Connection connection = connect();
        ResultSet resultSet = null;
        String metodoAcesso = "";
        try {
            String sqlClause = " select (select amname from pg_am where pg_am.oid= pg_class.relam) as nome"
                    + " from pg_class where relname like (select indexname from pg_indexes"
                    + " where schemaname like 'public'"
                    + " and indexname like '" + indexName + "')";
            Statement statement = connection.createStatement();
            resultSet = statement.executeQuery(sqlClause);
            resultSet.next();
            metodoAcesso = resultSet.getString("nome");
        } catch (SQLException e) {
            log.write(e);
        } catch (NullPointerException e) {
            log.write(e);
        } catch (Exception e) {
            log.write(e);
        }
        return metodoAcesso;
    }

    /**not used
     * M�todo utilizado para recuperar o tipo de uma express�o SQL (Tarefa)
     * @param wldId id da express�o SQL (tarefa)
     * @return tipo da express�o SQL (Tarefa)
     * @throws SQLException 
     * @throws ClassNotFoundException 
     * @throws IOException 
     */
    public String getTaskType(int wldId) throws IOException, ClassNotFoundException, SQLException {
        Connection connection = connect();
        ResultSet resultSet = null;
        PreparedStatement cstmt = null;
        String wldType = null;

        //Recupera o tipo da express�o SQL
        try {
            String sql = "select wld_type from agent.tb_workload where wld_id=?";
            cstmt = connection.prepareStatement(sql);
            log.write(sql);
            cstmt.setInt(1, wldId);

            resultSet = cstmt.executeQuery();

            if (resultSet != null) {
                if (resultSet.next()) {
                    wldType = resultSet.getString("wld_type");
                }
            }

            resultSet.close();
            cstmt.close();
        } catch (Exception e) {
            log.write(e);
        }

        return wldType;

    }

    /**not used
     * M�todo utilizado para recuperar a quantidade de vezes que uma express�o SQL (Tarefa) foi capturada e ainda n�o analisada
     * @param wldId id da express�o SQL (tarefa)
     * @return quantidade de vezes que uma express�o SQL (Tarefa) foi capturada e ainda n�o analisada
     * @throws SQLException 
     * @throws ClassNotFoundException 
     * @throws IOException 
     */
    public int getWldQtd(int wldId) throws IOException, ClassNotFoundException, SQLException {
        Connection connection = connect();
        ResultSet resultSet = null;
        PreparedStatement cstmt = null;
        int wldQtd = 0;

        try {
            String sql = "select (wld_capture_count - wld_analyze_count) as qtd from agent.tb_workload where wld_id=?";
            cstmt = connection.prepareStatement(sql);
            log.write(sql);
            cstmt.setInt(1, wldId);

            resultSet = cstmt.executeQuery();

            if (resultSet != null) {
                if (resultSet.next()) {
                    wldQtd = resultSet.getInt("qtd");
                }
            }

            resultSet.close();
            cstmt.close();
        } catch (Exception e) {
            log.write(e);
        }

        return wldQtd;
    }

    /**not used
     * M�todo utilizado para recuperar o maior benef�cio acumulado dentre todos os �ndices candidatos (existentes na MetaBase Local) definidos sobre a tabela passada como par�metro
     * @param tableName nome da tabela
     * @return maior benef�cio acumulado dentre todos os �ndices candidatos (existentes na MetaBase Local) definidos sobre a tabela passada como par�metro
     * @throws SQLException 
     * @throws ClassNotFoundException 
     * @throws IOException 
     */
    public int getBestPrimaryIndexProfit(String tableName) throws IOException, ClassNotFoundException, SQLException {
        Connection connection = connect();
        ResultSet resultSet = null;
        PreparedStatement cstmt = null;
        int maxProfit = -1;

        try {
            String sql = "select max(cid_index_profit) as max_profit from agent.tb_candidate_index";
            cstmt = connection.prepareStatement(sql);
            log.write(sql);

            resultSet = cstmt.executeQuery();

            if (resultSet != null) {
                if (resultSet.next()) {
                    maxProfit = resultSet.getInt("max_profit");
                }
            }

            resultSet.close();
            cstmt.close();
        } catch (Exception e) {
            log.write(e);
        }

        return maxProfit;
    }

    /**not used
     * M�todo utilizado para verificar se existe algum �ndice candidato (na MetaBase Local), em estado real (status = "R") definido sobre a tabela passada como par�metro
     * @param tableName nome da tabela
     * @return valor booleano indicando se existe algum �ndice candidato (na MetaBase Local), em estado real (status = "R") definido sobre a tabela passada como par�metro
     * @throws SQLException 
     * @throws ClassNotFoundException 
     * @throws IOException 
     */
    public boolean existRealPrimaryIndex(String tableName) throws IOException, ClassNotFoundException, SQLException {
        Connection connection = connect();
        ResultSet resultSet = null;
        PreparedStatement cstmt = null;
        boolean existRealPrimaryIndex = false;

        try {
            String sql = "select cid_id from agent.tb_candidate_index where cid_table_name=? and cid_type='C' and cid_status='R'";
            cstmt = connection.prepareStatement(sql);
            log.write(sql);
            cstmt.setString(1, tableName);
            resultSet = cstmt.executeQuery();

            if (resultSet != null) {
                if (resultSet.next()) {
                    existRealPrimaryIndex = true;
                }
            }

            resultSet.close();
            cstmt.close();
        } catch (Exception e) {
            log.write(e);
        }

        return existRealPrimaryIndex;
    }

    /**not used
     * M�todo utilizado para recuperar o nome do �ndice candidato prim�rio, cujo estado seja real (status = "R"), definido sobre a tabela passada como par�metro(na MetaBase Local)
     * @param tableName nome da tabela
     * @return indexName nome do �ndice
     * @throws SQLException 
     * @throws ClassNotFoundException 
     * @throws IOException 
     */
    public String getRealPrimaryIndexName(String tableName) throws IOException, ClassNotFoundException, SQLException {
        Connection connection = connect();
        ResultSet resultSet = null;
        PreparedStatement cstmt = null;
        String indexName = null;

        try {
            String sql = "select cid_index_name from agent.tb_candidate_index where cid_table_name=? and cid_status='R' and cid_type='C'";
            cstmt = connection.prepareStatement(sql);
            log.write(sql);
            cstmt.setString(1, tableName);
            resultSet = cstmt.executeQuery();

            if (resultSet != null) {
                if (resultSet.next()) {
                    indexName = resultSet.getString("cid_index_name");
                }
            }

            resultSet.close();
            cstmt.close();
        } catch (Exception e) {
            log.write(e);
        }

        return indexName;
    }

    /**not used
     * M�todo utilizado para recuperar o id (identificador) de um �ndice candidato (armazenado na MetaBase Local)
     * @param tableName nome da tabela
     * @param field ArrayList contendo as colunas (campos) que comp�em o �ndice
     * @param type Tipo do �ndice (Prim�rio (C-Clustering) ou Secund�rio (U-Unclustering))
     * @return identificado do �ndice
     * @throws ClassNotFoundException 
     * @throws IOException 
     */
    public int getIndexIdLM(String tableName, ArrayList<String> field, String type) throws SQLException, IOException, ClassNotFoundException {
        Connection connection = connect();
        ResultSet resultSet = null;
        ArrayList<String> indexes = new ArrayList<String>();
        ArrayList<String> searchKey = new ArrayList<String>();
        int ciId = 0;

        int contNotExist = 0;

        //Recupera os �ndices candidatos definidos sobre a tabela tableName
        String sql = "select ci.cid_id from agent.tb_candidate_index ci where ci.ci_table_name=? and ci.type=?";
        PreparedStatement cstmt = connection.prepareStatement(sql);
        log.write(sql);
        cstmt.setString(1, tableName);
        cstmt.setString(2, type);

        resultSet = cstmt.executeQuery();

        if (resultSet != null) {
            while (resultSet.next()) {
                indexes.add(resultSet.getString("cid_id"));
            }
        }

        resultSet.close();
        cstmt.close();

        //Procura o id do �ndice desejado
        for (int i = 0; i < indexes.size(); i++) {

            sql = "select cic.cid_column_name from agent.tb_candidate_index_column cic where cic.cid_id = ?";

            cstmt = connection.prepareStatement(sql);

            log.write(sql);

            cstmt.setInt(1, Integer.parseInt(indexes.get(i)));

            resultSet = cstmt.executeQuery();

            searchKey = new ArrayList<String>();

            if (resultSet != null) {
                while (resultSet.next()) {
                    searchKey.add((String) resultSet.getString("cic_column_name"));
                }
            }

            contNotExist = 0;
            if (searchKey.size() == field.size()) {
                for (int j = 0; j < field.size(); j++) {
                    if (!searchKey.contains(field.get(j))) {
                        contNotExist++;
                        break;
                    }
                }
            }
            if (contNotExist == 0) {
                ciId = Integer.parseInt(indexes.get(i));
            }

        }

        return ciId;
    }

    /**not used
     * M�todo utilizado para verificar se um determinado �ndice real existente no PostgreSQL � prim�rio (clusterizado)
     * @param schemaName nome do Schema
     * @param tableName nome da tabela
     * @param fields ArrayList contendo as colunas (campos) que comp�em o �ndice
     * @return valor booleano indicando se o �ndice, cujos dados passados por par�metro, existe no PostgreSQL e est� clusterizado
     * @throws SQLException 
     * @throws ClassNotFoundException 
     * @throws IOException 
     */
    public boolean isClustered(String schemaName, String tableName, ArrayList<String> fields) throws IOException, ClassNotFoundException, SQLException {
        Connection connection = connect();
        ResultSet resultSet = null;
        ArrayList<String> indexes = new ArrayList<String>();
        ArrayList<String> searchKey = new ArrayList<String>();
        boolean isClustered = false;
        String indexName = null;

        int contNotExist = 0;

        //Recupera o nome do �ndice utilizado para clusterizar a tabela
        String sql = signature + "select c.relname from pg_class c, pg_index i, pg_class t where c.oid = i.indexrelid and t.oid = i.indrelid and t.relname=? and indisclustered=true";

        try {
            PreparedStatement cstmt = connection.prepareStatement(sql);
            log.write(sql);
            //cstmt.setString(1, schemaName);
            cstmt.setString(1, tableName);

            resultSet = cstmt.executeQuery();

            if (resultSet != null) {
                if (resultSet.next()) {
                    indexName = resultSet.getString("relname");
                } else {
                    return false;
                }
            }

            resultSet.close();
            cstmt.close();

            //Verifica se o �ndice passado como par�metro � o �ndice utilizado para clusterizar a tabela

            sql = signature + "select a.attname from pg_class c, pg_indexes i, pg_attribute a where c.relname=i.indexname and i.schemaname=? and i.tablename=? and c.oid=a.attrelid and i.indexname = ?";

            cstmt = connection.prepareStatement(sql);

            log.write(sql);

            cstmt.setString(1, schemaName);
            cstmt.setString(2, tableName);
            cstmt.setString(3, indexName);

            resultSet = cstmt.executeQuery();

            searchKey = new ArrayList<String>();

            if (resultSet != null) {
                while (resultSet.next()) {
                    searchKey.add((String) resultSet.getString("attname"));
                }
            }

            for (int j = 0; j < fields.size(); j++) {
                if (!searchKey.contains(fields.get(j))) {
                    contNotExist++;
                    break;
                }
            }

            if (contNotExist == indexes.size()) {
                isClustered = true;
            }
        } catch (SQLException e) {
            log.write(e);
        }

        return isClustered;
    }

    /**not used
     * M�todo utilizado para recuperar o nome de um �ndice real (nome f�sico do �ndice)
     * @param schemaName nome do Schema
     * @param tableName nome da tabela
     * @param fields ArrayList contendo as colunas (campos) que comp�em o �ndice
     * @return Nome do �ndice (como criado fisicamente no PostgreSQL)
     * @throws SQLException 
     * @throws ClassNotFoundException 
     * @throws IOException 
     */
    public String getIndexName(String schemaName, String tableName, ArrayList<String> fields) throws IOException, ClassNotFoundException, SQLException {
        Connection connection = connect();
        ResultSet resultSet = null;
        ArrayList<String> indexes = new ArrayList<String>();
        ArrayList<String> searchKey = new ArrayList<String>();
        String indexName = null;

        int contAtribs = 0;

        try {
            //Recupera os �ndices definidos sobre a tabela tableName
            String sql = signature + "select i.indexname from pg_indexes i where i.schemaname=? and i.tablename=?";
            PreparedStatement cstmt = connection.prepareStatement(sql);
            log.write(sql);
            cstmt.setString(1, schemaName);
            cstmt.setString(2, tableName);

            resultSet = cstmt.executeQuery();

            if (resultSet != null) {
                while (resultSet.next()) {
                    indexes.add(resultSet.getString("indexname"));
                }
            }

            resultSet.close();
            cstmt.close();

            //Para cada �ndice recupera os seus atributos
            for (int i = 0; i < indexes.size(); i++) {

                sql = signature + "select a.attname from pg_class c, pg_indexes i, pg_attribute a where c.relname=i.indexname and i.schemaname=? and i.tablename=? and i.indexname = ? and c.oid=a.attrelid";

                cstmt = connection.prepareStatement(sql);

                log.write(sql);

                cstmt.setString(1, schemaName);
                cstmt.setString(2, tableName);
                cstmt.setString(3, (String) indexes.get(i));

                resultSet = cstmt.executeQuery();

                searchKey = new ArrayList<String>();

                if (resultSet != null) {
                    while (resultSet.next()) {
                        searchKey.add((String) resultSet.getString("attname"));
                    }
                }

                contAtribs = 0;

                for (int j = 0; j < fields.size(); j++) {
                    if (searchKey.contains(fields.get(j))) {
                        contAtribs++;
                    } else {
                        break;
                    }
                }

                if ((contAtribs == fields.size()) && (fields.size() == searchKey.size())) {
                    indexName = indexes.get(i);
                }

            }
        } catch (SQLException e) {
            log.write(e);
        }


        return indexName;
    }

    /**not used
     * M�todo utilizado para atualizar a quantidade de vezes que a express�o SQL foi analisada
     * @param wldId Id da express�o SQL do Schema
     * @throws SQLException 
     * @throws ClassNotFoundException 
     * @throws IOException 
     */
    public void updateWldAnalyzeCount(int wldId) throws IOException, ClassNotFoundException, SQLException {
        Connection connection = connect();
        try {
            Statement statement = connection.createStatement();
            String sqlClause = signature + "update agent.tb_workload set wld_analyze_count = wld_capture_count where wld_id = " + wldId;
            statement.executeUpdate(sqlClause);
            statement.close();
        } catch (SQLException e) {
            log.write(e);
        }
    }
    //not used
    public ArrayList getPartitionedPlan(int queryId) throws Exception {
        // TODO Auto-generated method stub
        return null;
    }
    /**
     * M�todo Finalize
     */
//	public void  finalize(){
//		try{
//			connection.close();
//		}
//		catch (SQLException e) {
//			log.write( e );
//		}
//		catch (NullPointerException e) {
//			log.write( e );
//		}
//		catch (Exception e) {
//			log.write( e );
//		}
//	}	
}
