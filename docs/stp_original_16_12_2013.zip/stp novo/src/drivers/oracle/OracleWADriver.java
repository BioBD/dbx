package drivers.oracle;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

import util.Log;

import agents.WOAgent;

import drivers.*;

/**
 * @author Jos� Maria
 * 		   Lucas Lemos
 * 
 * Classe usada para representar "Driver for Workload Obtainment" no Oracle
 * Respons�vel por capturar a carga de trabalho submetida ao SBD
 */
public class OracleWADriver implements WADriver {

	private String userName;
	private String password;
	private String urlAdress;
	private String driver;
	private Connection connection = null;
	private Properties propertiesFile;
	private String signatureToDifferentiate = null;
	private boolean debug = true;
	private Log log = null;
	private static String lastCapturedQuery = null;

	public OracleWADriver() {
		log = new Log();
		try {
			loadProperties();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			log.write(e1);
		}
		try {
			connect();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			log.write(e);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			log.write(e);
		}
	}

	public void loadProperties() throws IOException {
		propertiesFile = new Properties();
		propertiesFile.load(WOAgent.class.getResourceAsStream("database.properties"));
		signatureToDifferentiate = this.propertiesFile.getProperty("signature");
		driver = this.propertiesFile.getProperty("driverOracle");
		urlAdress = this.propertiesFile.getProperty("urlOracle");
		userName = this.propertiesFile.getProperty("userOracle");
		password = this.propertiesFile.getProperty("pwdOracle");
	}

	public void connect() throws ClassNotFoundException, SQLException {
		Class.forName(driver);
		this.connection = DriverManager.getConnection(urlAdress, userName, password);
	}

	public void closeConnection() throws SQLException {
		this.connection.close();
	}

	public void getLastExecutedQueries() throws SQLException {
		ResultSet queryData = null;
		ArrayList<String> partitionedPlan = null;
		ArrayList<String> capturedQueries = captureQueries();

		/* Percorre as consultas capturadas */
		for (int i = 0; i < capturedQueries.size(); i++) {
			//Recupera a pr�xima consulta capturada
			String currentQuery = capturedQueries.get(i);

			if (isQueryEqualsLastCapturedQuery(currentQuery)) {
				continue;
			} else {
				lastCapturedQuery = currentQuery;
			}
			partitionedPlan = getPartitionedPlan(currentQuery);
			String planJoined = joinPlanParts(partitionedPlan);
			//String planJoined = "teste";
			if (isQueryAlreadyCaptured(currentQuery)) {
				System.out.println("já foi capturada!!!!");
				updateQueryData(currentQuery);
			} else {
				System.out.println("n�o foi capturada ainda!!!!");
				insertQuery(currentQuery, planJoined);
				queryData = getQueryData(currentQuery);
				int queryId = queryData.getInt("wld_id");
				insertPartitionedQueryPlan(queryId, partitionedPlan);
			}
		}
		if (queryData != null) {
			queryData.close();
		}
	}

	public void updateQueryData(String query) throws SQLException {
		ResultSet queryData = getQueryData(query);
		int queryId = queryData.getInt("wld_id");

		ArrayList<String> partitionedPlan = getPartitionedPlan(query);
		String planJoined = joinPlanParts(partitionedPlan);
		String storedPlan = queryData.getString("wld_plan");

		if (!isCurrentPlanEqualsStoredPlan(planJoined, storedPlan)) {
			deletePartitionedQueryPlan(queryId);
			insertPartitionedQueryPlan(queryId, partitionedPlan);
		}

		String sqlUpdate = signatureToDifferentiate + 
		"update tb_workload set wld_capture_count = wld_capture_count + 1, wld_plan = ? where wld_id =?";

		PreparedStatement preparedStatement = this.connection.prepareStatement(sqlUpdate);
		log.write(sqlUpdate);
		preparedStatement.setString(1, planJoined);
		preparedStatement.setInt(2, queryId);

		preparedStatement.executeUpdate();
	}

	public boolean isCurrentPlanEqualsStoredPlan(String currentPlan, String storedPlan) {
		System.out.println("++++++++++"+currentPlan+"+++++++");
                System.out.println("++++++++++"+storedPlan+"+++++++");
                return storedPlan.equals(currentPlan);
	}

	public boolean isQueryEqualsLastCapturedQuery(String query) {
		return query.equals(lastCapturedQuery);
	}

	/**
	 *  @return ArrayList contendo as consultas SQL que est�o sendo executadas no Oracle
	 */
	@SuppressWarnings("unchecked")
	private ArrayList<String> captureQueries() throws SQLException {
		ResultSet resultset = null;
		Statement statement = this.connection.createStatement();
		ArrayList<String> capturedQuerys = new ArrayList<String>();

		String sqlClauseToCaptureCurrentQueries = signatureToDifferentiate
		+ "select vs.sql_id, sql_text "
		+ "from v$sql vs, v$session s "
		+ "where vs.sql_id = s.sql_id";

		resultset = statement.executeQuery(sqlClauseToCaptureCurrentQueries);

		//Percorre as consultas capturadas
		while (resultset.next()) {
			//Recupera a próxima consulta capturada
			String currentQuery = resultset.getString("sql_text");

			if (!isQueryGeneratedByDBMS(currentQuery)) {
				capturedQuerys.add(currentQuery);
			}
		}

		if (capturedQuerys.size() > 0) {
			log.write(capturedQuerys.size() + " query(s) capturated...");
                        System.out.println(capturedQuerys.get(0));
		}
		resultset.close();
		statement.close();
		return capturedQuerys;
	}

	public boolean isQueryGeneratedByDBMS(String query) {
		if ((!query.contains(this.signatureToDifferentiate)) && (!query.contains("pg_type")) && (!query.contains("<BIND>"))) {
			if (!query.equals("<command string not enabled>")) {
				return false;
			}
		}
		return true;
	}

	@SuppressWarnings("unchecked")
	private ArrayList<String> getPartitionedPlan(String query) throws SQLException {
		ResultSet resultset = null;
		Statement statement = this.connection.createStatement();

		//Armazena o plano de execu��o da consulta (de forma particionada, linha por linha)
		ArrayList<String> partitionedPlan = new ArrayList<String>();

		String sqlClauseToGetThePlan = signatureToDifferentiate 
		+"select operation, id "
		+"from v$sql_plan sp, v$sql s "
		+"where sp.sql_id = s.sql_id and sql_text = '" + query + "'";
		
		
		resultset = statement.executeQuery(sqlClauseToGetThePlan);

		while (resultset.next()) {
			partitionedPlan.add(resultset.getString("operation"));
		}

		resultset.close();
		statement.close();
		return partitionedPlan;
	}

	/**
	 * M�todo usado para recuperar o plano de consulta (execu��o) para uma determinada cl�usula SQL (fornecida como par�metro) em uma �nica String
	 * @param planParts plano de execu��o gerado (de forma particionada, linha a linha)
	 * @return plano de execu��o unificado (ou seja, em uma �nica String)
	 */
	private String joinPlanParts(ArrayList<String> planParts) {
		String planJoined = "";

		int numberOfPlansRows = planParts.size();
		for (int i = 0; i < numberOfPlansRows; i++) {
			planJoined += planParts.get(i);
		}
		return planJoined;
	}

	/**
	 * M�todo usado para verificar se uma determinada consulta (passada como par�metro) j� havia sido anteriormente recuperada
	 * @param query consulta SQL
	 * @return true se a cl�usula SQL query j� tiver sido anteriorente capturada, false caso contr�rio
	 */
	private boolean isQueryAlreadyCaptured(String query) throws SQLException {
		ResultSet resultset = null;

		String sqlClauseToCheckIfQueryIsAlreadyCaptured = signatureToDifferentiate + " select wld_id from tb_workload where wld_sql = '" + query + "'";
		Statement statement = this.connection.createStatement();
		
		log.write(sqlClauseToCheckIfQueryIsAlreadyCaptured);

		resultset = statement.executeQuery(sqlClauseToCheckIfQueryIsAlreadyCaptured);
		
		
		if (resultset.next()) {
			int temp = resultset.getInt("wld_id");
			System.out.println("resultset n�o vazio.....: " + temp);
			resultset.close();
			statement.close();
			return true;
		} else {
			resultset.close();
			statement.close();
			return false;
		}
	}

	/**
	 * M�todo usado para recuperar os dados de um elemento da carga de trabalho armazenado na meta-base
	 * @param query consulta SQL (ou seja, elemento da carga de trabalho do qual se deseja recuperar os dados)
	 * @return ResultSet contendo os dados requisitados so elemento da carga de trabalho recebido como par�metro
	 */
	private ResultSet getQueryData(String query) throws SQLException {
		ResultSet resultset = null;
		String sqlClauseToGetQueryData = signatureToDifferentiate + "select wld_id, wld_sql, wld_plan, wld_capture_count, wld_analyze_count from tb_workload where wld_sql = '"+query+"' ";
		PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClauseToGetQueryData);

		log.write(sqlClauseToGetQueryData);

		//preparedStatement.setString(1, query);
		resultset = preparedStatement.executeQuery();
                System.out.println("----------------------"+query+"----------------------");
		if (resultset != null) {
			resultset.next();
		}             
		return resultset;
	}

	/**
	 * M�todo usado para cadastrar uma determinada consulta, juntamente com o seu plano de execu��o, na meta-base
	 * @param query consulta SQL
	 * @param plan plano de execu��o gerado pelo otimizador para a cl�usula SQL query
	 */
	private void insertQuery(String query, String plan) throws SQLException {
		int nextId = getNextId();
		String queryType = null;

		if (Util.retiraAspas(query).toUpperCase().startsWith("SELECT")) {
			queryType = "Q";
		} else if (Util.retiraAspas(query).toUpperCase().startsWith("UPDATE")) {
			queryType = "U";
		}
		else {
			queryType = "?";
		}

		String sqlClauseToInsertQuery = signatureToDifferentiate + "insert into tb_workload ( wld_id, wld_sql, wld_plan, wld_capture_count, wld_analyze_count, wld_type ) values (?,?,?,?,?,?)";
		PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClauseToInsertQuery);

		log.write(sqlClauseToInsertQuery);

		preparedStatement.setInt(1, nextId);
		preparedStatement.setString(2, query);
		preparedStatement.setString(3, plan);
		preparedStatement.setInt(4, 1);
		preparedStatement.setInt(5, 0);
		preparedStatement.setString(6, queryType);

		preparedStatement.executeUpdate();
	}

	/**
	 * M�todo usado para cadastrar o plano de execu��o de uma determinada cl�usula SQL na meta-base de forma quebrada(linha por linha)
	 * @param queryId identificador da cl�usula SQL
	 * @param partitionedPlan ArrayList contendo as partes que comp�em o plano de execu��o (na forma de uma �rvore de execu��o)
	 */
	private void insertPartitionedQueryPlan(int queryId, ArrayList<String> partitionedPlan) throws SQLException {
		int numberOfPlansRows = partitionedPlan.size();

		//Insere o plano quebrado, linha a linha, na metabase
		for (int i = 0; i < numberOfPlansRows; i++) {
			String sqlClauseToInsertPartitionedPlan = signatureToDifferentiate + " insert into tb_access_plan ( wld_id, apl_id_seq, apl_text_line ) values (?,?,?)";
			PreparedStatement preparedStatement = this.connection.prepareStatement(sqlClauseToInsertPartitionedPlan);

			log.write(sqlClauseToInsertPartitionedPlan);

			preparedStatement.setInt(1, queryId);
			preparedStatement.setInt(2, i);
			preparedStatement.setString(3, partitionedPlan.get(i));

			preparedStatement.executeUpdate();
			preparedStatement.close();
		}
	}

	private void deletePartitionedQueryPlan(int queryId) throws SQLException {
		Statement statement = this.connection.createStatement();
		String sqlClauseToDeletePartitionedPlan = signatureToDifferentiate + "delete from tb_access_plan where wld_id = " + queryId;
		statement.executeUpdate(sqlClauseToDeletePartitionedPlan);
		statement.close();
	}

	/**
	 * M�todo usado para recuperar o valor do id (identificador) para o pr�ximo elemento de carga de trabalho a ser inserido na metabase
	 * @return valor do id do pr�ximo elemento de carga de trabalho a ser inserido na metabase
	 */
	private int getNextId() throws SQLException {
		int nextId = 0;
		Statement statement = this.connection.createStatement();
		String sqlClauseToGetNextId = signatureToDifferentiate + "SELECT MAX(wld_id) as maxId FROM tb_workload";
		ResultSet resultSet = statement.executeQuery(sqlClauseToGetNextId);

		if (resultSet.next()) {
			nextId = resultSet.getInt("maxId");
		}
		statement.close();
		resultSet.close();
		nextId++;
		return nextId;
	}
}
