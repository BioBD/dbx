package drivers.oracle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

import agents.WOAgent;

import drivers.UDDriver;

/**
 * @author Jos� Maria
 * 
 * Classe usada para representar "Driver for DBMS Update" no Oracle
 * Respons�vel pela cria��o e remo��o de �ndices
 */
public class OracleUDDriver implements UDDriver{
	
	/** vari�vel que representa uma conex�o com o Oracle **/
	Connection connection = null;
	/** vari�vel utilizada para enviar cl�usulas SQL para o SGBD Oracle **/
	Statement statement = null;
	/** vari�vel utilizada para acessar um arquivo de propriedades **/
	protected Properties properties;
	
	/**
	 * Construtor usado para estabelecer a conex�o com o Oracle
	 */
	public OracleUDDriver(){
		try
	    {   
			/*
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//Porta Default 1521
			//Mas na mquina de testes est sendo utilizada a porta 1522
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:xe","SYSTEM","unifor");
			statement = connection.createStatement();
			*/
			properties = new Properties();
			properties.load(WOAgent.class.getResourceAsStream("database.properties"));
			String driver = this.properties.getProperty( "driverOracle" );
			String url    = this.properties.getProperty( "urlOracle" );
	        String user   = this.properties.getProperty( "userOracle" );
	        String passwd = this.properties.getProperty( "pwdOracle" );
            Class.forName( driver );
            this.connection = DriverManager.getConnection( url, user, passwd );
            statement = connection.createStatement();
	    }
		catch (SQLException e) {
			System.out.println(e.toString());
		}
		catch (ClassNotFoundException e) {
			System.out.println(e.toString());
		}
		catch (NullPointerException e) {
			System.out.println(e.toString());
		}
		catch (Exception e) {
			System.out.println(e.toString());
		}
	}
	
	/**
	 * M�todo usado para criar um �ndice em uma determinada tabela
	 * @param nomeTabela Nome da tabela a ser indexada.
	 * @param nomeIndice Nome do ndice a ser criado.
	 * @param nomeColuna Nome de uma ou mais colunas da tabela.
	 */
	public void createIndex(String nomeTabela, String nomeIndice, String [] nomeColuna){
    	
		/*Atributo com o(s) nome(s) da(s) coluna(s)*/
		String colunas = "";
		for (int i = 0; i < nomeColuna.length; i++) {
			if (i == nomeColuna.length - 1) {
				colunas = colunas + nomeColuna[i];
			} else {
				colunas = colunas + nomeColuna[i] + ", ";
			}
		}
		
        try{
        	/*Clusula para criao de ndice*/
        	String sqlClause = "CREATE INDEX " + nomeIndice + " ON " + nomeTabela + "(" + colunas + ")";
        	System.out.println(sqlClause);
        	statement.executeUpdate(sqlClause);
        }
    	catch (SQLException e) {
			System.out.println(e.toString());
		}
		catch (NullPointerException e) {
			System.out.println(e.toString());
		}
		catch (Exception e) {
			System.out.println(e.toString());
		}
    }
	
	/**
	 * M�todo usado para remover um �ndice
	 * @param nomeIndice Nome do �ndice a ser removido.
	 */
	public void dropIndex(String nomeIndice){
    	
        try{
        	/*Clusula para remoo de ndice*/
        	String sqlClause = "DROP INDEX " + nomeIndice;
        	System.out.println(sqlClause);
        	statement.executeUpdate(sqlClause);
        }
    	catch (SQLException e) {
			System.out.println(e.toString());
		}
		catch (NullPointerException e) {
			System.out.println(e.toString());
		}
		catch (Exception e) {
			System.out.println(e.toString());
		}
    }
    
	/**
	 * M�todo usado para criar um �ndice em uma determinada tabela no Oracle
	 * @param tableName Nome da tabela a ser indexada.
	 * @param indexName Nome do ndice a ser criado.
	 * @param columnsName Nome de uma ou mais colunas da tabela.
	 */
	public void createIndex(String schemaName, String tableName, String indexName, String[] collumnName, String accessMethod) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * M�todo usado para criar um �ndice prim�rio em uma determinada tabela
	 * @param schemaName nome do Schema
	 * @param tableName Nome da tabela a ser indexada
	 * @param indexName Nome do ndice a ser criado
	 * @param columnsName Nome de uma ou mais colunas da tabela
	 * @param accessMethod Tipo de m�todo de acesso
	 */
	public void createPrimaryIndex(String schemaName, String tableName, String indexName, String[] collumnName, String accessMethod) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * M�todo usado para incrementar o benef�cio de um �ndice prim�rio no Oracle
	 * @param schemaName nome do Schema
	 * @param tableName Nome da tabela a ser indexada
	 * @param field Nome da coluna
	 * @param value Valor a ser adicionado no benef�cio acumulado do �ndice
	 * @param wldId id da express�o SQL analisada
	 * @param wldType tipo da express�o SQL analisada
	 * @return Valor do benef�cio acumulado ap�s a atualiza��o
	 */
	public double incrementPrimaryIndexBenefict(String schemaname, String tableName, ArrayList<String> field, double value, int wldId, String wldType, double creationCost) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * M�todo usado para incrementar o benef�cio de um �ndice secund�rio no Oracle
	 * @param schemaName nome do Schema
	 * @param tableName Nome da tabela a ser indexada
	 * @param field Nome da coluna
	 * @param value Valor a ser adicionado no benef�cio acumulado do �ndice
	 * @param wldId id da express�o SQL analisada
	 * @param wldType tipo da express�o SQL analisada
	 * @param creationCost Custo de cria��o do �ndice
	 * @return Valor do benef�cio acumulado ap�s a atualiza��o
	 */
	public double incrementSecondaryIndexBenefict(String schemaname, String tableName, ArrayList<String> field, double value, int wldId, String wldType, double creationCost) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * M�todo usado para adicionar um novo �ndice candidato
	 * @param tableName Nome da tabela a ser indexada
	 * @param field Nome das colunas
	 * @param cidType Tipo do �ndice a ser criado (C -> Clustering and U -> Unclustering)
	 * @param value Valor do benef�cio do �ndice a ser criado
	 * @param creationCost Custo de cria��o do �ndice
	 */
	public void addCandidateIndex(String tableName, ArrayList<String> field, String cidType, double value, double creationCost) throws SQLException {
		// TODO Auto-generated method stub
		
	}
	
	/**
	 * M�todo usado para clusterizar uma tabela
	 * @param tableName Nome da tabela a ser clusterizada
	 * @param realIndexName Nome do �ndice a ser usado na clusteriza��o da tabela
	 */
	public void clusterTable(String tableName, String realIndexName){
		
	}

	/**
	 * M�todo usado para atualizar o nome de um �ndice na MetaBase Local
	 * @param ciId Identificador do �ndice a ser atualizado
	 * @param realIndexName Nome do �ndice a ser usado na atualiza��o
	 */
	public void updateIndexName(int cidId, String realIndexName){
		
	}
	
	/**
     * M�todo utilizado para fechar a conexo com o banco
     */
    public void  finalize(){
    	try{
    		statement.close();
    		connection.close();
    	}
    	catch (SQLException e) {
			System.out.println(e.toString());
		}
		catch (NullPointerException e) {
			System.out.println(e.toString());
		}
		catch (Exception e) {
			System.out.println(e.toString());
		}
    }
}
