package drivers;

import java.util.ArrayList;

import entity.SeqScan;

/**
 * @author Jose Maria
 * 
 * Classe utilit�ria contendo m�todos auxiliares (utilit�rios)
 */
public class Util {

	/**
	 * M�todo usado para 
	 * @param arrayElement
	 * @param element
	 * @return 
	 */
	//TODO Rever javadoc do m�todo
	public static boolean isElementOf(String arrayElement, String element) {
		String[] a = arrayElement.split(" ");
		for (int i = 0; i < a.length; i++) {
			String s = a[i];
			if (s.equalsIgnoreCase(element)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * M�todo usado para 
	 * @param sql
	 * @return 
	 */
	//	TODO Rever javadoc do m�todo	
	public static String retiraAspas(String sql){
		//String a = "'a'+teste=\'Teste\' teste";
		//System.out.println(a); 
		int pos =0;
		int local=0;
		String newString="";
		local = sql.indexOf('\'', pos);
		while(local>=0){
			newString = newString + sql.substring(pos,local);
			newString = newString + "''";
			pos = local + 1;
			local = sql.indexOf('\'', pos);
		}	
		newString = newString + sql.substring(pos);
		//a.replaceAll("''", "x");
		//System.out.println(newString);
		return newString;
	}

	/**
	 * M�todo usado para 
	 * @param part
	 * @return 
	 */
	//	TODO Rever javadoc do m�todo	
	public static String getToken(String part){
		String aux = "";
		for(int i = 0; i < part.length(); i++){
			if( part.charAt(i) == ' '  ){
				break;
			}
			aux += part.charAt(i); 
		}
		return aux;
	}

		
	/**
	 * M�todo utilizado para formatar uma express�o SQL 
	 * @param sql Uma express�o em SQL
	 * @return A express�o SQL formatada
	 */
	//	TODO Rever javadoc do m�todo	
	public static String formatQuery(String sql){
		
		int pos = 0;
	
		String s = "";
		
		int ini=0;
		
		/** Remover Tab **/
		char c = '\t';
		
		pos = sql.indexOf(c,ini);
		
		if (pos==-1){
			s=sql;
			ini = s.length()+1;
		}
		
		while(pos!=-1){							
			s = s + sql.substring(ini, pos) + ' '; 
			
			ini=pos+1;
			
			pos = sql.indexOf(c,ini);
		}
		
		if (ini < sql.length()){
			s = s + sql.substring(ini, sql.length()); 
		}
		
		/** Remover ENTER (CR) **/
		pos = 0;
		ini=0;
		sql = s;
		s = "";
		c = '\n';
		
		pos = sql.indexOf(c,ini);
		
		if (pos==-1){
			s=sql;
			ini = s.length()+1;
		}
		
		while(pos!=-1){			
			s = s + sql.substring(ini, pos) + ' '; 
			
			ini=pos+1;
			pos = sql.indexOf(c,ini);
		}
		
		if (ini < sql.length()){
			s = s + sql.substring(ini, sql.length()); 
		}
		
		//Remover Espa�o
		/*
		c = ' ';
		pos = 0;
		ini=0;
		sql = s;
		s = "";
		
		pos = sql.indexOf(c,ini);
		
		if (pos==-1){
			s=sql;
			ini = s.length()+1;
		}
		
		while(pos!=-1){								
			if (sql.charAt(pos+1)==' '){
				s = s + sql.substring(ini, pos); 
			}
			else{
				s = s + sql.substring(ini, pos+1);
			}
			
			ini=pos+1;
			
			pos = sql.indexOf(c,ini);
		}
		
		if (ini < sql.length()){
			s = s + sql.substring(ini, sql.length()); 
		}
		*/
		
		/** Converte para caixa alta **/
		//s = s.toUpperCase();
		
		return s;
	}
	
	/**
	 * M�todo utilizado para calcular o logaritmo de um n�mero na base 2 
	 * @param num N�mero
	 * @return O Logaritmo de num na base 2
	 */
	public static double log2(double num)
	{
	return (Math.log(num)/Math.log(2));
	} 

}
