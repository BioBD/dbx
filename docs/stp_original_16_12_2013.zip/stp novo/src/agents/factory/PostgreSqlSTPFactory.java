package agents.factory;

import drivers.SADriver;
import drivers.UDDriver;
import drivers.WADriver;
import drivers.postgres.PostgreSqlSADriver;
import drivers.postgres.PostgreSqlUDDriver;
import drivers.postgres.PostgreSqlWADriver;

/**
 * @author Jos� Maria
 * Classe usada para representar uma f�brica de objetos (factory) para o SGBD Postgres
 */
public class PostgreSqlSTPFactory extends STPFactory {
	
	/** M�todo que retorna uma inst�ncia de SADriver. Mais precisamente, uma inst�ncia de PostgresSADriver**/
	public SADriver getSADriver()
	{
		return new PostgreSqlSADriver();	
	}	
	
	/** M�todo que retorna uma inst�ncia de UDDriver. Mais precisamente, uma inst�ncia de PostgresUDDriver**/
	public UDDriver getUDDriver()
	{
		return new PostgreSqlUDDriver();	
	}
	
	/** M�todo que retorna uma inst�ncia de WADriver. Mais precisamente, uma inst�ncia de PostgresWADriver**/
	public WADriver getWADriver()
	{
		return new PostgreSqlWADriver();	
	}	
}
