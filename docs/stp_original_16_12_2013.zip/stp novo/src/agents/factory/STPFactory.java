package agents.factory;

import drivers.SADriver;
import drivers.UDDriver;
import drivers.WADriver;

/**
 * @author Jos� Maria
 * Classe usada para implementa��o do padr�o factory
 */
public abstract class STPFactory
{
	/** Constante utilizada para representar o SGBD Oracle **/
	public static final int ORACLE = 1;
	/** Constante utilizada para representar o SGBD postgres **/
	public static final int POSTGRES = 2;
	/** Constante utilizada para representar o SGBD SQL Server **/
	public static final int SQLSERVER = 3;
	
	/** M�todo que retorna uma inst�ncia de WADriver **/
	public abstract WADriver getWADriver();
	/** M�todo que retorna uma inst�ncia de UDDriver **/
	public abstract UDDriver getUDDriver();
	/** M�todo que retorna uma inst�ncia de SADriver **/
	public abstract SADriver getSADriver();
	
	/**
	 * M�todo usado para recuperar uma f�brica de objetos (factory) para um determinado SGBD (fornecido como par�metro)
	 * @param db valor inteiro representando o SGBD
	 * @return uma inst�ncia de umas das sub-classe de STPFactory, ou seja,  uma f�brica de objetos (factory) para um determinado SGBD (fornecido como par�metro)
	 */
	public static STPFactory getWADFactory(int db)
	{
		switch(db)
		{
			case ORACLE:
				return new OracleSTPFactory();
			case POSTGRES:
				return new PostgreSqlSTPFactory();
			case SQLSERVER:
				return new SQLServerSTPFactory();
			default:
				return null;	
		}	
	}	
}
