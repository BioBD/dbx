package agents.factory;

import drivers.SADriver;
import drivers.UDDriver;
import drivers.WADriver;
import drivers.oracle.OracleSADriver;
import drivers.oracle.OracleUDDriver;
import drivers.oracle.OracleWADriver;

/**
 * @author Jos� Maria
 * Classe usada para representar uma f�brica de objetos (factory) para o SGBD Oracle
 */
public class OracleSTPFactory extends STPFactory{
	
	/** M�todo que retorna uma inst�ncia de SADriver. Mais precisamente, uma inst�ncia de OracleSADriver**/
	public SADriver getSADriver()
	{
		return new OracleSADriver();	
	}
	
	/** M�todo que retorna uma inst�ncia de UDDriver. Mais precisamente, uma inst�ncia de OracleUDDriver**/
	public UDDriver getUDDriver()
	{
		return new OracleUDDriver();	
	}
	
	/** M�todo que retorna uma inst�ncia de WADriver. Mais precisamente, uma inst�ncia de OracleWADriver**/
	public WADriver getWADriver()
	{
		return new OracleWADriver();	
	}
}
