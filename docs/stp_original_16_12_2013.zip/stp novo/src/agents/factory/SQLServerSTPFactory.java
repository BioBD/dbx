package agents.factory;

import drivers.SADriver;
import drivers.UDDriver;
import drivers.WADriver;
import drivers.sqlserver.SQLServerSADriver;
import drivers.sqlserver.SQLServerUDDriver;
import drivers.sqlserver.SQLServerWADriver;

/**
 * @author Jos� Maria
 * Classe usada para representar uma f�brica de objetos (factory) para o SGBD SQLServer
 */
public class SQLServerSTPFactory extends STPFactory{
	
	/** M�todo que retorna uma inst�ncia de SADriver. Mais precisamente, uma inst�ncia de SQLServerSADriver**/
	public SADriver getSADriver()
	{
		return new SQLServerSADriver();	
	}	
	
	/** M�todo que retorna uma inst�ncia de UDDriver. Mais precisamente, uma inst�ncia de SQLServerUDDriver**/
	public UDDriver getUDDriver()
	{
		return new SQLServerUDDriver();	
	}
	
	/** M�todo que retorna uma inst�ncia de WADriver. Mais precisamente, uma inst�ncia de SQLServerWADriver**/
	public WADriver getWADriver()
	{
		return new SQLServerWADriver();	
	}	
}
