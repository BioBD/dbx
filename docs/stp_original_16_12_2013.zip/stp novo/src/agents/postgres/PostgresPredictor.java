/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package agents.postgres;

import drivers.postgres.PostgreSqlSADriver;
import entity.IndexCandidate;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author Lucas
 */
public class PostgresPredictor {

    public ArrayList<IndexCandidate> selectAnIndexStructureConfiguration(ArrayList<IndexCandidate> indexCandidates, int storageConstraint) throws IOException, ClassNotFoundException, SQLException {
        ArrayList<IndexCandidate> sortedIndexCandidates = sortIndexCandidatesByRelativeProfit(indexCandidates);
        ArrayList<IndexCandidate> selectedIndexes = new ArrayList<IndexCandidate>();
        PostgreSqlSADriver pgsa = new PostgreSqlSADriver();
        int availableSpace = storageConstraint;
        int totalBenefit = 0;
        for(int i = 0; i<sortedIndexCandidates.size(); i++) {
            IndexCandidate currentIndex = sortedIndexCandidates.get(i);
            if((isTheIndexPrimary(currentIndex) && !isThereOtherPrimaryIndexOnTheSameTable(selectedIndexes, currentIndex.getTableName()))  
                    || isTheIndexSecondary(currentIndex)) {
                int pagesNumber = pgsa.estimateIndexPagesNumber(currentIndex);
                System.out.println("Index: " +currentIndex.getId() + " Pages: " + pagesNumber);
                if(availableSpace - pagesNumber > 0) {
                    selectedIndexes.add(currentIndex);
                    availableSpace -= pagesNumber;
                    totalBenefit += currentIndex.getProfit();
                }
            }
        }
        return selectedIndexes;
    }
    
    public boolean isTheIndexPrimary(IndexCandidate indexCandidate) {
        if(indexCandidate.getType().equals("P")) {
            return true;
        }
        return false;
    }
    
    public boolean isTheIndexSecondary(IndexCandidate indexCandidate) {
        if(indexCandidate.getType().equals("S")) {
            return true;
        }
        return false;
    }
    
   /* public boolean isThereOtherPrimaryIndexInTheSameTable(IndexCandidate indexCandidate) throws IOException, SQLException, ClassNotFoundException {
        IndexCandidateDAO indexCandidateDAO = new IndexCandidateDAO();
        ArrayList<String> tablesWithClusteredIndex = indexCandidateDAO.getTablesWithClusteredIndex();
        String tableName = indexCandidate.getTableName();
        if(tablesWithClusteredIndex.contains(tableName) && !indexCandidate.getStatus().equals("R")) {
            return true;
        }
        return false;
    }*/
    
    public boolean isThereOtherPrimaryIndexOnTheSameTable(ArrayList<IndexCandidate> setOfIndexes, String tableName) {
        for(IndexCandidate currentSelectedIndex : setOfIndexes) {
            String currentTableName = currentSelectedIndex.getTableName();
            if(currentSelectedIndex.getType().toUpperCase().equals("P") && tableName.equals(currentTableName)) {
                return true;
            }
        }
        return false;
    }

    public ArrayList<IndexCandidate> sortIndexCandidatesByRelativeProfit(ArrayList<IndexCandidate> indexCandidates) throws IOException, ClassNotFoundException, SQLException {
        indexCandidates = addRelativeProfit(indexCandidates);
        Collections.sort(indexCandidates, new Comparator() {

            public int compare(Object o1, Object o2) {
                IndexCandidate p1 = (IndexCandidate) o1;
                IndexCandidate p2 = (IndexCandidate) o2;
                return p1.getRelativeProfit() > p2.getRelativeProfit() ? -1 : (p1.getRelativeProfit() < p2.getRelativeProfit() ? +1 : 0);
            }
        });
        return indexCandidates;
    }

    public ArrayList<IndexCandidate> addRelativeProfit(ArrayList<IndexCandidate> indexCandidates) throws IOException, ClassNotFoundException, SQLException {
        PostgreSqlSADriver pgsa = new PostgreSqlSADriver();
        for (int i = 0; i < indexCandidates.size(); i++) {
            IndexCandidate currentIndexCandidate = indexCandidates.get(i);
            int indexProfit = currentIndexCandidate.getProfit();
            int estimatedPagesNumber = pgsa.estimateIndexPagesNumber(currentIndexCandidate);
            int relativeProfit = indexProfit / estimatedPagesNumber;
            currentIndexCandidate.setRelativeProfit(relativeProfit);
        }
        return indexCandidates;
    }
}
