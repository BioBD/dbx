/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package agents.postgres;

import entity.DAO.IndexCandidateDAO;
import entity.IndexCandidate;
import entity.Task;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Lucas
 */
public class PostgresRealIndexAnalyser {

    public void analyseRealIndexes(Task task) throws SQLException, IOException, ClassNotFoundException {
        IndexCandidateDAO indexCandidateDAO = new IndexCandidateDAO();
        ArrayList<IndexCandidate> indexCandidatesBelongsToTask = indexCandidateDAO.getIndexCandidateBelongsToTask(task.getId());
        for(IndexCandidate currentIndexCandidate : indexCandidatesBelongsToTask) {
            if(isIndexReal(currentIndexCandidate)) {
                
            }
        }
        
    }
    
    public boolean isIndexReal(IndexCandidate indexCandidate) {
        if(indexCandidate.getStatus().equals("R")) {
            return true;
        }
        return false;
    }
    
    // Metodo que retorna se um índice pertence ao plano de execução de determinada task
    public void indexBelongsToTaskExecutionPlan (IndexCandidate indexCandidate, int taskId) {
        
    }
}
