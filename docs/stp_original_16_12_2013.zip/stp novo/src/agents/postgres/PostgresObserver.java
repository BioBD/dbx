/* Classe usada para implementar o Algoritmo 2 do artigo, respons�vel por identificar
 * os benef�cios de cria��o dos �ndices e determinar se eles devem ser criados */

package agents.postgres;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;



import drivers.postgres.PostgreSqlSADriver;
import entity.IndexCandidate;
import entity.SeqScan;
import entity.SeqScanWithFilter;
import entity.Task;
import entity.DAO.IndexCandidateDAO;
import entity.DAO.TaskDAO;

public class PostgresObserver {

	public PostgresObserver() throws Exception {
		super();
	}
	
	public void observeCapturedWorkload() throws Exception {
		TaskDAO taskDAO = new TaskDAO();
		ArrayList<Task> obtainedWorkload = taskDAO.getObtainedWorkload();
		for(int i = 0; i < obtainedWorkload.size(); i++) {
			Task currentTask = obtainedWorkload.get(i);
			analyseIndexCandidates(currentTask);
			analyseRealIndexes(currentTask);
			if(isTheTaskAnUpdate(currentTask)) {
				//analyseUpdateOperations(currentTask);
			}
		}
	}

	public boolean isTheTaskAnUpdate(Task task) {
		return task.getType().equals("U");
	}

	public void analyseIndexCandidates(Task task) throws Exception {
		PostgreSqlSADriver pgsa = new PostgreSqlSADriver();
		if(isThereASeqScanOperation(task.getPlan())) {
			//Case 1: procura com Seq Scans com Filtros Where/Join
			ArrayList<SeqScanWithFilter> seqScansWithFilters = extractSeqScansWithFilters(task.getPlan(), task.getSqlText());
			System.out.println(seqScansWithFilters.size());
			ArrayList<IndexCandidate> indexCandidatesWithIndividualFieldOnFilters = null, indexCandidatesWithAllFieldsOnFilter = null, indexCandidatesWithoutFilters;
			/*Se o caso 1 � satisfeito, percorre todos os Seq Scans com filtros encontrados no 
			 * plano e cria um IndexCandidate para cada atributo usado no filtro */
			if(!seqScansWithFilters.isEmpty()) {
				indexCandidatesWithIndividualFieldOnFilters = getIndexCandidatesWithIndividualFieldsOnFilter(seqScansWithFilters);
				indexCandidatesWithAllFieldsOnFilter = getIndexCandidatesWithAllFiedsOnFilters(seqScansWithFilters);
				addIndexCandidates(task, indexCandidatesWithIndividualFieldOnFilters);
				addIndexCandidates(task, indexCandidatesWithAllFieldsOnFilter);
			}
			//ArrayList<IndexCandidate> indexCandidatesWithFilterGroupAndOrderOperations = getIndexCandidatesWithFilterGroupAndOrderOperations(seqScansWithFilters, task.getSqlText());
			//addIndexCandidates(task, indexCandidatesWithFilterGroupAndOrderOperations);
			/*Case 2: Cria um IndexCandidate para cada atributo usado em
			Select/Group/Order clauses */
			ArrayList<SeqScan> seqScans =  extractSeqScans(task.getPlan());
			indexCandidatesWithoutFilters = getIndexCandidatesWithoutFilters(seqScans, task.getSqlText());
			addIndexCandidates(task, indexCandidatesWithoutFilters);
			ArrayList<IndexCandidate> indexCandidatesWithFilterGroupAndOrderFields = getIndexCandidatesWithFilterGroupAndOrderOperations(seqScansWithFilters, task.getSqlText());
			addIndexCandidates(task, indexCandidatesWithFilterGroupAndOrderFields);
			ArrayList<IndexCandidate> indexCandidatesWithHashFields = getIndexCandidatesWithHashFields(seqScans,task.getPlan());
			addIndexCandidates(task, indexCandidatesWithHashFields);
			ArrayList<IndexCandidate> indexCandidatesWithGroupAndHashFields = getIndexCandidatesWithGroupAndHashFields(seqScans, task);
			addIndexCandidates(task, indexCandidatesWithGroupAndHashFields);
			ArrayList<IndexCandidate> indexCandidatesWithJoinFilterFields = getIndexCandidatesWithJoinFilterFields(seqScans,task.getPlan());
			addIndexCandidates(task, indexCandidatesWithJoinFilterFields);
			//ArrayList<IndexCandidate> indexCandidatesWithAllFields = analyzeIndexCandidateWithAllFields(indexCandidatesWithIndividualFieldOnFilters, indexCandidatesWithoutFilters);
			//addIndexCandidates(task, indexCandidatesWithAllFields);

			ArrayList<IndexCandidate> indexCandidates = task.getIndexCandidates();
			for(int i=0; i<indexCandidates.size(); i++) {
				IndexCandidate currentIndexCandidate = indexCandidates.get(i);
				if(currentIndexCandidate.getColumns().size() > 0 ) {
					IndexCandidate[] setOfTwoVersionsOfIndex = createAPrimaryAndASecondaryIndex(currentIndexCandidate);
					for(int j=0; j<setOfTwoVersionsOfIndex.length; j++) {
						IndexCandidate currentIndex = setOfTwoVersionsOfIndex[j];
						IndexCandidateDAO indexCandidateDAO = new IndexCandidateDAO();
						if(!indexCandidateDAO.indexBelongsToLocalMetabase(currentIndex)) {	
							System.out.println("Index on: " + currentIndex.getColumns() + "doesn't belong to LM..............");
							currentIndex.setId(pgsa.getNextCandidateIndexId());
							indexCandidateDAO.insertIndexCandidate(currentIndex, task);
						}
						if(currentIndex.getStatus().equals("H")) {
							int costOfASeqScan = pgsa.getBlocksNumber(currentIndex.getTableName());
							if (currentIndex.getCostOfAnIndexScan() < costOfASeqScan) {
								currentIndex.setProfit(costOfASeqScan - currentIndex.getCostOfAnIndexScan());
								indexCandidateDAO.updateProfit(currentIndex);
							}
						}
					}
				}
			}
		}
	}

	public void analyseRealIndexes(Task task) {
                
	}

	public ArrayList<IndexCandidate> getIndexCandidatesWithAllFiedsOnFilters(ArrayList<SeqScanWithFilter> seqScansWithFilter) {
		ArrayList<IndexCandidate> indexCandidates = new ArrayList<IndexCandidate>();
		for(int i = 0; i<seqScansWithFilter.size(); i++) {
			SeqScanWithFilter currentSeqScan = seqScansWithFilter.get(i);
			String tableName = currentSeqScan.getTableName();
			ArrayList<String> fieldsUsedInFilter = currentSeqScan.getFieldsUsedInFilter();
			IndexCandidate indexCandidate = new IndexCandidate(tableName);
			indexCandidate.addColumns(fieldsUsedInFilter);
			System.out.println("FILTRO: Criou Index Candidate nos atributos "  + fieldsUsedInFilter);
			indexCandidates.add(indexCandidate);
		}
		return indexCandidates;
	}

	public ArrayList<IndexCandidate> getIndexCandidatesWithFilterGroupAndOrderOperations(ArrayList<SeqScanWithFilter> seqScansWithFilter, String sqlText) throws SQLException, IOException, ClassNotFoundException {
		ArrayList<IndexCandidate> indexCandidates = new ArrayList<IndexCandidate>();
		for(int i = 0; i<seqScansWithFilter.size(); i++) {
			SeqScanWithFilter currentSeqScan = seqScansWithFilter.get(i);
			String tableName = currentSeqScan.getTableName();
			System.out.println("Analisando para tabela " + tableName + ".............");
			ArrayList<String> fieldsUsedInFilter = currentSeqScan.getFieldsUsedInFilter();
			System.out.println(tableName + "Filter: " + fieldsUsedInFilter);
			ArrayList<String> fieldsUsedInGroup = getFieldsUsedInGroupOperations(tableName, sqlText);
			System.out.println(tableName + "Group: " + fieldsUsedInGroup);
			ArrayList<String> fieldsUsedInOrder = getFieldsUsedInOrderOperations(tableName, sqlText);
			System.out.println(tableName + "Order: " + fieldsUsedInOrder);
			IndexCandidate indexCandidate = new IndexCandidate(tableName);
			indexCandidate.addColumns(fieldsUsedInFilter);
			indexCandidate.addColumns(fieldsUsedInGroup);
			indexCandidate.addColumns(fieldsUsedInOrder);
			System.out.println("index columns size: " + indexCandidate.getColumns().size());
			System.out.println("FILTRO + ORDER + GROUP: Criou Index Candidate nos atributos "  + indexCandidate.getColumns());
			indexCandidates.add(indexCandidate);
		}
		return indexCandidates;
	}
	
	public ArrayList<IndexCandidate> getIndexCandidatesWithGroupAndHashFields(ArrayList<SeqScan> seqScans, Task task) throws SQLException, IOException, ClassNotFoundException {
		ArrayList<IndexCandidate> indexCandidates = new ArrayList<IndexCandidate>();
		for(int i =0;i<seqScans.size();i++) {
			String currentTable = seqScans.get(i).getTableName();
			ArrayList<String> fieldsUsedInGroup = getFieldsUsedInGroupOperations(currentTable, task.getSqlText());
			ArrayList<String> fieldsUsedInJoin = getFieldsUsedInAllHashes(task.getPlan(), currentTable);
			IndexCandidate indexCandidate = new IndexCandidate(currentTable);
			indexCandidate.addColumns(fieldsUsedInJoin);
			indexCandidate.addColumns(fieldsUsedInGroup);
			indexCandidates.add(indexCandidate);
		}
		return indexCandidates;
	}
	
	//Cria um �ndice candidato para cada tabela e seus respectivos atributos presentes na joinLine
//	public ArrayList<IndexCandidate> getIndexCandidatesWithJoinFields(ArrayList<String> queryPlan) throws SQLException, IOException, ClassNotFoundException {
//		ArrayList<IndexCandidate> indexCandidates = new ArrayList<IndexCandidate>();
//		ArrayList<String> joinLines = getJoinLines(queryPlan);
//		System.out.println("Join Lines: " + joinLines.size());
//		for(int i = 0; i<joinLines.size(); i ++) {
//			String currentLine = joinLines.get(i);
//			ArrayList<String> tables = getTablesUsedInJoinLine(currentLine);
//			System.out.println("Tables Used in Join Line: " + tables.size());
//			for(int j = 0; j< tables.size(); j++) {
//				String currentTable = tables.get(j);
//				ArrayList<String> fields = getFieldsUsedInJoin(currentLine, currentTable);
//				IndexCandidate indexCandidate = new IndexCandidate(currentTable);
//				indexCandidate.addColumns(fields);
//				indexCandidates.add(indexCandidate);
//				System.out.println("JOIN: " + fields);
//			}
//		}
//		return indexCandidates;
//	}

	//Cria um �ndice candidato para cada tabela e seus respectivos atributos presentes na joinLine
	public ArrayList<IndexCandidate> getIndexCandidatesWithHashFields(ArrayList<SeqScan> seqScans,ArrayList<String> queryPlan) throws SQLException, IOException, ClassNotFoundException {
		ArrayList<IndexCandidate> indexCandidates = new ArrayList<IndexCandidate>();
		ArrayList<String> hashLines = getHashLines(queryPlan);
		System.out.println("Hash Lines: " + hashLines.size());
		for(int i = 0; i<seqScans.size(); i++) {
			SeqScan currentSeqScan = seqScans.get(i);
			String table = currentSeqScan.getTableName();
			for(int j = 0; j<hashLines.size();j++) {
				String currentHashLine = hashLines.get(j);
				ArrayList<String> fieldsUsedInHash  = getFieldsUsedInLine(currentHashLine, table);
				IndexCandidate indexCandidate = new IndexCandidate(table);
				indexCandidate.addColumns(fieldsUsedInHash);
				indexCandidates.add(indexCandidate);
				System.out.println("HASH: " + fieldsUsedInHash);
			}
		}
		return indexCandidates;
	}
	
	//Cria um �ndice candidato para cada tabela e seus respectivos atributos presentes na joinLine
	public ArrayList<IndexCandidate> getIndexCandidatesWithJoinFilterFields(ArrayList<SeqScan> seqScans,ArrayList<String> queryPlan) throws SQLException, IOException, ClassNotFoundException {
		ArrayList<IndexCandidate> indexCandidates = new ArrayList<IndexCandidate>();
		ArrayList<String> joinLines = getJoinFilterLines(queryPlan);
		System.out.println("Join Filter Lines: " + joinLines.size());
		for(int i = 0; i<seqScans.size(); i++) {
			SeqScan currentSeqScan = seqScans.get(i);
			String table = currentSeqScan.getTableName();
			for(int j = 0; j<joinLines.size();j++) {
				String currentJoinLine = joinLines.get(j);
				ArrayList<String> fieldsUsedInJoin  = getFieldsUsedInLine(currentJoinLine, table);
				IndexCandidate indexCandidate = new IndexCandidate(table);
				indexCandidate.addColumns(fieldsUsedInJoin);
				indexCandidates.add(indexCandidate);
				System.out.println("JOIN: " + fieldsUsedInJoin);
			}
		}
		return indexCandidates;
	}
	
	public ArrayList<String> getFieldsUsedInLine(String hashLine, String tableName) throws SQLException, IOException, ClassNotFoundException {
		PostgreSqlSADriver pgsa = PostgreSqlSADriver.getInstance();
		ArrayList<String> fieldsUsedInHashOperations =  new ArrayList<String>();
		ArrayList<String> tableFields = pgsa.getFieldsNames(tableName);
		for(int i = 0; i<tableFields.size(); i++) {
			String currentField = tableFields.get(i);
			if(hashLine.contains(currentField)) {
				fieldsUsedInHashOperations.add(currentField);
			}
		}
		return fieldsUsedInHashOperations;
	}
	
	public ArrayList<String> getFieldsUsedInAllHashes(ArrayList<String> queryPlan, String tableName) throws SQLException, IOException, ClassNotFoundException {
		PostgreSqlSADriver pgsa = PostgreSqlSADriver.getInstance();
		ArrayList<String> hashLines = getHashLines(queryPlan);
		ArrayList<String> fieldsUsedInAllHashOperations =  new ArrayList<String>();
		ArrayList<String> tableFields = pgsa.getFieldsNames(tableName);
		for(int i =0;i<hashLines.size();i++) {
			String currentJoinLine = hashLines.get(i);
			for(int j = 0; j<tableFields.size(); j++) {
				String currentField = tableFields.get(j);
				if(currentJoinLine.contains(currentField)) {
					fieldsUsedInAllHashOperations.add(currentField);
				}
			}
		}
		return fieldsUsedInAllHashOperations;
	}
 
	public IndexCandidate[] createAPrimaryAndASecondaryIndex(IndexCandidate indexCandidate) throws ParseException, SQLException, IOException, ClassNotFoundException {
		PostgreSqlSADriver pgsa = PostgreSqlSADriver.getInstance();
		IndexCandidate[] setOfTwoVersions = new IndexCandidate[2];
		String tableName = indexCandidate.getTableName();
		ArrayList<String> columns = indexCandidate.getColumns();
		int costoOfAnIndexScanUsingAPrimayIndex = estimateTheCostOfAnIndexScan(indexCandidate, "P");
		int costOfAnIndexScanUsingASecondaryIndex = estimateTheCostOfAnIndexScan(indexCandidate, "S");
		setOfTwoVersions[0] = new IndexCandidate(tableName, "H", "P", columns, costoOfAnIndexScanUsingAPrimayIndex);
		setOfTwoVersions[1] = new IndexCandidate(tableName, "H", "S", columns, costOfAnIndexScanUsingASecondaryIndex);
		return setOfTwoVersions;
	}

	public int estimateTheCostOfAnIndexScan(IndexCandidate indexCandidate, String indexType) throws ParseException, SQLException, IOException, ClassNotFoundException {
		int minorFs, costOfAnIndexScan = 0;
		PostgreSqlSADriver pgsa = PostgreSqlSADriver.getInstance();
		String tableName = indexCandidate.getTableName();
		ArrayList<String> fields = indexCandidate.getColumns();
		if(fields == null || fields.size() < 1) return -1;
		long pageFactor = pgsa.getRowsNumber(tableName)/pgsa.getBlocksNumber(tableName);
		long indexHeight = pgsa.getIndexTreeHeight(tableName, fields);
		minorFs = (int)Math.ceil(pgsa.getAttSelectivity(tableName, fields.get(0), "=", ""));
		for(int i=0; i<fields.size(); i++) {
			String currentField = fields.get(i);
			int fs = (int)Math.ceil(pgsa.getAttSelectivity(tableName, currentField, "=", ""));
			if(fs < minorFs) minorFs = fs;
			if(indexType.equals("P")) costOfAnIndexScan += minorFs/pageFactor;
			if(indexType.equals("S")) costOfAnIndexScan += minorFs;
		}
		costOfAnIndexScan += indexHeight;
		return costOfAnIndexScan;
	}

	//MODIFICAR ESSE M�TODO ( EST� PEGANDO APENAS A PRIMEIRA COLUNA DE CADA �NDICE )
	public ArrayList<IndexCandidate> analyzeIndexCandidateWithAllFields(ArrayList<IndexCandidate> indexCandidatesWithFilters , ArrayList<IndexCandidate> indexCandidatesWithoutFilters) {
		ArrayList<IndexCandidate> indexCandidates =  new ArrayList<IndexCandidate>();
		ArrayList<String> tablesNames = getTablesNames(indexCandidatesWithFilters, indexCandidatesWithoutFilters);
		for(int i=0; i<tablesNames.size(); i++) {
			String currentTable = tablesNames.get(i);
			IndexCandidate indexCandidate =  new IndexCandidate(currentTable);
			for(int j=0; j<indexCandidatesWithFilters.size(); j++) {
				IndexCandidate currentIndexCandidate = indexCandidatesWithFilters.get(j);
				if(currentIndexCandidate.getTableName().equals(currentTable)) {
					for(int k=0; k<currentIndexCandidate.getColumns().size(); k++) {
						if(!indexCandidate.getColumns().contains(currentIndexCandidate.getColumns().get(k))) {
							indexCandidate.addColumn(currentIndexCandidate.getColumns().get(k));
						}
					}
				}
			}
			for(int j=0; j<indexCandidatesWithoutFilters.size(); j++) {
				IndexCandidate currentIndexCandidate = indexCandidatesWithoutFilters.get(j);
				if(currentIndexCandidate.getTableName().equals(currentTable)) {
					for(int k=0; k<currentIndexCandidate.getColumns().size(); k++) {
						if(!indexCandidate.getColumns().contains(currentIndexCandidate.getColumns().get(k))) {
							indexCandidate.addColumn(currentIndexCandidate.getColumns().get(k));

						}
					}
				}
			}
			System.out.println("Criou indexCandidate na tabela: " + indexCandidate.getTableName() + " com " + indexCandidate.getColumns().size() + " atributos" );
			System.out.println(indexCandidate.getColumns());
			indexCandidates.add(indexCandidate);
		}
		return indexCandidates;
	}

	public ArrayList<String> getTablesNames(ArrayList<IndexCandidate> indexCandidatesWithFilters , ArrayList<IndexCandidate> indexCandidatesWithoutFilter) {
		ArrayList<String> tablesNames = new ArrayList<String>();
		for(int i = 0; i<indexCandidatesWithFilters.size(); i++) {
			IndexCandidate currentIndexCandidate = indexCandidatesWithFilters.get(i);
			if(!tablesNames.contains(currentIndexCandidate.getTableName())) {
				tablesNames.add(currentIndexCandidate.getTableName());
			}
		}
		for(int i = 0; i<indexCandidatesWithoutFilter.size(); i++) {
			IndexCandidate currentIndexCandidate = indexCandidatesWithoutFilter.get(i);
			if(!tablesNames.contains(currentIndexCandidate.getTableName())) {
				tablesNames.add(currentIndexCandidate.getTableName());
			}
		}
		return tablesNames;
	}


	public void addIndexCandidates(Task task, ArrayList<IndexCandidate> indexCandidates) {
		for(int i = 0; i< indexCandidates.size(); i++) {
			IndexCandidate currentIndexCandidate = indexCandidates.get(i);
			if(!task.containsIndexCandidate(currentIndexCandidate.getTableName(), currentIndexCandidate.getColumns())) {
				task.addIndexCandidate(currentIndexCandidate);
			}
		}
	}

	public ArrayList<IndexCandidate> getIndexCandidatesWithIndividualFieldsOnFilter(ArrayList<SeqScanWithFilter> seqScansWithFilters) {
		ArrayList<IndexCandidate> indexCandidates = new ArrayList<IndexCandidate>();
		for(int i = 0; i<seqScansWithFilters.size(); i++) {
			SeqScanWithFilter currentSeqScan = seqScansWithFilters.get(i);
			String tableName = currentSeqScan.getTableName();
			ArrayList<String> fieldsUsedInFilter = currentSeqScan.getFieldsUsedInFilter();
			for(int j=0; j< fieldsUsedInFilter.size(); j++) {
				String currentField = fieldsUsedInFilter.get(j);
				IndexCandidate indexCandidate = new IndexCandidate(tableName);
				indexCandidate.addColumn(currentField);
				System.out.println("Criou Index Candidate no atributo " + currentField );
				indexCandidates.add(indexCandidate);
			}
		}
		return indexCandidates;
	}

	//	public ArrayList<IndexCandidate> analyzeIndexCandidatesWithoutFilters(ArrayList<SeqScan> seqScans , String sqlText) throws SQLException {
	//		ArrayList<IndexCandidate> indexCandidates = new ArrayList<IndexCandidate>();
	//		for(int i = 0; i<seqScans.size(); i++) {
	//			SeqScan currentSeqScan = seqScans.get(i);
	//			String tableName = currentSeqScan.getTableName();
	//			ArrayList<String> fields = getFieldsUsedInSelectGroupOrOrderOperations(tableName,sqlText);
	//			for(int j = 0; j< fields.size(); j++) {
	//				String currentField = fields.get(j);
	//				IndexCandidate indexCandidate = new IndexCandidate(tableName);
	//				indexCandidate.addColumn(currentField);
	//				System.out.println("Criou Index Candidate no atributo " + currentField );
	//				indexCandidates.add(indexCandidate);
	//			}
	//		}
	//		return indexCandidates;
	//	}

	public ArrayList<IndexCandidate> getIndexCandidatesWithoutFilters(ArrayList<SeqScan> seqScans , String sqlText) throws SQLException, IOException, ClassNotFoundException {
		ArrayList<IndexCandidate> indexCandidates = new ArrayList<IndexCandidate>();
		for(int i = 0; i<seqScans.size(); i++) {
			SeqScan currentSeqScan = seqScans.get(i);
			String tableName = currentSeqScan.getTableName();
			if(getIndexCandidateWithGroupFields(tableName, sqlText) != null) {
				indexCandidates.add(getIndexCandidateWithGroupFields(tableName, sqlText));
			}
			if(getIndexCandidateWithOrderFields(tableName, sqlText) != null) {
				indexCandidates.add(getIndexCandidateWithOrderFields(tableName, sqlText));
			}
			if(getIndexCandidateWithSelectFields(tableName, sqlText) != null) {
				indexCandidates.add(getIndexCandidateWithSelectFields(tableName, sqlText));
			}
		}
		return indexCandidates;
	}

	public IndexCandidate getIndexCandidateWithSelectFields(String tableName, String sqlText) throws SQLException, IOException, ClassNotFoundException {
		ArrayList<String> fieldsUsedInSelect = getFieldsUsedInSelectOperations(tableName, sqlText);
		if(fieldsUsedInSelect != null && fieldsUsedInSelect.size() != 0) {
			IndexCandidate indexCandidate = new IndexCandidate(tableName);
			indexCandidate.setColumns(fieldsUsedInSelect);
			System.out.println("SELECT: Criou index candidate nos atributos: " + fieldsUsedInSelect);
			return indexCandidate;
		}
		return null;
	}

	public IndexCandidate getIndexCandidateWithGroupFields(String tableName, String sqlText) throws SQLException, IOException, ClassNotFoundException {
		ArrayList<String> fieldsUsedInGroup = getFieldsUsedInGroupOperations(tableName, sqlText);
		if(fieldsUsedInGroup != null && fieldsUsedInGroup.size() != 0) {
			IndexCandidate indexCandidate = new IndexCandidate(tableName);
			indexCandidate.setColumns(fieldsUsedInGroup);
			System.out.println("GROUP: Criou index candidate nos atributos: " + fieldsUsedInGroup);
			return indexCandidate;
		}
		return null;
	}

	public IndexCandidate getIndexCandidateWithOrderFields(String tableName, String sqlText) throws SQLException, IOException, ClassNotFoundException {
		ArrayList<String> fieldsUsedInOrder = getFieldsUsedInOrderOperations(tableName, sqlText);
		if(fieldsUsedInOrder != null && fieldsUsedInOrder.size() != 0) {
			IndexCandidate indexCandidate = new IndexCandidate(tableName);
			indexCandidate.setColumns(fieldsUsedInOrder);
			System.out.println("ORDER: Criou index candidate nos atributos: " + fieldsUsedInOrder);
			return indexCandidate;
		}
		return null;
	}

	public ArrayList<String> getFieldsUsedInSelectGroupOrOrderOperations(String tableName, String query) throws SQLException, IOException, ClassNotFoundException {
		ArrayList<String> fields = new ArrayList<String>();
		ArrayList<String> fieldsUsedInSelect = getFieldsUsedInSelectOperations(tableName, query);
		ArrayList<String> fieldsUsedInGroup = getFieldsUsedInGroupOperations(tableName, query);
		ArrayList<String> fieldsUsedInOrder = getFieldsUsedInOrderOperations(tableName, query);

		fields = addFilesUsedInSelectOperations(fields, fieldsUsedInSelect);
		fields = addFilesUsedInGroupOperations(fields, fieldsUsedInGroup);
		fields = addFilesUsedInOrderOperations(fields, fieldsUsedInOrder);

		return fields;
	}

	public ArrayList<String> addFilesUsedInSelectOperations(ArrayList<String> fields, ArrayList<String> fieldsUsedInSelect) {
		for(int i = 0; i<fieldsUsedInSelect.size(); i++) {
			String currentField = fieldsUsedInSelect.get(i);
			if(!fields.contains(currentField)) {
				fields.add(currentField);
			}
		}
		return fields;
	}

	public ArrayList<String> addFilesUsedInGroupOperations(ArrayList<String> fields, ArrayList<String> fieldsUsedInGroup) {
		for(int i = 0; i<fieldsUsedInGroup.size(); i++) {
			String currentField = fieldsUsedInGroup.get(i);
			if(!fields.contains(currentField)) {
				fields.add(currentField);
			}
		}
		return fields;
	}

	public ArrayList<String> addFilesUsedInOrderOperations(ArrayList<String> fields, ArrayList<String> fieldsUsedInOrder) {
		for(int i = 0; i<fieldsUsedInOrder.size(); i++) {
			String currentField = fieldsUsedInOrder.get(i);
			if(!fields.contains(currentField)) {
				fields.add(currentField);
			}
		}
		return fields;
	}

	public ArrayList<String> getFieldsUsedInSelectOperations(String tableName, String query) throws SQLException, IOException, ClassNotFoundException {
		PostgreSqlSADriver pgsa = PostgreSqlSADriver.getInstance();
		ArrayList<String> fieldsUsedInSelectOperations =  new ArrayList<String>();
		ArrayList<String> tableFields = pgsa.getFieldsNames(tableName);
		ArrayList<String> selectsLines = getSelectsLines(query);
		for(int i = 0; i< selectsLines.size(); i++) {
			String currentSelectLine = selectsLines.get(i);
			for(int j = 0; j<tableFields.size(); j++) {
				String currentField = tableFields.get(j);
				if(currentSelectLine.contains(currentField)) {
					fieldsUsedInSelectOperations.add(currentField);
				}
			}
		}
		return fieldsUsedInSelectOperations;
	}

	public ArrayList<String> getFieldsUsedInGroupOperations(String tableName, String query) throws SQLException, IOException, ClassNotFoundException {
		PostgreSqlSADriver pgsa = PostgreSqlSADriver.getInstance();
		ArrayList<String> fieldsUsedInGroupOperations =  new ArrayList<String>();
		ArrayList<String> tableFields = pgsa.getFieldsNames(tableName);
		String groupByLine = getGroupByLine(query);
		for(int i = 0; i<tableFields.size(); i++) {
			String currentField = tableFields.get(i);
			if(groupByLine.contains(currentField)) {
				fieldsUsedInGroupOperations.add(currentField);
			}
		}
		return fieldsUsedInGroupOperations;
	}

	public ArrayList<String> getFieldsUsedInOrderOperations(String tableName, String query) throws SQLException, IOException, ClassNotFoundException {
		PostgreSqlSADriver pgsa = PostgreSqlSADriver.getInstance();
		ArrayList<String> fieldsUsedInOrderOperations =  new ArrayList<String>();
		ArrayList<String> tableFields = pgsa.getFieldsNames(tableName);
		String orderByLine = getOrderByLine(query);
		for(int i = 0; i<tableFields.size(); i++) {
			String currentField = tableFields.get(i);
			if(orderByLine.contains(currentField)) {
				fieldsUsedInOrderOperations.add(currentField);
			}
		}
		return fieldsUsedInOrderOperations;
	}


	public boolean isThereASeqScanOperation(ArrayList<String> queryPlan) {
		for(int i = 0; i< queryPlan.size(); i++) {
			String currentLine = queryPlan.get(i);
			if(currentLine.contains("Seq Scan")) return true;
		}
		return false;
	}


	public ArrayList<SeqScanWithFilter> extractSeqScansWithFilters(ArrayList<String> queryPlan, String sqlText) throws Exception {
		ArrayList<SeqScanWithFilter> seqScans = new ArrayList<SeqScanWithFilter>();

		for (Iterator<String> iterator = queryPlan.iterator(); iterator.hasNext();) {
			String seqLine = iterator.next();
			if( seqLine .contains("Seq Scan on") ){
				/* Se o plano tem linhas depois do Seq Scan, procuramos por opera��es
				 * de filtros usando Where/Join clauses */
				if (iterator.hasNext()) {
					String filterLine = iterator.next();
					if( filterLine.contains("Filter:") ){
						// Achou um Full Scan com filter
						//SeqScanWithFilter seq = getSeqScanWithFilter(seqLine, filterLine);
						ArrayList<String> wheresLines = getWheresLines(sqlText);
						SeqScanWithFilter seqScan = getSeqScanWithFilter(seqLine, wheresLines, filterLine);
						seqScans.add( seqScan );
					}
				}
			} 
		}
		return seqScans;
	}

	public ArrayList<SeqScan> extractSeqScans(ArrayList<String> queryPlan) {
		ArrayList<SeqScan> seqScans = new ArrayList<SeqScan>();

		for (Iterator<String> iterator = queryPlan.iterator(); iterator.hasNext();) {
			String seqLine = iterator.next();
			if( seqLine .contains("Seq Scan on") ){
				SeqScan seqScan = getSeqScan(seqLine);
				seqScans.add(seqScan);
			} 
		}
		return seqScans;
	}

	public SeqScan getSeqScan(String seqScanLine) {
		String tableName = getTableName( seqScanLine );
		String costEstimation = getSeqScanCostEstimation( seqScanLine );
		int retrievedRows = getNumberOfRetrievedRows( seqScanLine );
		//		String wldType = this.getType(wldId);
		//		int wldQtd = this.getQtd(wldId);
		return new SeqScan(tableName, costEstimation, retrievedRows);
	}

	//	public SeqScanWithFilter getSeqScanWithFilter(String seqScanLine, String filterLine) throws Exception{
	//		String tableName = getTableName( seqScanLine );
	//		String costEstimation = getSeqScanCostEstimation( seqScanLine );
	//		ArrayList<String> fields = getFieldsUsedInFilter(filterLine, tableName);
	//		String operador = getOperador( filterLine );
	//		int retrievedRows = getNumberOfRetrievedRows( seqScanLine );
	//		//		String wldType = this.getType(wldId);
	//		//		int wldQtd = this.getQtd(wldId);
	//		return new SeqScanWithFilter(tableName,costEstimation, retrievedRows, fields, operador);
	//	}
	//	
	public SeqScanWithFilter getSeqScanWithFilter(String seqScanLine, ArrayList<String> wheresLines, String filterLine) throws Exception{
		String tableName = getTableName( seqScanLine );
		String costEstimation = getSeqScanCostEstimation( seqScanLine );
		//ArrayList<String> fields = getFieldsUsedInFilter(wheresLines, tableName);
		ArrayList<String> fields = getFieldsUsedInFilter(filterLine, tableName);
		String operador = getOperador( filterLine );
		int retrievedRows = getNumberOfRetrievedRows( seqScanLine );
		//		String wldType = this.getType(wldId);
		//		int wldQtd = this.getQtd(wldId);
		return new SeqScanWithFilter(tableName,costEstimation, retrievedRows, fields, operador);
	}

	public static String getTableName(String seqScan){
		int pos_seq = seqScan.indexOf( "on" );
		String tabela = seqScan.substring(pos_seq + 2, seqScan.indexOf("(") ); 
		return tabela.trim();
	}

	public static String getSeqScanCostEstimation(String seqScan){
		return seqScan.substring( seqScan.indexOf("..") + 2, seqScan.indexOf( " rows" ) ).trim();
	}

		public static ArrayList<String> getFieldsUsedInFilter(String filterLine, String tableName) throws SQLException, IOException, ClassNotFoundException {
			ArrayList<String> fieldsUsedInFilter = new ArrayList<String>();
			PostgreSqlSADriver pgsa = new PostgreSqlSADriver();
			ArrayList<String> fieldsNames = pgsa.getFieldsNames(tableName);
			for(int i = 0; i<fieldsNames.size() ; i++) {
				String currentField = fieldsNames.get(i);
				if(filterLine.contains(currentField) && !fieldsUsedInFilter.contains(currentField)) {
					fieldsUsedInFilter.add(currentField);
				}
			}
			return fieldsUsedInFilter;
		}

//	public static ArrayList<String> getFieldsUsedInFilter(ArrayList<String> wheresLines, String tableName) throws SQLException, IOException, ClassNotFoundException {
//		ArrayList<String> fieldsUsedInFilter = new ArrayList<String>();
//		PostgreSqlSADriver pgsa = PostgreSqlSADriver.getInstance();
//		ArrayList<String> fieldsNames = pgsa.getFieldsNames(tableName);
//		for(int i = 0; i< wheresLines.size(); i++) {
//			String currentLine = wheresLines.get(i);
//			for(int j = 0; j<fieldsNames.size() ; j++) {
//				String currentField = fieldsNames.get(j);
//				if(currentLine.contains(currentField) && !fieldsUsedInFilter.contains(currentField)) {
//					fieldsUsedInFilter.add(currentField);
//				}
//			}
//		}
//		return fieldsUsedInFilter;
//	}
	//Rever este m�todo
	public static String getOperador( String filter ){
		ArrayList<String> operadores = new ArrayList<String>();
		operadores.add(">");
		operadores.add("<");
		operadores.add(">=");
		operadores.add("<=");
		operadores.add("=");
		operadores.add("<>");
		String[] partes = filter.split("\\s+");		
		for (int i = 0; i < partes.length; i++) 
			if( operadores.contains( partes[i] ) )return partes[i] ;
		return null;
	}

	public static int getNumberOfRetrievedRows( String seqScan ){
		int beginIndex = seqScan.indexOf("rows") + 5;  
		int endIndex = seqScan.indexOf("width") - 1;
		return Integer.parseInt(seqScan.substring(beginIndex, endIndex));
	}
	
	public ArrayList<String> getHashLines(ArrayList<String> queryPlan) {
		ArrayList<String> hashLines =  new ArrayList<String>();
		for(int i = 0; i< queryPlan.size(); i++) {
			String currentLine = queryPlan.get(i);
			if(currentLine.contains("Hash Cond")) {
				hashLines.add(currentLine);
			}
		}
		return hashLines;
	}
	
	public ArrayList<String> getJoinFilterLines(ArrayList<String> queryPlan) {
		ArrayList<String> joinLines =  new ArrayList<String>();
		for(int i = 0; i< queryPlan.size(); i++) {
			String currentLine = queryPlan.get(i);
			if(currentLine.contains("Join Filter")) {
				joinLines.add(currentLine);
			}
		}
		return joinLines;
	}
	
	public ArrayList<String> getTablesUsedInJoinLine(String joinLine) {
		ArrayList<String> tableNames = new ArrayList<String>();
		while(joinLine.contains("public.")) {
			int publicPosition = joinLine.indexOf("public.");
			joinLine = joinLine.substring(publicPosition+7);
			int dotPosition = joinLine.indexOf(".");
			String tableName = joinLine.substring(0, dotPosition);
			if(!tableNames.contains(tableName)) {
				tableNames.add(tableName);
			}
			joinLine = joinLine.substring(dotPosition);
		}
		return tableNames;
	}
	
	public ArrayList<String> getSelectsLines(String query) {
		ArrayList<String> selectsLines = new ArrayList<String>();
		while(query.toLowerCase().contains("select")) {
			int selectPosition = query.toLowerCase().indexOf( "select" );
			int fromPosition = query.toLowerCase().indexOf("from");
			String selectLine = query.substring(selectPosition + 7, fromPosition);
			selectsLines.add(selectLine);
			query = query.substring(fromPosition + 4);
		}
		return selectsLines;
	}

	public ArrayList<String> getWheresLines(String query) {
		ArrayList<String> wheresLines = new ArrayList<String>();
		while(query.toLowerCase().contains("where")) {
			int wherePosition = query.toLowerCase().indexOf("where");
			query = query.substring(wherePosition+6);
			if(query.toLowerCase().contains("exists")) {
				int existsPosition = query.toLowerCase().indexOf("exists");
				String whereLine = query.substring(0, existsPosition);
				wheresLines.add(whereLine);
				query = query.substring(existsPosition + 7);
				continue;
			}
			else {
				if(isThereAGroupByOperation(query)) {
					int groupByPosition = query.toLowerCase().indexOf("group by");
					String whereLine = query.substring(0,groupByPosition);
					wheresLines.add(whereLine);
					query = query.substring(groupByPosition + 9);
					continue;
				}
				else if(isThereAnOrderByOperation(query)) {
					int orderByPosition = query.toLowerCase().indexOf("order by");
					String whereLine = query.substring(0,orderByPosition);
					wheresLines.add(whereLine);
					query = query.substring(orderByPosition + 9);
					continue;
				}
				else if(isThereASelectOperation(query)){
					int selectPosition = query.toLowerCase().indexOf("select");
					String whereLine = query.substring(0,selectPosition);
					wheresLines.add(whereLine);
					query = query.substring(selectPosition+7 + 9);
					continue;
				}
				else {
					wheresLines.add(query);
					continue;
				}
			}
		}
		return wheresLines;
	}

	public String getGroupByLine(String query) {
		String groupByLine = "";
		if(isThereAGroupByOperation(query)) {
			int groupByPosition = query.toLowerCase().indexOf( "group by" );
			if(isThereAnOrderByOperation(query)) {
				int orderByPosition = query.toLowerCase().indexOf("order by");
				groupByLine = query.substring(groupByPosition + 9, orderByPosition);
			}
			else {
				groupByLine = query.substring(groupByPosition + 9);
			}
		}
		return groupByLine;
	}

	public String getOrderByLine(String query) {
		String orderByLine = "";
		if(isThereAnOrderByOperation(query)) {
			int orderByPosition = query.toLowerCase().indexOf("order by");
			orderByLine = query.substring(orderByPosition + 9);
		}
		return orderByLine;
	}

	public boolean isThereAGroupByOperation(String query) {
		return query.toLowerCase().contains("group by");
	}
	
	public boolean isThereASelectOperation(String query) {
		return query.toLowerCase().contains("select");
	}

	public boolean isThereAnOrderByOperation(String query) {
		return query.toLowerCase().contains("order by");
	}

}
