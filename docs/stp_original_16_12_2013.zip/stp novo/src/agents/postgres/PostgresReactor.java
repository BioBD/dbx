/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package agents.postgres;

import agents.WOAgent;
import entity.DAO.IndexCandidateDAO;
import entity.IndexCandidate;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lucas
 */
public class PostgresReactor {
        
    private String userName;
    private String password;
    private String urlAdress;
    private String driver;
    private Connection connection = null;
    private Properties propertiesFile;
    private String signatureToDifferentiate = null;
    
    
    public PostgresReactor() {
        try {
            loadProperties();
        } catch (IOException ex) {
            Logger.getLogger(PostgresReactor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void loadProperties() throws IOException {
        propertiesFile = new Properties();
        propertiesFile.load(WOAgent.class.getResourceAsStream("database.properties"));
        signatureToDifferentiate = this.propertiesFile.getProperty("signature");
        driver = this.propertiesFile.getProperty("driverPostgres");
        urlAdress = this.propertiesFile.getProperty("urlPostgres");
        userName = this.propertiesFile.getProperty("userPostgres");
        password = this.propertiesFile.getProperty("pwdPostgres");
    }

    public Connection connect() throws ClassNotFoundException, SQLException {
        Class.forName(driver);
        return DriverManager.getConnection(urlAdress, userName, password);
    }
    
    public void updateIndexStructuresConfiguration(ArrayList<IndexCandidate> indexCandidates, double k) throws IOException, SQLException, ClassNotFoundException {
        IndexCandidateDAO indexCandidateDAO = new IndexCandidateDAO();
        int newTotalProfit = getTotalIndexesProfit(indexCandidates);
        ArrayList<IndexCandidate> currentRealIndexes = indexCandidateDAO.getAllRealIndexes();
        int currentTotalProfit = getTotalIndexesProfit(currentRealIndexes);
        
        for (int i = 0; i < indexCandidates.size(); i++) {
            System.out.println("Index Candidates:");
            System.out.println(indexCandidates.get(i).getId());
        }
        
         for (int i = 0; i < currentRealIndexes.size(); i++) {
             System.out.println("Real Indexes");
             System.out.println(currentRealIndexes.get(i).getId());
        }

        System.out.println("new total profit: " +newTotalProfit+"currentTotalProfit: "+currentTotalProfit);
        if(newTotalProfit > currentTotalProfit*k) {
            for(IndexCandidate currentIndexCandidate : indexCandidates) {
                if(currentIndexCandidate.isIndexCandidateHypothetical()) {
                    createPhysicallyIndex(currentIndexCandidate);
                }
            }
            for(IndexCandidate currentRealIndex : currentRealIndexes) {
                if(!indexBelongsToSet(currentRealIndex, indexCandidates)) {
                    dropIndex(currentRealIndex);
                }
            }
        }
    }
    
    public boolean indexBelongsToSet(IndexCandidate indexCandidate, ArrayList<IndexCandidate> setOfIndexes) {
        ArrayList<Integer> indexesIds =  getIndexesIds(setOfIndexes);
        System.out.println("Set Of Selected Indexes: " + indexesIds);
        System.out.println("Index Candidate Id: " + indexCandidate.getId());
        if(indexesIds.contains(indexCandidate.getId())) {
            return true;
        }
        return false;
    }
    
    public ArrayList<Integer> getIndexesIds(ArrayList<IndexCandidate> indexCandidates) {
        ArrayList<Integer> indexesIds = new ArrayList<Integer>();
        for(IndexCandidate currentIndexCandidate : indexCandidates) {
            indexesIds.add(currentIndexCandidate.getId());
        }
        return indexesIds;
    }
    
    public int getTotalIndexesProfit(ArrayList<IndexCandidate> indexCandidates) {
        int totalProfit = 0;
        for(int i = 0; i< indexCandidates.size(); i++) {
            IndexCandidate currentIndexCandidate = indexCandidates.get(i);
            totalProfit += currentIndexCandidate.getProfit();
        }
        return totalProfit;
    }
    
    public void createPhysicallyIndex(IndexCandidate indexCandidate) throws ClassNotFoundException, SQLException, IOException {
        Connection connection = connect();
        String tableName = indexCandidate.getTableName();
        ArrayList<String> columns = indexCandidate.getColumns();
        String columnsString = getColumnsString(columns);
        String indexName = indexCandidate.getType() + "_" + tableName + "_" + indexCandidate.getId();
        String sqlClause = signatureToDifferentiate + "CREATE INDEX " + indexName + " on " + tableName+columnsString;
        Statement statement = connection.createStatement();
        statement.executeUpdate(sqlClause);
        
        System.out.println("Index Candidate Id: " + indexCandidate.getId() + " type: " +indexCandidate.getType());
        
        if(indexCandidate.getType().toUpperCase().equals("P")) {
            String sqlClauseToCluster = signatureToDifferentiate + "CLUSTER " + indexName + " on " + tableName;
            statement.executeUpdate(sqlClauseToCluster);
        }
        
        System.out.println("Criou Fisicamente Índice "+indexCandidate.getId() );
        
        indexCandidate.setStatus("R");
        IndexCandidateDAO indexCandidateDAO = new IndexCandidateDAO();
        indexCandidateDAO.updateStatus(indexCandidate);
        
        statement.close();
        connection.close();
    }
    
    public void dropIndex(IndexCandidate indexCandidate) throws SQLException, ClassNotFoundException, IOException {
        Connection connection = connect();
        String tableName = indexCandidate.getTableName();
        String indexName = indexCandidate.getType() + "_" + tableName + "_" + indexCandidate.getId();
        String sqlClause = "DROP INDEX " + indexName;
        Statement statement = connection.createStatement();
        statement.executeUpdate(sqlClause);
        
        System.out.println("Dropou Index: " + indexCandidate.getId());
        
        indexCandidate.setStatus("H");
        IndexCandidateDAO indexCandidateDAO = new IndexCandidateDAO();
        indexCandidateDAO.updateStatus(indexCandidate);
        
        if(indexCandidate.getProfit() > 0) indexCandidate.setProfit(0);
        indexCandidateDAO.updateProfit(indexCandidate);
        
        statement.close();
        connection.close();
    }
    
    public String getColumnsString(ArrayList<String> columns) {
        String columnsString = columns.toString();
        int lastPosition = columnsString.length();
        columnsString = columnsString.replace("[","(");
        columnsString = columnsString.replace("]", ")");
        return columnsString;
    }
    
}
