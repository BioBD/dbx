package agents;

import java.util.Properties;

import util.Log;

import agents.factory.STPFactory;
import drivers.WADriver;

/**
 * @author Jos� Maria
 * Classe usada para representar "Agent for Workload Obtainment"
 * Respons�vel por capturar a carga de trabalho submetida ao SBD
 */
public class WOAgent extends Thread {
	
	/** vari�vel auxiliar utilizada para gerar um log da execu��o **/ 
	Log log = null;	
	
	/** inst�ncia de WADriver **/
	WADriver driver;
	
	/**
	 * M�todo Construtor
	 */
	public WOAgent() {
		super();
		this.log = new Log();
	}
	
	/**
	 * M�todo principal de WOAgent
	 * Respons�vel por, periodicamente, capturar a carga de trabalho submetida ao SBD
	 */
	public void run() {
		
		/* Cria��o do WADriver */
		Properties parameters = new Properties();
		try{
			parameters.load(WOAgent.class.getResourceAsStream("database.properties"));
		}
		catch(Exception e){
			log.write( e );
		}
		/* Cria��o do WADriver */
		int database = Integer.parseInt(parameters.getProperty("database"));
		STPFactory wadf = STPFactory.getWADFactory(database);
		driver = wadf.getWADriver();
		
		//Mensagem indicativa da execu��o do agente WOAgent
		log.write("WOAgent Running ................................................");
		
		//La�o principal (infinito)
		while (true) {
			/* m�todo do driver responsvel pela obten��o da carga de trabalho */
			try {
				driver.getLastExecutedQueries();
                                
			} catch (Exception e) {
				log.write( e );
			}
			try {
				//sleep(5000);
				sleep(2000);
			} catch (InterruptedException e) {
				log.write( e );
			}
		}
	}
	
	/**
	 * M�todo utilizado para instanciar e inicializar um WOAgent
	 */
	public static void main(String[] args) {
		new WOAgent().start();
	}
}