package agents;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import agents.factory.STPFactory;
import drivers.UDDriver;

/**
 * @author Jos� Maria
 * Classe usada para representar o "Executer Agent"
 */
public class ExecuterAgent {

	/** inst�ncia de UDDriver **/
	UDDriver updateDriver;
	
	/**
	 * M�todo Construtor
	 */
	ExecuterAgent(){
		/* Cria��o do UDDriver  */
		Properties parameters = new Properties();
		try{
			parameters.load(ExecuterAgent.class.getResourceAsStream("database.properties"));
		}
		catch(Exception e){
			System.out.println("ERRO:" + e.getStackTrace());
		}
		int database = Integer.parseInt(parameters.getProperty("database"));
		STPFactory wadf = STPFactory.getWADFactory(database);
		updateDriver = wadf.getUDDriver();
	}
	
	/**
	 * M�todo usado para criar um �ndice em uma determinada tabela
	 * @param tableName Nome da tabela a ser indexada
	 * @param indexName Nome do ndice a ser criado
	 * @param columnsName Nome de uma ou mais colunas da tabela
	 */
	public void createIndex(String tableName, String indexName, String[] columnName) {
		updateDriver.createIndex(tableName, indexName, columnName);
	}

	/**
	 * M�todo usado para criar um �ndice em uma determinada tabela
	 * @param schemaName Nome do Schema
	 * @param tableName Nome da tabela a ser indexada
	 * @param indexName Nome do ndice a ser criado
	 * @param columnsName Nome de uma ou mais colunas da tabela
	 */
	public void createIndex(String schemaName, String tableName, String indexName, String[] columnName, String accessMethod) {
		try{
			updateDriver.createIndex(schemaName, tableName, indexName, columnName, accessMethod);
		}
		catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	/**
	 * M�todo usado para criar um �ndice prim�rio em uma determinada tabela
	 * @param schemaName Nome do Schema
	 * @param tableName Nome da tabela a ser indexada
	 * @param indexName Nome do ndice a ser criado
	 * @param columnsName Nome de uma ou mais colunas da tabela
	 * @param accessMethod Tipo de m�todo de acesso
	 */
	public void createPrimaryIndex(String schemaName, String tableName, String indexName, String[] collumnName, String accessMethod){
		updateDriver.createPrimaryIndex(schemaName, tableName, indexName, collumnName, accessMethod);
	}
	
	/**
	 * M�todo usado para remover um �ndice em uma determinada tabela
	 * @param indexName Nome do ndice a ser criado
	 */
	public void dropIndex(String indexName) {
		updateDriver.dropIndex(indexName);
	}
	
	/**
	 * M�todo usado para incrementar o benef�cio de um �ndice prim�rio
	 * @param schemaName Nome do Schema
	 * @param tableName Nome da tabela a ser indexada
	 * @param field Nome da coluna
	 * @param value Valor a ser adicionado no benef�cio acumulado do �ndice
	 * @param wldId id da express�o SQL analisada
	 * @param wldType tipo da express�o SQL analisada
	 * @param creationCost Custo de cria��o do �ndice
	 * @return Valor do benef�cio acumulado ap�s a atualiza��o
	 */
	public double incrementPrimaryIndexBenefict(String schemaname, String tableName, ArrayList<String> field, double value, int wldId, String wldType, double creationCost) throws SQLException{
		return updateDriver.incrementPrimaryIndexBenefict(schemaname,tableName,field,value, wldId, wldType, creationCost);
	}
		
	/**
	 * M�todo usado para incrementar o benef�cio de um �ndice secund�rio
	 * @param schemaName Nome do Schema
	 * @param tableName Nome da tabela a ser indexada
	 * @param field Nome da coluna
	 * @param value Valor a ser adicionado no benef�cio acumulado do �ndice
	 * @param wldId id da express�o SQL analisada
	 * @param wldType tipo da express�o SQL analisada
	 * @param creationCost Custo de cria��o do �ndice
	 * @return Valor do benef�cio acumulado ap�s a atualiza��o
	 */
	public double incrementSecondaryIndexBenefict(String schemaname, String tableName, ArrayList<String> field, double value, int wldId, String wldType, double creationCost) throws SQLException{
		return updateDriver.incrementSecondaryIndexBenefict(schemaname,tableName,field,value,wldId,wldType,creationCost);
	}
	
	/**
	 * M�todo usado para adicionar um novo �ndice candidato
	 * @param tableName Nome da tabela a ser indexada
	 * @param field Nome da coluna
	 */
	public void addCandidateIndex(String tableName, ArrayList<String> field, String cidType, double value, double creationCost) throws SQLException{
		updateDriver.addCandidateIndex(tableName, field, cidType, value, creationCost);
	}
	
	/**
	 * M�todo usado para clusterizar uma tabela
	 * @param tableName Nome da tabela a ser clusterizada
	 * @param realIndexName Nome do �ndice a ser usado na clusteriza��o da tabela
	 */
	public void clusterTable(String tableName, String realIndexName){
		updateDriver.clusterTable(tableName, realIndexName);
	}

	/**
	 * M�todo usado para atualizar o nome de um �ndice na MetaBase Local
	 * @param ciId Identificador do �ndice a ser atualizado
	 * @param realIndexName Nome do �ndice a ser usado na atualiza��o
	 */
	public void updateIndexName(int cidId, String realIndexName){
		updateDriver.updateIndexName(cidId, realIndexName);
	}
	
}
