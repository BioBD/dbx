package facade;

import java.util.ArrayList;
import entity.Task;
import entity.DAO.TaskDAO;


public class WorkloadFacade {

	
	public ArrayList<Task> getCapturedWorkload() throws Exception {
		TaskDAO taskDAO = new TaskDAO(); 
		return taskDAO.getObtainedWorkload();
	}

}
