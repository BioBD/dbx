package facade;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import entity.IndexCandidate;
import entity.DAO.IndexCandidateDAO;


public class IndexCandidateFacade {
	
	public ArrayList<IndexCandidate> getIndexCandidatesBelongsToTask(int taskId) throws IOException, SQLException, ClassNotFoundException {
		IndexCandidateDAO indexCandidateDAO = new IndexCandidateDAO();
		return indexCandidateDAO.getIndexCandidateBelongsToTask(taskId);
	}
	
	public ArrayList<String> getColumnsBelongsToIndex(int indexId) throws IOException, SQLException, ClassNotFoundException {
		IndexCandidateDAO indexCandidateDAO = new IndexCandidateDAO();
		return indexCandidateDAO.getColumnsBelongsToIndexCandidate(indexId);
	}

}
