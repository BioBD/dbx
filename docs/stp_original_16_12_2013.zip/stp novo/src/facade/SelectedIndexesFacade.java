/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package facade;

import agents.postgres.PostgresPredictor;
import entity.DAO.IndexCandidateDAO;
import entity.IndexCandidate;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Lucas
 */
public class SelectedIndexesFacade {
    
    public ArrayList<IndexCandidate> getSelectedIndexCandidates(int storageConstraint) throws IOException, SQLException, ClassNotFoundException {
        PostgresPredictor predictor = new PostgresPredictor();
        IndexCandidateDAO indexCandidateDAO = new IndexCandidateDAO();
        ArrayList<IndexCandidate> allIndexCandidates = indexCandidateDAO.getAllIndexCandidates();
        return predictor.selectAnIndexStructureConfiguration(allIndexCandidates, storageConstraint);
    }
    
}
